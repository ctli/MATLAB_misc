clear all
close all
clc
format compact

% This m-file shows how to  generate  a reduced order model

% plant
A = [0 1 0;
    64.4 0 -16;
    0 0 -100];
B = [0;
    0;
    100];
C = [1 0 0];
D = 0;

% eigenvalues and zeros of full order model
plant_eigenvalues =  eig(A)
plant_zeros =   tzero(A,B,C,D)

% bode plot of full order model
[mag,phase,w] = bode(A,B,C,D);
phase = squeeze(phase);
mag = squeeze(mag);
mag = 20*log10(mag);

%% ================================================================== %%
% find the reduced order model by using modal residualization 
disp('==================================');
disp('Reduced plant:');
[am,bm,cm,dm] = canon(A,B,C,D,'modal'); % diagonalizes system

% elim = input('which states to delete?'); % enter which state you wish to delete
elim = 3; % eliminate 3rd state
[ar,br,cr,dr] = modred(am,bm,cm,dm,elim);

% eigenvalues and zeros of reduced order model
reduced_mod_evalues = eig(ar)
reduced_mod_zeros = tzero(ar,br,cr,dr)

% bode plot of reduced order model
[magr,phaser] = bode(ar,br,cr,dr,1,w);
phaser = squeeze(phaser);
magr = squeeze(magr);
magr = 20*log10(magr);

%% ================================================================== %%
% compare Bode plots
figure(1); clf;
subplot(2,1,1)
semilogx(w,mag,'k-',w,magr,'k--');
title('Bode plots')
ylabel('magnitude, dB')
set(gca, 'position', [0.1432,0.58,0.7618,0.32]);

subplot(2,1,2);
semilogx(w,phase,'k-',w,phaser-360,'k--');
xlabel('frequency,rad/sec')
ylabel('phase,degrees')
legend('full order','reduced order',3);
set(gca, 'position', [0.1432,0.1493,0.7618,0.32]);

defaultratio_ppt('old axis');

% %% ================================================================== %%
% % bode plot with phase wrapping
% figure(2); clf;
% P = bodeoptions;
% P.phasewrapping = 'on';
% bode(ss(A,B,C,D), 'k-', ss(ar,br,cr,dr), 'k--', P);
% legend('full order','reduced order',3);

