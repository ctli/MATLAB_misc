% Deisel engine with VGT & EGR
clear all;
close all;
clc;
format compact

Py = [-0.84,  1.8;
      -1.1, -2.1];

Pz = [0.23, -0.55;
      -0.9,  1.84];
zss = [1;
      -1];

uss = inv(Pz)*zss
yss = Py*uss

%singular values
s_z = svds(inv(Pz))
s_y = svds(Py)