clear all
close all
clc
format compact

s = tf('s');

D = s^4+4*s^3+7*s^2+6*s+3; %=(s^2+s+1)*(s^2+3*s+3)
Gzd = s*(s+1)/D;
Gyu = Gzd;
Gzu = s*(s^2+2*s+2)/D;
Gyd = Gzu;

K = -Gzd/(Gyd^2-Gzd^2);
Tyd = minreal((Gyd^2-Gzd^2)/Gyd)
pole(Tyd)

% step disturbancd
step(Tyd)


