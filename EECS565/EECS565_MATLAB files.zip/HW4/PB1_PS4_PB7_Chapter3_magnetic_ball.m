clear all;
close all;
clc;
format compact;
format short e %format: 8.0250e+000

% plant for the magnetic ball problem
A = [0 1 0;
    64.4 0 -16;
    0 0 -100];
B = [0;
    0;
    100];
C = [1 0 0];
D = [0];

% disturbance description
E=B; % range(E) belongs to range(B)
F=0;

plant_eigenvalues = eig(A)
plant_zeros = tzero(A,B,C,D)

%% ================================================================== %%
% various pole locations....
% First the bad design from the problem set -- you want a better design!!!!!!!!!!!
psf = [-6+6*1i   -6-6*1i   -20]*3
pobs = [psf*2 -5]*3

% design the controller with state feedback and bias estimator
% dimensions of system (makes it easier to specify closed loop
% system matrices)
n = size(A,1); % #plant states
p = size(B,2); % #inputs
q = size(C,1); % #outputs
m = size(E,2); % #disturbance states

% check the feasibility conditions 
rank([A B;C zeros(size(C,1),size(B,2))]) - (n+q)
rank([A E;C F]) - (n+m)

%% ================================================================== %%
% if the feasibility conditions are satisfied
% then choose K, L, G, H, so that the control signal is given by
% u = -K*xhat + G*r + H*dhat and L is the estimator gain
K = place(A,B,psf);

Aaug = [A E;
        zeros(size(C,1), size(A,2)), zeros(size(C,1), size(E,2))];
Caug = [C F];
L = place(Aaug',Caug',pobs).';
L1 = L(1:3);
L2 = L(4);

G = (C*((-A+B*K)^(-1))*B)^(-1); %eq(3.52)
H = -G*(C*((-A+B*K)^(-1))*E+F); %eq(3.53)

% closed loop state equations (Bcl and Dcl map the reference r and
% disturbance w to the state derivative and output, respectively)
% eq(3.54)
Acl = [A,          -B*K,        B*H;
       L1*C, A-B*K-L1*C, E+B*H-L1*F;
       L2*C,      -L2*C,      -L2*F];
	  
Bcl = [B*G, E;
       B*G, L1*F;
         0, L2*F];

Ccl = [C, zeros(size(C)), 0];
Dcl = 0;

Cu = [zeros(1,n) -K H];
Du = [G 0];

% create step command r and disturbance w
t = linspace(0,5,500);
r = zeros(size(t)); r(t>1) = 1;
w = zeros(size(t)); w(t>2) = 0.5;

% simulate response of y and u to command and disturbance
[y,x] = lsim(Acl,Bcl,Ccl,Dcl,[r' w'],t);
[u,x] = lsim(Acl,Bcl,[zeros(1,n) -K H],[G 0],[r' w'],t);
xhat = x(:,n+1:2*n);
dhat = x(:,2*n+1:2*n+m);

% % anther way to see u:
% u =-K*xhat'+G*r+H*dhat';

figure(1); clf;
set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 6.67, 2.8]);

subplot(1,2,1);
plot(t,r,'k:', 'linewidth', 1); hold on;
plot(t,y,'k-', 'linewidth', 1);
plot(t,w,'k:', 'linewidth', 2);
plot(t,dhat,'k-', 'linewidth', 2);
xlabel('time, seconds')
legend('ref','y (out)','w (dist)','w_{est}',4)
ylim([-0.2 1.2]);
set(gca,'ytick', -0.2:0.2:1.2);
set(gca, 'position', [0.07 0.15 0.4 0.7]);
title('output(y) to step command & step disturbance');

subplot(1,2,2);
plot(t,u, 'k-', 'linewidth', 1);
xlabel('time, seconds')
legend('u',4)
set(gca, 'position', [0.55 0.15 0.4 0.7]);
title('control signal(u) to step command & step disturbance');

%% ================================================================== %%
% simulate the design with  disturbance ONLY
% this makes it easier to separate the disturbance response from the command response
t = linspace(0,5,500);
r = zeros(size(t));
w = zeros(size(t)); w(t>2) = 0.5;

[y,x] = lsim(Acl,Bcl,Ccl,Dcl,[r' w'],t);
[u,x] = lsim(Acl,Bcl,[zeros(1,3) -K H],[G 0],[r' w'],t);
xhat = x(:,n+1:2*n);
dhat = x(:,2*n+1:2*n+m);

figure(2); clf;
set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 6.67, 2.8]);

subplot(1,2,1);
plot(t,r,'k:', 'linewidth', 1); hold on;
plot(t,y,'k-', 'linewidth', 1);
plot(t,w,'k:', 'linewidth', 2);
plot(t,dhat,'k-', 'linewidth', 2);
xlabel('time, seconds')
legend('ref','y (out)','w (dist)','w_{est}',4)
% ylim([-0.2 1.2]);
set(gca,'ytick', -0.2:0.2:1.2);
set(gca, 'position', [0.07 0.15 0.4 0.7]);
title('output(y) to step command & step disturbance');

subplot(1,2,2);
plot(t,u, 'k-', 'linewidth', 1);
xlabel('time, seconds')
legend('u',4)
ylim([-1 0.2]);
set(gca, 'position', [0.55 0.15 0.4 0.7]);
title('control signal(u) to step command & step disturbance');

%% ================================================================== %%
% compute closed loop disturbance response, Tdy
Acl = [A,          -B*K,        B*H;
       L1*C, A-B*K-L1*C, E+B*H-L1*F;
       L2*C,      -L2*C,      -L2*F];
Bcl = [E;
       L1*F;
       L2*F];
Ccl = [C, zeros(size(C)), 0];

s = tf('s');
Tdy = Ccl*((s*eye(7)-Acl)^(-1))*Bcl

omega = logspace(-3,3);
[mag,phase] = bode(Tdy, omega);
mag = squeeze(mag);
phase = squeeze(phase);
mag = 20*log10(mag);

figure(3);clf;
loglog(omega,mag, 'k')
ylabel('magnitude, dB')
xlabel('frequency, rad/sec')
title('closed loop disturbance response')
hold on;
line([10^-3 10^3], [-20 -20], 'color', 'k', 'linestyle', ':');
text(1, -19, '-20dB', 'HorizontalAlignment', 'center');
defaultratio_ppt('old axis');
