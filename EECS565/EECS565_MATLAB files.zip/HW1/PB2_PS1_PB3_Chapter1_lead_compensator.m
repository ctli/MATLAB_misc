clear all
close all
clc
format compact

w = logspace(-3,100,10000);

s = tf('s');

P = 1/(s*(s+1));

%% ===================================================================== %%
% root locus
figure(1);
rlocus(P);
set(gca, 'fontsize', 12);
title('Root Locus of P = 1/(s*(s+1))', 'fontsize', 12);
xlabel('Real Axis', 'fontsize', 12);
ylabel('Imaginary Axis', 'fontsize', 12);

%% ===================================================================== %%
sisotool(P)

% %% ===================================================================== %%
% r0 = -2 + 2*sqrt(3)*1i; % desired pole location
% p = 10
% phi1 = angle(r0)*180/pi;
% phi2 = angle(r0+1)*180/pi;
% phi3 = angle(r0+p)*180/pi;
% psi = -180-(-phi1-phi2-phi3);
% z = 2*sqrt(3)/tan(psi*pi/180)+2
% 
% D = (s+z)/(s+p);
% [mag,phase] = bode(D,w);
% mag = squeeze(mag);
% phase = squeeze(phase);
% mag = 20*log10(mag);
% 
% % Bode plot of the compensator
% figure(2);
% subplot(2,1,1);
% semilogx(w,mag, 'k');
% xlabel('frequency, rad/sec');
% ylabel('magnitude, dB');
% xlim([10^-1 10^2]);
% title('Bode plot of the lead compensator: (s+3.2941)/(s+10)');
% 
% subplot(2,1,2);
% semilogx(w,phase, 'k');
% xlabel('frequency, rad/sec');
% ylabel('phase,degrees');
% xlim([10^-1 10^2]);
% 
% defaultratio_ppt('old axis');
% 
% %% ===================================================================== %%
% % Step response of CL system
% k = 34; % found by hand calculation to math coefficients
% C = k*D;
% t = linspace(0,4,100);
% G = C*P/(1+C*P);
% figure(3);
% y = step(G, t);
% plot(t, y, 'k');
% title('Step response of CL system: G = C*P/(1+C*P)');
% xlabel('Time [sec]');
% ylabel('Amplitude');
% defaultratio_ppt('old axis');
% 
% 
% %% ===================================================================== %%
% % Corrected step response of CL system
% p = 10;
% z= 2.5;
% k = 28.756; % found by hand calculation to math coefficients
% D = (s+z)/(s+p);
% C = k*D;
% 
% t = linspace(0,4,100);
% G = C*P/(1+C*P);
% 
% disp('Closed loop poles:');
% pole(G)
% 
% figure(4);
% y = step(G, t);
% plot(t, y, 'k');
% title({'Step response of CL system with new compensator:', 'C = 28.756*(s+2.5)/(s+10)'});
% xlabel('Time [sec]');
% ylabel('Amplitude');
% defaultratio_ppt('old axis');
% 
% 
% %% ===================================================================== %%
% % Bode plot of S = 1/(1+P*C) & T = P*C/(1+P*C)
% p = 10;
% z= 2.5;
% k = 28.756; % found by hand calculation to math coefficients
% D = (s+z)/(s+p);
% C = k*D;
% 
% S = 1/(1+P*C);
% [magS,phaseS] = bode(S,w);
% magS = squeeze(magS);
% phaseS = squeeze(phaseS);
% magS = 20*log10(magS);
% 
% T = P*C/(1+P*C);
% [magT,phaseT] = bode(T,w);
% magT = squeeze(magT);
% phaseT = squeeze(phaseT);
% magT = 20*log10(magT);
% 
% figure(5); clf;
% semilogx(w,magS, w, magT);
% xlabel('frequency, rad/sec');
% ylabel('magnitude, dB');
% xlim([10^-1 10^2]);
% legend('S = 1/(1+P*C)', 'T = P*C/(1+P*C)', 'location', 'south');
% 
% 
% %% ===================================================================== %%
% % Nyquist plot of the OL system
% L = P*C;
% 
% figure(6); clf;
% nyquist(L);
% axis([-2 2 -2 2]);
% axis equal
% 
% % plot a unit circle at the origin
% circle = rsmak('circle');
% hold on;
% fnplt(circle,':k',[],1,[]); % FNPLT(F,SYMBOL,INTERV,LINEWIDTH,JUMPS)
% 
% % find the interesction point on unit circle to compute the phase margin
% [re,im] = nyquist(L);
% re = squeeze(re);
% im = squeeze(im);
% temp = sqrt(re.^2+im.^2);
% intersect_x = interp1(temp, re, 1);
% intersect_y = interp1(temp, im, 1);
% phase_margin = atan(intersect_y/intersect_x)*180/pi
% plot([0 intersect_x*10], [0 intersect_y*10], 'color', [0.5 0.5 0.5]);
% 
% % find the interesction point on real axis to compute the gain margin
% intersect_y = find(im == 0) % it's empty, no intersection, gain margin == inf
% 
% % Bode plot of the OL system, and GainMargin & PhaseMargin
% figure(7);
% margin(L);

