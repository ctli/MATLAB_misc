clear all
close all
clc

s = tf('s');
P = 1/(s^2 + s);
C = (s+2)/(s+5);
L = P*C;
S = 1/(1+L);

T1 = L/(1+L)
T2 = 1-S


% Transfer function:
%          s^4 + 8 s^3 + 17 s^2 + 10 s
% ----------------------------------------------
% s^6 + 12 s^5 + 47 s^4 + 68 s^3 + 42 s^2 + 10 s
%  
%  
% Transfer function:
%         s + 2
% ---------------------
% s^3 + 6 s^2 + 6 s + 2


