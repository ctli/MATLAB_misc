clear all
close all
clc


w = logspace(-3,2,200);
t = linspace(0,20,100);

zeta = 0.5;
wn = [1 2 5];

s = tf('s');
clear mag phase
for i = 1:length(wn)
    G = (wn(i)^2)/(s^2 + 2*zeta*wn(i)*s + (wn(i)^2));
    [mag(i,:),phase(i,:)] = bode(G,w);
end

% figure(1); clf;
% loglog(w,mag(1,:),'-',w,mag(2,:),':',w,mag(3,:),'-.',w,mag(4,:),'--')
% xlabel('frequency, rad/sec')
% ylabel('magnitude')
% title('Bode Gain plots, 1st order filters')
% legend('p=0.01','p=0.1','p=1.0','p=10.0',3)


%%   to plot Bode magnitude in db instead of absolute units, use the
%%   following commands

figure(1); clf;
mag = 20*log10(mag);
semilogx(w,mag(1,:),'k-',w,mag(2,:),'k:',w,mag(3,:),'k-.')
xlabel('frequency, rad/sec')
ylabel('magnitude, dB')
title('Bode Gain plots, 2nd order systems')
legend('w_n=1 rad/s','w_n=2 rad/s','w_n=5 rad/s',3);
defaultratio_ppt('old axis');

figure(2); clf;
semilogx(w,phase(1,:),'k-',w,phase(2,:),'k:',w,phase(3,:),'k-.')
xlabel('frequency, rad/sec')
ylabel('phase,degrees')
title('Bode Phase plots, 2nd order systems')
legend('w_n=1 rad/s','w_n=2 rad/s','w_n=5 rad/s',3)
defaultratio_ppt('old axis');


clear y
for i = 1:length(wn)
    G = (wn(i)^2)/(s^2 + 2*zeta*wn(i)*s + (wn(i)^2));
    y(:,i) = step(G,t);
end

figure(3); clf;
plot(t,y(:,1),'k-',t,y(:,2),'k:',t,y(:,3),'k-.')
xlabel('time, seconds')
title('Step responses, 2nd order systems')
legend('w_n=1 rad/s','w_n=2 rad/s','w_n=5 rad/s', 4)
defaultratio_ppt('old axis');

