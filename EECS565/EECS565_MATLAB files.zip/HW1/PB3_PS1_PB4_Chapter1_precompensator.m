clear all;
close all;
clc;
format compact


s = tf('s');
% plant transfer function
P =  1/(s*(s+1));

% controller transfer function
C = 34*(s+3.2941)/(s+10);
 
% form open loop, complementary sensitivity, and sensitivity functions
L =  C*P;
T =  L/(1+L);
T = minreal(T); 
S =  1/(1+L);
closed_loop_zeros = zero(T)   % closed loop zeros
closed_loop_poles = pole(T)   % closed loop poles

% plot closed loop step response: because this is a 1DOF feedback system
% the closed loop command response is given by the complementary sensitivity function


t = linspace(0,5,200);
y = step(T,t);
figure(1);
plot(t,y, 'k')
xlabel('time, seconds')
grid
title('step response')
defaultratio_ppt;

%% ===================================================================== %%
% add in a  precompensator to satisfy design specification
wn = 3.6;
zeta = 0.5;
G_desired = wn^2/(s^2 + 2*zeta*wn*s + wn^2)
G = G_desired/T

GT = G_desired;
y = step(GT,t);

figure(2);
plot(t,y, 'k')
xlabel('time, seconds')
grid
title('step response with precompensator')
defaultratio_ppt;


%% ===================================================================== %%
% vector of uncertain gains
K = [1.5  1.0  0.8  0.5  -0.01  -1.0];
for i = 1:length(K)
	P1 =  K(i)/(s*(s+1));
	L= C*P1;
    T =  L/(1+L);
    T = minreal(T);
    S =  1/(1+L);
	GT =  G*T;
	
	% create a vector of step responses
	y([1:length(t)],i) = step(GT,t); 
end


figure(3);clf;
plot(t,y(:,1),'k:'); hold on;
plot(t,y(:,2),'k', 'linewidth', 2);
plot(t,y(:,3),'k-.',t,y(:,4),'k--',t,y(:,5),'kx',t,y(:,6),'ko')
axis([0 5 -1.4 1.4]);
set(gca, 'ytick', -1.4:0.2:1.4);
grid
title('perturbed step response')
xlabel('time, seconds')
legend(['K = ',num2str(K(1))],...
       ['K = ',num2str(K(2))],...
       ['K = ',num2str(K(3))],...
       ['K = ',num2str(K(4))],...
       ['K = ',num2str(K(5))],...
       ['K = ',num2str(K(6))], 4);

