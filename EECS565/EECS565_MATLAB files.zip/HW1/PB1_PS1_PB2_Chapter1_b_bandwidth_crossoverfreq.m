% One DOF feedback system
% CL bandwidth ~ OP crossover freq
clear all
close all
clc
format compact

w = logspace(-3,2,200);
t = linspace(0,20,100);

zeta = 0.5;
wn = [1 2 5];

s = tf('s');
clear magL phaseL
for i = 1:length(wn)
    L = (wn(i)^2)/(s*(s + 2*zeta*wn(i)));
    T = L/(1+L);
    [magL(i,:),phaseL(i,:)] = bode(L,w);
    [magT(i,:),phaseT(i,:)] = bode(T,w);
    
    temp = allmargin(L);
    w_c(i) = temp.PMFrequency;  % crossover frequency: 0db @ OL bode plot
    w_bw(i) = bandwidth(T); % bandwidth: -3db @ CL bode plot
end

%%   to plot Bode magnitude in db instead of absolute units, use the
%%   following commands

figure(1); clf;
magL = 20*log10(magL);
semilogx(w,magL(1,:),'k-',w,magL(2,:),'k:',w,magL(3,:),'k-.')
xlabel('frequency, rad/sec')
ylabel('magnitude, dB')
title('Bode Gain plots, L = P*C')
legend('w_n=1 rad/s','w_n=2 rad/s','w_n=5 rad/s',1);
defaultratio_ppt('old axis');

figure(2); clf;
magT = 20*log10(magT);
semilogx(w,magT(1,:),'k-',w,magT(2,:),'k:',w,magT(3,:),'k-.')
xlabel('frequency, rad/sec')
ylabel('magnitude, dB')
title('Bode Gain plots, T = L/(1+L)')
legend('w_n=1 rad/s','w_n=2 rad/s','w_n=5 rad/s',3);
defaultratio_ppt('old axis');


for i = 1:length(wn)
    figure(1); hold on;
    plot(w_c(i), 0, 'k.', 'MarkerSize', 15);
    axx=[50 50+i*10];
    axy=[-20*i 0];
    [arrowx,arrowy] = dsxy2figxy(gca, axx, axy);
    annotation('textarrow',arrowx,arrowy, 'TextEdgeColor','none', 'headwidth', 7, 'headlength', 7, 'String', {['w_c=', num2str(w_c(i))]});
    
    figure(2); hold on;
    plot(w_bw(i), -3, 'k.', 'MarkerSize', 15);
    axx=[60 60+i*10];
    axy=[-10*i 0];
    [arrowx,arrowy] = dsxy2figxy(gca, axx, axy);
    annotation('textarrow',arrowx,arrowy, 'TextEdgeColor','none', 'headwidth', 7, 'headlength', 7, 'String', {['w_{bw}=', num2str(w_bw(i))]});
end


