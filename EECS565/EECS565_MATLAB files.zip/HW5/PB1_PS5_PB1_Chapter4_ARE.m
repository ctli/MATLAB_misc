% this m-file solves the scalar Riccati differential equation over
% the time interval [t0,T]. The terminal value of the cost is
% assumed equal to zero.

clear all
close all
clc
format compact

A = 0.5; 
B = 1;
Q = 1; 
R = 0.1;
t0 = 0;

L2 = B*2/R;

% coefficients of Riccati equation
ARE = [-B^2*R^-1, 2*A, Q];
Pboth =roots(ARE);
Pboth = sort(Pboth, 'ascend'); % sort roots of ARE so that P1 > 0, P2 < 0
P1 = Pboth(1)
P2 = Pboth(2)

% vector of terminal time, T
T=[1 5 10 20];

figure(1); clf;
for i = 1:length(T)
    t = linspace(t0,T(i),1000);
    num = P1*P2*(exp((P1-P2)*L2*(T(i)-t))-1);
    den = -P1+P2*exp((P1-P2)*L2*(T(i)-t));
    P = num./den;
    K = (B/R)*num./den;
    plot(t,P,'k-',t,K,'k:');
    hold on;
end
title(['$$t_0 = 0,  T = [$$',num2str(T),'$$], P_{1,2} = $$',num2str([P1 P2])], 'interpreter','latex');
xlabel('Time [sec]', 'interpreter','latex');
h = legend('P','K',0);
set(h,'interpreter','latex');
set(gca, 'position', [0.13 0.13 0.775 0.78]);
defaultratio_ppt;


