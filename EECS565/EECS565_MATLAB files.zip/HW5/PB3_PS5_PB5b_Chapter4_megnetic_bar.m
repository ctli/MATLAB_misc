% magnetic bar
clear all
close all
clc
format compact

% Plant
A = [0 1 0 0;
     2 0 0 0;
     0 0 0 1;
     0 0 6 0];
B = [0 0;
    -2 -2;
     0 0;
    -1 1];
C = [1 0 6 0;
     1 0 -6 0];  % y1 and y2 as outputs
D = [0 0;
     0 0];
C_z = [1 0 0 0;
       0 0 1 0]; % h and theta as outputs 

% weighting matrices Q and R, and a time vector
% the time vector used for the simulations may need to
% be changed depending on the response speed of the system
Q = [150 0 0 0;
     0 1 0 0;
     0 0 500 0;
     0 0 0 1];
R = eye(size(B,2));
t = linspace(0,3,50); 

% compute optimal state feedback gain
K = lqr(A,B,Q,R)

% compute precompensator allowing us to command height and theta separately
Py0 = C*((-A+B*K)^(-1))*B;
Pz0 = C_z*((-A+B*K)^(-1))*B;
G = (Pz0^-1);

% print out closed loop eigenvalue locations
format short e
closed_loop_evalues = eig(A-B*K)

% NOTE: use the following syntax for the step command: x = step(a,b,c,d,1,t);
% where (a,b,c,d) is the state space representation of the system whose
% response you want to plot, t is a vector of time values at which you 
% wish to evaluate the response, and "1" is the first input. (use "2" to
% plot the response to the 2nd input)
% choose c to be the identity matrix, so that the vector x contains all
% the states of the system.
figure(1); clf;
set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 6.67, 2.8]);

% calculate response of the state vector to a step command in height
x = step(A-B*K,B*G,eye(4),0,1,t);
subplot(1,2,1);
plot(t,x(:,1),'k-', 'linewidth', 2); hold on;
plot(t,x(:,2),'k-', 'color', [0.7 0.7 0.7]);
plot(t,x(:,3),'k-', 'color', [0.7 0.7 0.7], 'linewidth', 2);
plot(t,x(:,4),'k:');
title('step command to height', 'interpreter','latex');
xlabel('time,seconds','interpreter','latex');
set(legend('$h$','$dh/dt$','$\theta$','$d\theta/dt$'),'interpreter','latex');
set(gca, 'position', [0.07 0.17 0.4 0.72]);
line([t(1) t(end)], [.9 .9], 'color', [0.7 0.7 0.7]);
line([t(1) t(end)], [1.05 1.05], 'color', [0.7 0.7 0.7]);
line([0.5 0.5], get(gca, 'ylim'), 'color', [0.7 0.7 0.7]);

% calculate response of the state vector to a step command in angle
x = step(A-B*K,B*G,eye(4),zeros(4,4),2,t);
subplot(1,2,2);
plot(t,x(:,1),'k-', 'linewidth', 2); hold on;
plot(t,x(:,2),'k-', 'color', [0.7 0.7 0.7]);
plot(t,x(:,3),'k-', 'color', [0.7 0.7 0.7], 'linewidth', 2);
plot(t,x(:,4),'k:');
title('step command to angle', 'interpreter','latex');
xlabel('time,seconds','interpreter','latex');
set(legend('$h$','$dh/dt$','$\theta$','$d\theta/dt$'),'interpreter','latex');
line([t(1) t(end)], [.9 .9], 'color', [0.7 0.7 0.7]);
line([t(1) t(end)], [1.05 1.05], 'color', [0.7 0.7 0.7]);
line([0.5 0.5], get(gca, 'ylim'), 'color', [0.7 0.7 0.7]);
set(gca, 'position', [0.57 0.17 0.4 0.72]);

