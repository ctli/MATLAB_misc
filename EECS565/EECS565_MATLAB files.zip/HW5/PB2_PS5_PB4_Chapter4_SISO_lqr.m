clear all
close all
clc
format compact

A = 1;
B= 1;
C= 1;

Q= [1 10 100];
R= 1;

w = logspace(-1,2,200);
s = tf('s');

t = linspace(0,3,100);

for i = 1:length(Q)
    K = lqr(A,B,Q(i),R);
    G = (C*((-A+B*K)^-1)*B)^-1;
    
    Try = sqrt(A^2+Q(i)*(B^2)/R)/(s+sqrt(A^2+Q(i)*(B^2)/R))
    [mag_Try(i,:),phase_Try(i,:)] = bode(Try,w);
    y(i,:) = step(Try, t);
    
    Tru = (s-A)*sqrt(A^2+Q(i)*(B^2)/R)/(B*C*(s+sqrt(A^2+Q(i)*(B^2)/R)))
    [mag_Tru(i,:),phase_Tru(i,:)] = bode(Tru,w);
    u(i,:) = step(Tru, t);
    
    disp('========================');
end


%% ================================================================== %%
figure(1); clf;
set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 6.67, 2.8]);

subplot(1,2,1); %Try
loglog(w,mag_Try(1,:),'k-',w,mag_Try(2,:),'k--',w,mag_Try(3,:),'k-.')
title('CL transfer function $T_{r\rightarrow y}$','interpreter','latex');
xlabel('$\omega$, rad/sec','interpreter','latex');
set(legend('$Q/R=1$','$Q/R=10$','$Q/R=100$',3),'interpreter','latex');
set(gca, 'position', [0.07 0.17 0.4 0.72]);

subplot(1,2,2); %Tru
loglog(w,mag_Tru(1,:),'k-',w,mag_Tru(2,:),'k--',w,mag_Tru(3,:),'k-.')
title('CL transfer function $T_{r\rightarrow u}$','interpreter','latex');
xlabel('$\omega$, rad/sec','interpreter','latex');
set(legend('$Q/R=1$','$Q/R=10$','$Q/R=100$',2),'interpreter','latex');
set(gca, 'position', [0.57 0.17 0.4 0.72]);

%% ================================================================== %%
figure(2); clf;
set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 6.67, 2.8]);

subplot(1,2,1); %y
plot(t,y(1,:),'k-',t,y(2,:),'k--',t,y(3,:),'k-.');
xlabel('time, seconds','interpreter','latex');
title('step response of output, $y$','interpreter','latex');
set(legend('$y, Q/R=1$','$y, Q/R=10$','$y, Q/R=100$',4),'interpreter','latex');
set(gca, 'position', [0.07 0.17 0.4 0.72]);

subplot(1,2,2); %u
plot(t,u(1,:),'k-',t,u(2,:),'k--',t,u(3,:),'k-.');
ylim([-2 8]);
xlabel('time, seconds','interpreter','latex');
title('step response of control, $u$','interpreter','latex');
set(legend('$u, Q/R=1$','$u, Q/R=10$','$u, Q/R=100$'),'interpreter','latex');
set(gca, 'position', [0.57 0.17 0.4 0.72]);

