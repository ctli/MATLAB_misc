% magnetic bar
clear all
close all
clc
format compact

% Plant
A = [0 1 0 0;
     2 0 0 0;
     0 0 0 1;
     0 0 6 0];
B = [0 0;
    -2 -2;
     0 0;
    -1 1];
C = [1 0 6 0;
     1 0 -6 0];  % y1 and y2 as outputs
C_z = [1 0 0 0;
       0 0 1 0]; % h and theta as outputs 

% weighting matrices Q and R
Q = [150 0 0 0;
     0 1 0 0;
     0 0 500 0;
     0 0 0 1];
R = eye(size(B,2));

% Plant augmented with integrators
n = size(A,1);
p = size(B,2);
q = size(C,1);

Aaug = [A, zeros(n,q)
        C, zeros(q,q)];
Baug = [B;
        zeros(q,q)];
Caug = [C zeros(q,q)];
Daug = zeros(q,q);

%  transformation matrix from states [h;theta] to outputs [y1;y2]
H = [1 6;
     1 -6];
Qx = [2000 0;
      0 5500]*10;
Qy = (H^-1)'*Qx*H^-1;

% weighting matrices
Qaug = [Q,    zeros(n,q);
      zeros(q,n), Qy];

% compute the optimal state feedback
Kaug = lqr(Aaug,Baug,Qaug,R);
K = Kaug(:,1:n);
Kw = Kaug(:,n+1:n+q);

% print out closed loop eigenvalues
format short e
closed_loop_evalues = eig(Aaug-Baug*Kaug)

% closed loop equations
Acl = [A-B*K, -B*Kw;
         C,     zeros(q,q)];
Bcl = [zeros(n,q);
      -eye(q)*H];
Ccl = eye(n+q);%[eye(n) zeros(n,q)];
Dcl = zeros(n+q,p);

t = linspace(0, 3, 100);

figure(1); clf;
set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 6.67, 2.8]);

% step command to h
x = step(Acl,Bcl,Ccl,Dcl,1,t);
subplot(1,2,1);
plot(t,x(:,1),'k-', 'linewidth', 2); hold on;
plot(t,x(:,2),'k-', 'color', [0.7 0.7 0.7]);
plot(t,x(:,3),'k-', 'color', [0.7 0.7 0.7], 'linewidth', 2);
plot(t,x(:,4),'k:');
title('step command to height', 'interpreter','latex');
xlabel('time,seconds','interpreter','latex');
set(legend('$h$','$dh/dt$','$\theta$','$d\theta/dt$'),'interpreter','latex');
set(gca, 'position', [0.07 0.17 0.4 0.72]);
line([t(1) t(end)], [.9 .9], 'color', [0.7 0.7 0.7]);
line([t(1) t(end)], [1.05 1.05], 'color', [0.7 0.7 0.7]);
line([0.5 0.5], get(gca, 'ylim'), 'color', [0.7 0.7 0.7]);

% step command to theta
x = step(Acl,Bcl,Ccl,Dcl,2,t);
subplot(1,2,2);
plot(t,x(:,1),'k-', 'linewidth', 2); hold on;
plot(t,x(:,2),'k-', 'color', [0.7 0.7 0.7]);
plot(t,x(:,3),'k-', 'color', [0.7 0.7 0.7], 'linewidth', 2);
plot(t,x(:,4),'k:');
title('step command to angle', 'interpreter','latex');
xlabel('time,seconds','interpreter','latex');
set(legend('$h$','$dh/dt$','$\theta$','$d\theta/dt$'),'interpreter','latex');
set(gca, 'position', [0.57 0.17 0.4 0.72]);
line([t(1) t(end)], [.9 .9], 'color', [0.7 0.7 0.7]);
line([t(1) t(end)], [1.05 1.05], 'color', [0.7 0.7 0.7]);
line([0.5 0.5], get(gca, 'ylim'), 'color', [0.7 0.7 0.7]);

% step disturbance, w = 1.0, d = 1.0
d=1;
E = [0;
    0.5;
     0;
    d/24];
m = size(E,2); % #disturbance states

Bcl_new = [zeros(n,q), E
         -eye(q)*H, zeros(p,m)];
Dcl_new = zeros(n+q,p+m);

figure(2); clf;
set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 6.67, 2.8]);

% response to step disturbance
x = step(Acl,Bcl_new,Ccl,Dcl_new,3,t); %[y,x,t] = step(Acl,Bcl_w,Ccl,Dcl_new,3,t);
subplot(1,2,1);
plot(t,x(:,1),'k-', 'linewidth', 2); hold on;
plot(t,x(:,2),'k-', 'color', [0.7 0.7 0.7]);
plot(t,x(:,3),'k-', 'color', [0.7 0.7 0.7], 'linewidth', 2);
plot(t,x(:,4),'k:');
title('plant states, step disturbance', 'interpreter','latex');
xlabel('time,seconds','interpreter','latex');
set(legend('$h$','$dh/dt$','$\theta$','$d\theta/dt$'),'interpreter','latex');
set(gca, 'position', [0.07 0.17 0.4 0.72]);

subplot(1,2,2);
plot(t,x(:,5),'k-',t,x(:,6),'k--')
title('integrator states, step disturbance', 'interpreter','latex');
xlabel('time, seconds', 'interpreter','latex');
set(legend('$w_1$','$w_2$',0),'interpreter','latex');
set(gca, 'position', [0.57 0.17 0.4 0.72]);


% % steady state value of the state vector for a unit step disturbance 
% xaug_ss = 

