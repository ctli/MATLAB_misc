clear all;
close all;
clc;
format compact;
format short e;

% parameters that define the plant
m=0.5;  % pendulum mass
M=0.5;  % cart mass
g=10;   % gravitational constant
L = 1;  % pendulum length

% state description of the plant
A =  [0 1 0 0;
      0 0 -m*g/M 0;
      0 0 0 1;
      0 0 (M+m)*g/(M*L) 0];
B =  [0;
     1/M;
     0 ;
     -1/(M*L)];
D =  0;

C =  [1 0 0 0]; % P_y_u
% C =  [0 0 1 0]; % P_theta_u

P = ss(A,B,C,D);

%% ===================================================================== %%
% pole-zero constellation of the plant
figure(1); clf;
pzmap(P);
title('Pole-Zero Map of P_{yu}')
axis equal
set(gca, 'xtick', -5:1:5, 'ytick', -4:1:4);
defaultratio_ppt;

% %% ===================================================================== %%
% % bode plot of the plant
% w = logspace(-2,2,200);
% [mag,phase] = bode(P,w);
% mag = squeeze(mag);phase = squeeze(phase);
% 
% figure(2);clf;
% subplot(2,1,1)
% loglog(w,mag)
% ylabel('magnitude')
% title('Bode plots, inverted pendulum')
% subplot(2,1,2)
% semilogx(w,phase)
% ylabel('phase, degrees')
% 
% %% ===================================================================== %%
% % Nyquist plot of the plant 
% [re,im] = nyquist(P,w);
% re = squeeze(re);im = squeeze(im);
% 
% figure(3); clf;
% plot(re,im,'-',re,-im,'--');
% title('Nyquist plot of inverted pendulum');
% xlabel('real');
% ylabel('imaginary');
% axis([-5 5 -5 5]);
% 
% %% ===================================================================== %%
% % positive and negative root loci of the plant
% figure(4); clf;
% rlocus(P);
% title('root locus of P for k>0');
% axis([-5 5 -5 5])
% 	
% figure(5); clf;
% rlocus(-P);
% title('root locus of P for k<0');
% axis([-5 5 -5 5])

%% ===================================================================== %%
% design controller with position feedback only
% desired state feedback and observer eigenvalues
psf = [-1+1i -1-1i -5 -6];
pobs = 2*psf;

% state feedback and observer gains (use the "place" command)
K = place(A,B,psf)
L = place(A',C',pobs)'


%% ===================================================================== %%
% state space description of compensator with one measurement
A_C1 = A-B*K-L*C;
B_C1 = L;
C_C1 = K;
D_C1 = 0;
Cobs1 = ss(A_C1,B_C1,C_C1,D_C1);

% s = tf('s');
% Cobs1_tf = minreal(C_C1*(s*eye(4)-A_C1)^(-1)*B_C1);

% observer = reg(ss(A,B,C,[0]),K,L);
% Cobs2 = feedback(ss(A,B,C,[0]), observer, +1); % Positive feedback!

% check poles of compensator to see if they are stable
compensator_poles = eig(A_C1)


%% ===================================================================== %%
% open loop, sensitivity, and comp. sensitivity functions
Lobs1 = Cobs1*P;
T1 = Lobs1/(1+Lobs1);
T1 = minreal(T1);
S1 = 1/(1+Lobs1);

% Root locus of the open loop L
figure(6); clf;
rlocus(Lobs1)
axis([-3  15 -10 10])
title('detail of root locus of L = C*P')

% Bode plot of the open loop L, and phase margin & gain margin
figure(7); clf;
margin(Lobs1);

% Nyquist plot
figure(8); clf;
[re,im] = nyquist(Lobs1);
re = squeeze(re);
im = squeeze(im);

set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 6.67, 2.8]);

subplot(1,2,1);
plot(re,im,'k-',re,-im,'k--');
hold on;
line([-100 100], [0 0], 'color', [0.5 0.5 0.5], 'linestyle', ':');
line([0 0], [-100 100], 'color', [0.5 0.5 0.5], 'linestyle', ':');
axis([-80 20  -4 4])
xlabel('Real Axis');
ylabel('Imaginary Axis');
title('Nyquist Plot of L, Position Feedback Only')
set(gca, 'position', [0.07 0.15 0.38 0.7]);

subplot(1,2,2);
plot(re,im,'k-',re,-im,'k--');
hold on;
line([-100 100], [0 0], 'color', [0.5 0.5 0.5], 'linestyle', ':');
line([0 0], [-100 100], 'color', [0.5 0.5 0.5], 'linestyle', ':');
axis([-1.5 0.1 -0.5  0.5]);
xlabel('Real Axis');
ylabel('Imaginary Axis');
title('Detailed Nyquist Plot')
set(gca, 'position', [0.58 0.15 0.38 0.7]);


% Bode plot of the sensitivity function 
w = logspace(-2,2,200);
[mS1,pS1] = bode(S1,w);
mS1 = squeeze(mS1);
pS1 = squeeze(pS1);
figure(10); clf;
loglog(w,mS1, 'k')
%grid
xlabel('\omega, rad/sec')
ylabel('magnitude')
title('Sensitivity function, |S(j\omega)|, Position Feedback Only')
defaultratio_ppt;

max(mS1)

%% ===================================================================== %%
% add a precompensator to achieve steady state tracking
% and plot both pendulum angle and cart position 
% need to change the C and D matrices to provide both outputs
Cboth = [1 0 0 0;
         0 0 1 0];
Dboth = zeros(2,1);
L = [L, zeros(size(L))];

% closed loop system that maps the reference through the precompensator and
% the system with state feedback
Ar_obs = [A -B*K
          L*Cboth A-B*K-L*Cboth];
Br_obs = [B
          B];
Cr_obs = [Cboth, zeros(size(Cboth))];
Dr_obs = Dboth;

Tsf = ss(Ar_obs,Br_obs,Cr_obs,Dr_obs);

% normalize the cart position by its dc_gain, so step response has zero
% tracking error
dc_gain = dcgain(Tsf);
G = 1/dc_gain(1);
TsfG = Tsf*G;

t = linspace(0,6);
y = step(TsfG,t);

figure(11); clf;
subplot(2,1,1)
plot(t,y(:,1), 'k')
ylabel('distance')
title('Cart Position, Cart Feedback Only')
ylim([-0.2 1.2]);
grid on;
subplot(2,1,2)
plot(t,y(:,2), 'k')
title('Pendulum Angle, Cart Feedback Only')
ylabel('radians')
xlabel('time, seconds')
grid on;
defaultratio_ppt;

%% ===================================================================== %%
% Non-minimum phase
% % plot out the phase lag due to a NMP zero at s = 1
% num = [-1 1];
% den = [1 1];
% [mag,phase] = bode(num,den,w);
% figure(12); clf;
% semilogx(w,phase)
% ylabel('phase, degrees')
% xlabel('frequency, rad/sec')
% title('phase lag of allpass  (1-s)/(1+s)')
% grid
% 
% % plot the phase lag of the system 1/(s+1) with and without an additional
% % NMP zero added w/o changing the gain
% num_MP = 1;den_MP = [1 1];
% num_NMP = [-1 1];den_NMP = [1 1];
% [mag_MP,phase_MP] = bode(num_MP,den_MP,w);
% [mag_NMP,phase_NMP] = bode(num_NMP,den_NMP,w);
% figure(13); clf;	
% subplot(2,1,1)
% loglog(w,mag_MP,'-',w,mag_NMP,'-.')
% ylabel('magnitude')
% title('Bode plots of 1/(1+s) and (1-s)/(1+s)')
% subplot(2,1,2)
% semilogx(w,phase_MP,'-',w,phase_NMP,'-.')
% ylabel('phase')
% xlabel('\omega, rad/sec')
% legend('MP','NMP',3)


%% ===================================================================== %%
% response to an input disturbance

% with state feedback, w/o observer (same as Try)
Ad_sf = A-B*K;
Bd_sf = B;
Cd_sf = Cboth;
Dd_sf = Dboth;
Td_sf = ss(Ad_sf,Bd_sf,Cd_sf,Dd_sf);
% dc_gain = dcgain(Td_sf);
% Td_sf = Td_sf/dc_gain(1);
ysf_dist = step(Td_sf,t);

% with state feedback, with observer
Ad_obs = [A -B*K
          L*Cboth A-B*K-L*Cboth];
Bd_obs = [B
          zeros(size(B))];
Cd_obs = [Cboth, zeros(size(Cboth))];
Dd_obs = Dboth;
Td_obs = ss(Ad_obs,Bd_obs,Cd_obs,Dd_obs);
% dc_gain = dcgain(Td_obs);
% Td_obs = Td_obs/dc_gain(1);
yobs_dist = step(Td_obs,t); 

figure(14); clf;
subplot(2,1,1)
plot(t,ysf_dist(:,1),'k-',t,yobs_dist(:,1),'k--')
title('Cart Position to Step Disturbance')
ylabel('position')
grid
ylim([-10 20]);
subplot(2,1,2)
plot(t,ysf_dist(:,2),'k-',t,yobs_dist(:,2),'k--')
title('Pendulum Angle to Step Disturbance')
ylabel('radians')
xlabel('time, seconds')
grid;
legend('state feedback w/o observr', 'state feedback w/ observer')
set(gcf,'Units', 'inches');
set(gcf, 'Position', [2, 2, 4, 3.2708]);

%% ===================================================================== %%
% now use both measurements for feedback into the observer
 
% compute state feedback and observer gains
% note that TWO outputs must fed into the observer
K = place(A,B,psf);
L = place(A',Cboth',pobs)';

% state space of Cobs2, the observer based compensator with both outputs
A_C2 = A-B*K-L*Cboth;
B_C2 = L;
C_C2 = K;
D_C2 = 0;
Cobs2 = ss(A_C2,B_C2,C_C2,D_C2);

% state space of the scalar open loop and sensitivity functions
% obtained at the plant input. 
% L = Cobs2*Pboth, where Pboth is the SITO plant with two outputs (cart and
% pendulum)
Pboth = ss(A,B,Cboth,Dboth);

Lobs2 =  Cobs2*Pboth;
Sobs2 = 1/(1+Lobs2);
 

% Bode plot of the open loop at the plant input
figure(15); clf;
margin(Lobs2);
defaultratio_ppt;

% Nyquist plot at the plant input
figure(16); clf;
[re,im] = nyquist(Lobs2,w);
re = squeeze(re);
im = squeeze(im);

set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 6.67, 2.8]);

subplot(1,2,1);
plot(re,im,'k-',re,-im,'k--');
hold on;
line([-100 100], [0 0], 'color', [0.5 0.5 0.5], 'linestyle', ':');
line([0 0], [-100 100], 'color', [0.5 0.5 0.5], 'linestyle', ':');
axis([-10 50  -4 4])
axis([-80 20  -4 4])
xlabel('Real Axis');
ylabel('Imaginary Axis');
title('Nyquist Plot of L, Two measurements')
set(gca, 'position', [0.07 0.15 0.38 0.7]);

subplot(1,2,2);
plot(re,im,'k-',re,-im,'k--');
hold on;
line([-100 100], [0 0], 'color', [0.5 0.5 0.5], 'linestyle', ':');
line([0 0], [-100 100], 'color', [0.5 0.5 0.5], 'linestyle', ':');
axis([-1.5 0.1 -0.5  0.5]);
xlabel('Real Axis');
ylabel('Imaginary Axis');
title('Detailed Nyquist Plot')
set(gca, 'position', [0.58 0.15 0.38 0.7]);


% sensitivity functions at the plant input, with 1 and 2 measurements
[mS2,pS2] = bode(Sobs2,w);
mS2 = squeeze(mS2);pS2 = squeeze(pS2);

figure(17); clf;
loglog(w,mS2,'k-',w,mS1,'k--')  
axis([.01 100 .01 100])
legend('2 measurements','1 measurement',4)
xlabel('\omega, rad/sec')
title('sensitivity functions')
defaultratio_ppt;
