% symb_model_inv_pend_cart.m
%
clear *
%
% This is for the EECS 562 project of an inverted pendulum on a cart
%
syms s phi ds dphi real
syms g L m M J real
%
% reference = absolute angle for the pendulum, measured clockwise from the vertical
% referebce = position of cart measured from left to right
%
q=[phi s].';
dq=[dphi ds].';
%
% 
pcart=[s;0];
ppend_centermass=pcart+L*[sin(phi);cos(phi)];
%
%
vcart =  jacobian(pcart,q)*dq;
vpend_centermass = jacobian(ppend_centermass,q)*dq;
%
%
KEcart = simplify(M*(1/2)*vcart.'*vcart)
KEpend_centermass = simplify(m*(1/2)*vpend_centermass.'*vpend_centermass)
KErotation=simplify(J*(1/2)*(dphi)^2)
%
%
KE = (KEcart+KEpend_centermass+KErotation);
KE = simple(KE)
%
%
%
PE = g*m*ppend_centermass(2);
PE = simple(PE);
%
%
% Model NOTATION: Spong and Vidyasagar, page 142, Eq. (6.3.12)
%                 D(q)ddq + C(q,dq)*dq + G(q) = B*tau
%
L=KE-PE;

G=jacobian(PE,q).';
G=simple(G);
D=simple(jacobian(KE,dq).');
D=simple(jacobian(D,dq));

syms C real
n=max(size(q));
for k=1:n
   for j=1:n
      C(k,j)=0*g;
      for i=1:n
         C(k,j)=C(k,j)+(1/2)*(diff(D(k,j),q(i))+diff(D(k,i),q(j))-diff(D(i,j),q(k)))*dq(i);
      end
   end
end
C=simple(C);
%
% Compute the matrix for the input force
%
B=[0;1];
%
%
% Compute D^{-1} 
% 
d=simple(det(D));
DI=inv(D);
DI=simple(DI);
%
%
% compute RHS of model in the form ddq = f + g mu
f=DI*(-C*dq-G); f=simple(f)
g=DI*B; g=simple(g)
pretty(f(1))
pretty(f(2))
pretty(g(1))
pretty(g(2))
save work_symb_model_inv_pend_cart
return

