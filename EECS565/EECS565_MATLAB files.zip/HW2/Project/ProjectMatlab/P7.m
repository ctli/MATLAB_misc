%% Project, Pb7
clear all; 
%close all; clc;
global A B b c d K L

%% ================================================================ %%
% state: x = [phi dphi sbar dsbar]
A = [0 1 0 0;
     1 0 0 0;
     0 0 0 1;
    -1 0 0 0];

B = [0 -1 0 3]';

C = [1 0 0 0;
     0 0 1 0];

b = 3;
c = 1/40;
d = 1 + c;

p = [-3 -2 -0.7+0.2j -0.7-0.2j];

K = place(A,B,p)
L = place(A',C',30*p)


%% ================================================================ %%
tspan = linspace(0,10, 200);

x0 = [0.238 0 0 0];
[y_linear, t, x] = initial(ss(A-B*K, B, eye(4), [0]), x0, tspan);
[t,y_nonlinear] = ode45('fun_nonlinear', tspan, x0);

x0_obs = [x0 zeros(1,4)];
observer = reg(ss(A,B,C,[0]),K,L');
observerNfeedback = feedback(ss(A,B,C,[0]), observer, +1);

[y_linear_obs, t, x] = initial(observerNfeedback, x0_obs, tspan);
[t,y_nonlinear_linearObs] = ode45('fun_nonlinear_linearObs', tspan, x0_obs);

figure(2)
subplot(2,1,1);
% Static controller
plot(t, y_linear(:,1), 'Color', [0.5 0.5 0.5]); hold on;
plot(t, y_nonlinear(:,1), '-.k');
% Dynamic controller
plot(t, y_linear_obs(:,1), 'Color', [0.5 0.5 0.5], 'LineWidth', 2); hold on;
plot(t, y_nonlinear_linearObs(:,1), '-.k', 'LineWidth', 2);
ylabel('y_1 (\Phi)', 'FontSize', 12);
set(gca, 'FontSize', 12);
legend('Linear      (sta. ctrler)', ...
       'Nonlinear (sta. ctrler)', ...
       'Linear      (dyn. ctrler)', ...
       'Nonlinear (dyn. ctrler)');
title('I.C.: x0 = [0 0 0.2 0]', 'FontSize', 12);

subplot(2,1,2);
% Static controller
plot(t, y_linear(:,1), 'Color', [0.5 0.5 0.5]); hold on;
plot(t, y_nonlinear(:,1), '-.k');
% Dynamic controller
plot(t, y_linear_obs(:,2), 'Color', [0.5 0.5 0.5], 'LineWidth', 2);
plot(t, y_nonlinear_linearObs(:,2), '-.k', 'LineWidth', 2);
ylabel('y_2 (sbar)', 'FontSize', 12);
xlabel('Time', 'FontSize', 12);
set(gca, 'FontSize', 12);

% %% ================================================================ %%
% % Problem 8
% tspan = linspace(0,10, 200);
% x0_obs = [x0 zeros(1,4)];
% 
% [t,y_nonlinear_nonlinearObs] = ode45('fun_nonlinear_nonlinearObs', tspan, x0_obs);
% 
% figure(3)
% subplot(2,1,1);
% plot(t, y_nonlinear_linearObs(:,1), 'Color', [0.5 0.5 0.5], 'LineWidth', 2); hold on;
% plot(t, y_nonlinear_nonlinearObs(:,1), '-.k', 'LineWidth', 2);
% ylabel('y_1 (\Phi)', 'FontSize', 12);
% 
% subplot(2,1,2);
% plot(t, y_nonlinear_linearObs(:,2), 'Color', [0.5 0.5 0.5], 'LineWidth', 2); hold on;
% plot(t, y_nonlinear_nonlinearObs(:,2), '-.k', 'LineWidth', 1);
% ylabel('y_2 (sbar)', 'FontSize', 12);
% xlabel('Time', 'FontSize', 12);
% set(gca, 'FontSize', 12);

