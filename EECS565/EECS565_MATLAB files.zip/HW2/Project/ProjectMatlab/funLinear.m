function [dx] = funLinear(t,x)

global A B K
dx = (A + B*K)*x;

end