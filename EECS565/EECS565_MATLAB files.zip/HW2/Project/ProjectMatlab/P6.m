%% Project, Pb6
clear all; close all; clc;
global A B b c d K L

%% ================================================================ %%
% state: x = [phi dphi sbar dsbar]
A = [0 1 0 0;
     1 0 0 0;
     0 0 0 1;
    -1 0 0 0];
B = [0 -1 0 3]';


%% ================================================================ %%
% Check controllability
p = [-3 -2 -0.7+0.2j -0.7-0.2j];
K = place(A,B,p)

% Pole placement
p = [-3 -2 -0.7+0.2j -0.7-0.2j];
K = place(A,B,p)


%% ================================================================ %%
% Check observability
C = [1 0 0 0;
     0 0 1 0];

obsv(A,C)
rank(obsv(A,C))

% Liner observer, 10 times faster than system poles
L = place(A',C',30*p)


