function [dx] = fun_nonliner(t,x)

global b c d K

dx = zeros(4,1);
dx(1) = x(2);
dx(2) = (-c*x(2)^2*sin(x(1))*cos(x(1))+sin(x(1))-cos(x(1))*(-K*x))/(1 + c*sin(x(1))^2);
dx(3) = x(4);
dx(4) = (d*x(2)^2*sin(x(1))-cos(x(1))*sin(x(1)) + b*(-K*x))/(1 + c*sin(x(1))^2);

end