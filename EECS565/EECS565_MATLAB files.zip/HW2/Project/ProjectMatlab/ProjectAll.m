%% Project, all
clear all; close all; clc;
global A B b c d K L

%% ================================================================ %%
% Problem 4
% state: x = [phi dphi sbar dsbar]
A = [0 1 0 0;
     1 0 0 0;
     0 0 0 1;
    -1 0 0 0];
B = [0 -1 0 3]';

b = 3;
c = 1/2;
d = 1 + c;

%% ================================================================ %%
% Check controllability
ctrb(A,B)
rank(ctrb(A,B))

p = [-3 -2 -0.7+0.2j -0.7-0.2j];
K = place(A,B,p)


%% ================================================================ %%
% Problem 5
tspan = linspace(0,10, 200);

x0 = [0.253 0 0 0];
[y_linear, t, x] = initial(ss(A-B*K, B, eye(4), [0]), x0, tspan);
[t,y_nonlinear] = ode45('fun_nonlinear', tspan, x0);


figure(1); clf;
subplot(4,1,1);
plot(t, y_linear(:,1), 'Color', [0.5 0.5 0.5]); hold on;
plot(t, y_nonlinear(:,1), '-.k'); hold on;
legend('Linear', 'Nonlinear');
ylabel('\Phi', 'FontSize', 12);
title('I.C.: x0 = [0 0 0 0.3]', 'FontSize', 12);

subplot(4,1,2);
plot(t, y_linear(:,2), 'Color', [0.5 0.5 0.5]); hold on;
plot(t, y_nonlinear(:,2), '-.k'); hold on;
ylabel('d\Phi', 'FontSize', 12);

subplot(4,1,3);
plot(t, y_linear(:,3), 'Color', [0.5 0.5 0.5]); hold on;
plot(t, y_nonlinear(:,3), '-.k'); hold on;
ylabel('s\_bar', 'FontSize', 12);

subplot(4,1,4);
plot(t, y_linear(:,4), 'Color', [0.5 0.5 0.5]); hold on;
plot(t, y_nonlinear(:,4), '-.k'); hold on;
xlabel('Time', 'FontSize', 12);
ylabel('ds\_bar', 'FontSize', 12);


%% ================================================================ %%
% Problem 6
C = [1 0 0 0;
     0 0 1 0];

obsv(A,C)
rank(obsv(A,C))

% Liner observer, 10 times faster than system poles
L = place(A',C',10*p)


%% ================================================================ %%
% Problem 7
tspan = linspace(0,10, 200);
x0 = [0.253 0 0 0];
x0_obs = [x0 zeros(1,4)];

observer = reg(ss(A,B,C,[0]),K,L');
observerNfeedback = feedback(ss(A,B,C,[0]), observer, +1); % Positive feedback!

[y_linear_obs, t, x] = initial(observerNfeedback, x0_obs, tspan);
[t,y_nonlinear_linearObs] = ode45('fun_nonlinear_linearObs', tspan, x0_obs);

figure(2)
subplot(2,1,1);
% L. Sys. + full state feedback (Problem 5)
plot(t, y_linear(:,1), ':', 'Color', [0.5 0.5 0.5]); hold on;
% NL. Sys. + full state feedback (Problem 5)
plot(t, y_nonlinear(:,1), 'Color', [0.5 0.5 0.5]); hold on;
% L. Sys. + L. Obs.
plot(t, y_linear_obs(:,1), '-.k');
% NL. Sys.+ L. Obs.
plot(t, y_nonlinear_linearObs(:,1), 'k');

ylabel('y_1 (\Phi)', 'FontSize', 12);
xlabel('Time', 'FontSize', 12);
set(gca, 'FontSize', 12);
legend('L. Sys. + full state feedback (prblem5)', ...
       'NL. Sys.+ full state feedback (prblem5)', ...
       'L. Sys. + L. Obs.', ...
       'NL. Sys.+ L. Obs.');

subplot(2,1,2);
% L. Sys. + full state feedback (Problem 5)
plot(t, y_linear(:,4), ':', 'Color', [0.5 0.5 0.5]); hold on;
% NL. Sys. + full state feedback (Problem 5)
plot(t, y_nonlinear(:,4), 'Color', [0.5 0.5 0.5]); hold on;
% L. Sys. + L. Obs.
plot(t, y_linear_obs(:,2), '-.k'); hold on;
% NL. Sys.+ L. Obs.
plot(t, y_nonlinear_linearObs(:,2), 'k');
ylabel('y_2 (sbar)', 'FontSize', 12);
xlabel('Time', 'FontSize', 12);
set(gca, 'FontSize', 12);


%% ================================================================ %%
% Problem 8
tspan = linspace(0,10, 200);
x0_obs = [x0 zeros(1,4)];

[t,y_nonlinear_nonlinearObs] = ode45('fun_nonlinear_nonlinearObs', tspan, x0_obs);

figure(3)
subplot(2,1,1);
plot(t, y_nonlinear_linearObs(:,1), 'Color', [0.5 0.5 0.5], 'LineWidth', 2); hold on;
plot(t, y_nonlinear_nonlinearObs(:,1), '-.k', 'LineWidth', 2);
ylabel('y_1 (\Phi)', 'FontSize', 12);

subplot(2,1,2);
plot(t, y_nonlinear_linearObs(:,2), 'Color', [0.5 0.5 0.5], 'LineWidth', 2); hold on;
plot(t, y_nonlinear_nonlinearObs(:,2), '-.k', 'LineWidth', 1);
ylabel('y_2 (sbar)', 'FontSize', 12);
xlabel('Time', 'FontSize', 12);
set(gca, 'FontSize', 12);
