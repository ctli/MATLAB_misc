%% Project, Pb5
clear all; close all; clc;
global A B b c d K L

%% ================================================================ %%
% state: x = [phi dphi sbar dsbar]
A = [0 1 0 0;
     1 0 0 0;
     0 0 0 1;
    -1 0 0 0];
B = [0 -1 0 3]';

b = 3;
c = 1/40;
d = 1 + c;

p = [-3 -2 -0.7+0.2j -0.7-0.2j];
K = place(A,B,p)


%% ================================================================ %%
tspan = linspace(0,10, 200);

x0 = [0.629 0 0 0];
[y_linear, t, x] = initial(ss(A-B*K, B, eye(4), [0]), x0, tspan);
[t,y_nonlinear] = ode45('fun_nonlinear', tspan, x0);


figure(1); clf;
subplot(4,1,1);
plot(t, y_linear(:,1), 'Color', [0.5 0.5 0.5]); hold on;
plot(t, y_nonlinear(:,1), '-.k'); hold on;
legend('Linear', 'Nonlinear');
ylabel('\Phi', 'FontSize', 12);
title('I.C.: x0 = [0 0 0 0.3]', 'FontSize', 12);

subplot(4,1,2);
plot(t, y_linear(:,2), 'Color', [0.5 0.5 0.5]); hold on;
plot(t, y_nonlinear(:,2), '-.k'); hold on;
ylabel('d\Phi', 'FontSize', 12);

subplot(4,1,3);
plot(t, y_linear(:,3), 'Color', [0.5 0.5 0.5]); hold on;
plot(t, y_nonlinear(:,3), '-.k'); hold on;
ylabel('s\_bar', 'FontSize', 12);

subplot(4,1,4);
plot(t, y_linear(:,4), 'Color', [0.5 0.5 0.5]); hold on;
plot(t, y_nonlinear(:,4), '-.k'); hold on;
xlabel('Time', 'FontSize', 12);
ylabel('ds\_bar', 'FontSize', 12);

