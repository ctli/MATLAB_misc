function [dx] = fun_nonlinear_nonlinearObs(t,x)

global A B b c d K L

% x = [system_states, observer_states]
dx = zeros(8,1);
dx(1) = x(2);
dx(2) = (-c*x(2)^2*sin(x(1))*cos(x(1)) + sin(x(1)) - cos(x(1))*(-K*x(5:8)))/(1 + c*sin(x(1))^2);
dx(3) = x(4);
dx(4) = (d*x(2)^2*sin(x(1)) - cos(x(1))*sin(x(1)) + b*(-K*x(5:8)))/(1 + c*sin(x(1))^2);

dx(5) = x(6) + [L(1,1) L(2,1)]*([x(1); x(3)] - [x(5); x(7)]);
dx(6) = (-c*x(6)^2*sin(x(5))*cos(x(5)) + sin(x(5)) - cos(x(5))*(-K*x(5:8)))/(1 + c*sin(x(1))^2) + [L(1,2) L(2,2)]*([x(1); x(3)] - [x(5); x(7)]);
dx(7) = x(8) + [L(1,3) L(2,3)]*([x(1); x(3)] - [x(5); x(7)]);
dx(8) = (d*x(2)^2*sin(x(1)) - cos(x(1))*sin(x(1)) + b*(-K*x(5:8)))/(1 + c*sin(x(1))^2) + [L(1,4) L(2,4)]*([x(1); x(3)] - [x(5); x(7)]);
end