%% Project, Pb3
clear all; close all; clc;
global A B b c d K L

%% ================================================================ %%
% state: x = [phi dphi sbar dsbar]
A = [0 1 0 0;
     1 0 0 0;
     0 0 0 1;
    -1 0 0 0];
B = [0 -1 0 3]';


%% ================================================================ %%
% Check controllability
ctrb(A,B)
rank(ctrb(A,B))

% Pole placement
p = [-3 -2 -0.7+0.2j -0.7-0.2j];
K = place(A,B,p)

