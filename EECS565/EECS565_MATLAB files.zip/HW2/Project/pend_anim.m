function pend_anim(t,x,theta,Ts);
%PEND_ANIM    Inverted pendulum animation.
%    PEND_ANIM(T,X,THETA,TS) is an animation of the inverted
%    pendulum.
%
%      T - time vector
%      X - cart position vector (green wedge is zero)
%      THETA - pendulum angle vector (with respect to normal)
%      TS - an optional animation scaling factor with default
%          .1; increase to speed animation
%
%    Run PEND_ANIM with no arguments for a demo.
%
%Eric Westervelt
%(ewesterv@umich.edu)
%1/17/01

if nargin < 4, Ts = .1; end
if nargin == 0, t = 0:.1:6*pi; x = 5*sin(t); theta = .5*cos(t); end

% check arguments
[nt,mt] = size(t); [nx,mx] = size(x); [nh,mh] = size(theta);

if ((nt ~=1) & (mt ~=1)), 
  error('first argument must all be a vector');
end
if ((nx ~=1) & (mx ~=1))
  error('second argument must all be a vector');
end
if ((nh ~=1) & (mh ~=1))
  error('third argument must all be a vector');
end

if nt < mt, t = t'; end
if nx < mx, x = x'; end
if nh < mh, theta = theta'; end

[t,tmp] = even_sample(t, [x theta], 1/Ts);
x = tmp(:,1);
theta = tmp(:,2);

% define constants
scl = 1;    % the sclaing for better visualization
cl  = 2;    % length of cart
ch  = 2;    % height of cart
br  = 0.5;  % radius of pendulum
pl  = 10;   % pendulum length

% set up figure window
xmax   = 20;
ymax   = 20;
ydepth = 10;
figure; clf
axis([-xmax xmax -ydepth ymax]); axis off

arrow = line([0 -1],[0 -1]);
set(arrow,'LineWidth',2,'Color','g');
arrow = line([0 1],[0 -1]);
set(arrow,'LineWidth',2,'Color','g');

ground = line([-xmax xmax],[0 0]);
set(ground,'Color',[0 0 0],'LineWidth',2);

x0 = 0;
xcart = [x0-cl/2 x0+cl/2 x0+cl/2 x0-cl/2];
ycart = [ch ch 0 0];
cartcolor = 'b';
cart = patch(xcart,ycart,cartcolor);

theta0 = 3/4*pi;
xpendulum = [x0 x0+(pl-br)*sin(theta0)];
ypendulum = [ch ch+(pl-br)*cos(theta0)];
pendulum = line(xpendulum,ypendulum);
set(pendulum,'Color',[0 0 0]);
param = linspace(0,2*pi+2*pi/50,50);
xbob = br*cos(param);
ybob = br*sin(param);
bob = patch(xbob+pl*sin(theta0),ch+ybob+pl*cos(theta0),'r');

% animate the system
for k = 1:length(t)
  % refresh cart
  x1 = scl*x(k);
  xcart = [x1-cl/2 x1+cl/2 x1+cl/2 x1-cl/2];
  ycart = [ch ch 0 0];
  set(cart,'XData',xcart,'YData',ycart);
  
  % refresh pendulum
  xpendulum = [x(k) x(k)+(pl-br)*sin(theta(k))];
  ypendulum = [ch  ch+(pl-br)*cos(theta(k))];
  set(pendulum,'XData',xpendulum,'YData',ypendulum);
  set(bob,'XData',x(k)+xbob+pl*sin(theta(k)),...
          'YData',ch+ybob+pl*cos(theta(k)));
  
  drawnow;
  pause(.001);
end

%---------------------------------------------------------------

function [Et, Ex] = even_sample(t, x, Fs);

% Obtain the process related parameters
N = size(x, 2);    % number of signals to be interpolated
M = size(t, 1);    % Number of samples provided
t0 = t(1,1);       % Initial time
tf = t(M,1);       % Final time
EM = (tf-t0)*Fs;   % Number of samples in the evenly sampled case with
                   % the specified sampling frequency
Et = linspace(t0, tf, EM)';

% Using cubic spline interpolation technique interpolate and
% re-sample each signal and obtain the evenly sampled signal.
for s = 1:N,
  Ex(:,s) = spline(t(:,1), x(:,s), Et(:,1)); 
end;