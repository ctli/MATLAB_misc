clear all;
close all;
clc;
format compact

s = tf('s');

% create plant
P = 1/(s*(s+1));
[A,B,C,D] = ssdata(P);

% place eigenvalues at desired locations
psf = [-2-2*sqrt(3)*1i -2+2*sqrt(3)*1i];
K = place(A,B,psf)
eig(A-B*K)

% evaluate step response of system with state feedback.
% the transfer function is Tsf = c(sI-a+b*k)^(-1)b
figure(1);
Tsf = C*(s*eye(2)-A+B*K)^(-1)*B;

% Normalize the system to achieve unity DC gain
dc_gain_sf = dcgain(Tsf);
Tsf = Tsf/dc_gain_sf

% step(Tsf, 'k')


%% ===================================================================== %%
% design observer
pobs = psf*5; % five times faster than controller poles
L = place(A',C',pobs).'
eig(A-L*C)


% evaluate the step response with the observer (should be same as without)
Abig = [A -B*K
        L*C A-B*K-L*C];
Bbig = [B;
        B];
Cbig = [C 0 0];
Dbig = 0;
Tobs = ss(Abig,Bbig,Cbig,Dbig);

%% Another method to construct observer:
% observer = reg(ss(A,B,C,D),K,L);
% Tobs = feedback(ss(A,B,C,0), observer, +1);

dc_gain_obs = dcgain(Tobs);
Tobs = Tobs/dc_gain_obs;

figure(1); clf;
set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 6.67, 2.8]);

subplot(1,2,1);
[y t] = step(Tobs);
plot(t, y, 'k');
hold on;
line([0 3], [1 1], 'color', 'k', 'linestyle', ':');
set(gca, 'ylim', [0 1.4], 'ytick', 0:0.2:1.4);
set(gca, 'position', [0.1 0.15 0.35 0.7]);
title('Step response with state feedback and oberserver');
xlabel('Time (sec)', 'Position', [1.5 -0.2]);
ylabel('Amplitude', 'Position', [-0.4 1.5/2]);


%% ===================================================================== %%
% check the poles and zeros of the transfer function from r to y
zeros_Tobs = tzero(Tobs);
poles_Tobs = pole(Tobs);

subplot(1,2,2);
pzmap(Tobs);
set(gca, 'position', [0.58 0.15 0.35 0.7]);


%% ===================================================================== %%
A_Cobs = A-B*K-L*C;
B_Cobs = L;
C_Cobs = K;
D_Cobs = 0;

Cobs = minreal(C_Cobs*(s*eye(2)-A_Cobs)^(-1)*B_Cobs);
% Alternative: Cobs = minreal(K*(s*eye(2)-A+B*K+L*C)^(-1)*L);

% check poles and zeros of observer based compensator
zeros_Cobs = tzero(Cobs)
poles_Cobs = pole(Cobs)

figure(5); clf;
pzmap(Cobs);
title('Pole-Zero Map of Cobs');
defaultratio_ppt;

% check bode plot of observer based compensator
w = logspace(-3,1000,100000);
[mag,phase] = bode(Cobs,w);
mag = squeeze(mag);
phase = squeeze(phase);
mag = 20*log10(mag);

figure(6); clf;
subplot(2,1,1);
semilogx(w,mag, 'k');
xlabel('frequency, rad/sec');
ylabel('magnitude, dB');
axis([10^-1 10^3 0 40]);
set(gca,'ytick', 0:10:40);
title('Bode plot of Cobs');

subplot(2,1,2);
semilogx(w,phase, 'k');
xlabel('frequency, rad/sec');
ylabel('phase,degrees');
axis([10^-1 10^3 -90 45]);
set(gca,'ytick', -90:45:45);

defaultratio_ppt('old axis');

figure(7); clf;
Lobs = P*Cobs;
rlocus(Lobs);
hold on
plot(psf,'*');
axis equal
axis([-25 25 -25 25]);
set(gca,'fontsize',10);

defaultratio_ppt;


% ===================================================================== %%
% find a reduced order observer 
% use a realization of P with C = [1 0]
Ar = [-1 1;0 0];
Br = [0; 1];
Cr = [1 0];
Dr = 0;

A11 = Ar(1,1);A12 = Ar(1,2); A21 = Ar(2,1);A22 = Ar(2,2);
B1 = Br(1);B2 = Br(2);
Kr = place(Ar,Br,psf);
K1 = Kr(1);K2 = Kr(2);
pobsr = -5; % a rather arbitrary location
Lr  = place(A22,A12,pobsr);

Aroo = [A22-Lr*A12-(B2-Lr*B1)*K2];
Broo = (A22-Lr*A12)*Lr+(A21-Lr*A11)-(B2-Lr*B1)*(K1+K2*Lr);
Croo = K2;
Droo = (K1+K2*Lr);
Cobsr = ss(Aroo,Broo,Croo,Droo);

figure(8); clf;
[mag,phase] = bode(Cobsr,w);
mag = squeeze(mag);
phase = squeeze(phase);
mag = 20*log10(mag);
subplot(2,1,1);
semilogx(w,mag, 'k');
xlabel('frequency, rad/sec');
ylabel('magnitude, dB');
axis([10^-1 10^3 20 30]);
set(gca,'ytick', 0:10:40);
title('Bode plot of the reduced observer');
subplot(2,1,2);
semilogx(w,phase, 'k');
xlabel('frequency, rad/sec');
ylabel('phase,degrees');
axis([10^-1 10^3 0 30]);

% figure(9); clf; 
% Lobsr = P*Cobsr;
% rlocus(Lobsr)
% hold on
% plot(psf,'*')
% hold off
% title('root locus, with reduced order observer');
% defaultratio_ppt;

