clear all
close all
clc
format compact


w = logspace(-1,1,100);
s = tf('s');
 
% Plant in engineering coordinates

% [F]/Power
P11 = (0.17*s+0.7)/(s^2 + 15*s + 26.7);

% Vbias/Power
P21 = 0.28/(s + 0.97);
 
% use a 2nd order Pade approximation (probably overkill) to 
% approximate the throttle delay -- use the Matlab "Pade" command
[ndelay,ddelay] = pade(0.5,2);
delay_sys = tf(ndelay,ddelay);

% [F]/Throttle
P12 = -0.17/(s + 0.24);
 
% Vbias/Throttle
P22 = (2.41*s + 9.75)/(s^2 + 4*s + 0.7);
 
P = [P11 P12;P21 P22]*[1 0;0 delay_sys];

%% ================================================================== %%
% Input scalings, based upon nominal operating point values
% RF Power: 1000 watts
% Throttle: 12.5% open
in_scale = diag([1000 12.5]);

% Output scalings, based upon nominal operating point values
% [F]: 30 (unitless)
% Vbias: 350 volts
out_scale = diag([30 350]);

% plant with scaling 
Ps = inv(out_scale)*P*in_scale;
[np11,dp11] = tfdata(Ps(1,1),'v');
[np12,dp12] = tfdata(Ps(1,2),'v');
[np21,dp21] = tfdata(Ps(2,1),'v');
[np22,dp22] = tfdata(Ps(2,2),'v');

% plot the poles and zeros of p11
figure(1); clf;
pzmap(Ps(1,1));
title('poles and zeros of p11');

figure(2); clf;
bode(Ps(1,1),w);
title('Bode of p11');

%sisotool(Ps(1,1));

% Design a controller for the first loop
% z = tzero(Ps(1,1));
% p = pole(Ps(1,1));
% C11 = 1.46*(1/s)*(s-z)/(s-p(2));
z1 = 4.1176; % pole-zero cancelation
p1 = 2.0640;
C11 = 1.46*(1/s)*(s+z1)/(s+p1);

% the "plant" in the second loop with the first loop closed
S1 = 1/(1+C11*Ps(1,1));
P22t = Ps(2,2) - Ps(2,1)*C11*S1*Ps(1,2);
P22t = minreal(P22t);

figure(3); clf;
pzmap(P22t);
title('poles and zeros of 2nd loop plant w/ 1st loop closed');

figure(4); clf;
bode(P22t,w);
title('Bode gain plot, 2nd loop plant w/ 1st loop closed');

 
% design a controller for the second loop
z2 = 1;
p2 = 10;
C22 = 1.25*(1/s)*(s+z2)/(s+p2);

[nc11,dc11] = tfdata(C11,'v');
[nc22,dc22] = tfdata(C22,'v'); 

RIE_dec %open the simulink file
[a_CL2,b_CL2,c_CL2,d_CL2] = linmod('RIE_dec');

eig(a_CL2)


% calculate step responses with both loops closed
t = linspace(0,50,200);
CL_Flourine = step(a_CL2,b_CL2,c_CL2,d_CL2,1,t);
CL_Vbias = step(a_CL2,b_CL2,c_CL2,d_CL2,2,t);

figure(5); clf;

subplot(2,2,1);
plot(t,CL_Flourine(:,1),'k-',t,CL_Flourine(:,2),'k--');
%xlabel('time, seconds');
title('Step to [F], Dec');
set(legend('[F] (y1)','Vbias (y2)'), 'location', 'best', 'fontsize' ,8);
xlim([0 50]);

subplot(2,2,2);
plot(t,CL_Flourine(:,3),'k-',t,CL_Flourine(:,4),'k--');
%xlabel('time, seconds');
title('Step to [F], Dec');
set(legend('RF Power (u1)','Throttle (u2)'), 'location', 'best', 'fontsize' ,8);
xlim([0 50]);

subplot(2,2,3);
plot(t,CL_Vbias(:,1),'k-',t,CL_Vbias(:,2),'k--');
xlabel('time, seconds');
title('Step to V_{bias}, Dec');
set(legend('[F] (y1)','Vbias (y2)'), 'location', 'best', 'fontsize' ,8);
xlim([0 50]);

subplot(2,2,4);
plot(t,CL_Vbias(:,3),'k-',t,CL_Vbias(:,4),'k--');
xlabel('time, seconds');
title('Step to V_{bias}, Dec');
set(legend('RF Power (u1)','Throttle (u2)'), 'location', 'best', 'fontsize' ,8);
xlim([0 50]);

annotation('textbox',[0.3107 0.9347 0.4 0.06667],...
           'String',{'Response of Nominal Plant'}, ...
           'linestyle', 'none', 'Fontsize', 11, 'fontweight', 'bold', 'horizontalalignment', 'center');

%% ================================================================== %%
% calculate noisy step responses with both loops closed
RIE_dec_noise %open the simulink file
[a_CL2,b_CL2,c_CL2,d_CL2] = linmod('RIE_dec_noise');
eig(a_CL2)

t = linspace(0,50,200);
%  1% F noise, 0% Vbias noise -- you may wish to use different values
%  I don't have good figures to use -- at the time we did the designs,
%  F was a much noiser measurement
F_noise = sqrt(0.01)*randn(size(t));
Vbias_noise = sqrt(0)*randn(size(t));
one_input = ones(1, length(t));
zero_input = zeros(1, length(t));

u = [one_input',zero_input',zero_input',zero_input',F_noise',Vbias_noise'];
CL_Flourine = lsim(a_CL2,b_CL2,c_CL2,d_CL2,u,t);

u = [zero_input',one_input',zero_input',zero_input',F_noise',Vbias_noise'];
CL_Vbias = lsim(a_CL2,b_CL2,c_CL2,d_CL2,u,t);

figure(6); clf;

subplot(2,2,1);
plot(t,CL_Flourine(:,1),'k-',t,CL_Flourine(:,2),'k--');
%xlabel('time, seconds');
title('Step to [F], Dec');
set(legend('[F] (y1)','Vbias (y2)'), 'location', 'best', 'fontsize' ,8);
xlim([0 50]);

subplot(2,2,2);
plot(t,CL_Flourine(:,3),'k-',t,CL_Flourine(:,4),'k--');
%xlabel('time, seconds');
title('Step to [F], Dec');
set(legend('RF Power (u1)','Throttle (u2)'), 'location', 'best', 'fontsize' ,8);
xlim([0 50]);

subplot(2,2,3);
plot(t,CL_Vbias(:,1),'k-',t,CL_Vbias(:,2),'k--');
xlabel('time, seconds');
title('Step to V_{bias}, Dec');
set(legend('[F] (y1)','Vbias (y2)'), 'location', 'best', 'fontsize' ,8);
xlim([0 50]);

subplot(2,2,4);
plot(t,CL_Vbias(:,3),'k-',t,CL_Vbias(:,4),'k--');
xlabel('time, seconds');
title('Step to V_{bias}, Dec');
set(legend('RF Power (u1)','Throttle (u2)'), 'location', 'best', 'fontsize' ,8);
xlim([0 50]);

annotation('textbox',[0.35 0.9371 0.3 0.06667],...
           'String',{'Response with Noise'}, ...
           'linestyle', 'none', 'Fontsize', 11, 'fontweight', 'bold', 'horizontalalignment', 'center');

%% ================================================================== %%
% compute output sensitivity and complementary sensitivity functions
% with scaled plant and controller
C = [C11 0;0 C22];

SO = (eye(2)+Ps*C)^(-1);
TO = eye(2)-SO;

figure(7); clf;
sv_SO = sigma(SO,w);
[magSO,phaseSO] = bode(SO,w);
magSO11 = magSO(1,1,:);
magSO12 = magSO(1,2,:);
magSO21 = magSO(2,1,:);
magSO22 = magSO(2,2,:);
loglog(w,sv_SO(1,:),'-',w,sv_SO(2,:),'--', 'color', [0.6 0.6 0.6], 'linewidth', 3); hold on;
loglog(w,magSO11(:),'k-',w,magSO12(:),'k--', w,magSO21(:),'k-.',w,magSO22(:),'k:', 'linewidth', 2);
axis([.1 10 .001 10]);
set(legend('\sigma_{max}(S_O)','\sigma_{min}(S_O)','|S_{O11}|','|S_{O12}|','|S_{O21}|','|S_{O22}|', 4), 'fontsize', 7);
title('output sensitivity function S_O');
xlabel('\omega, rad/sec');
defaultratio_ppt;

figure(8); clf;
sv_TO = sigma(TO,w);
[magTO,phaseTO] = bode(TO,w);
magTO11 = magTO(1,1,:);
magTO12 = magTO(1,2,:);
magTO21 = magTO(2,1,:);
magTO22 = magTO(2,2,:);
loglog(w,sv_TO(1,:),'-',w,sv_TO(2,:),'--', 'color', [0.6 0.6 0.6], 'linewidth', 3); hold on;
loglog(w,magTO11(:),'k-',w,magTO12(:),'k--', w,magTO21(:),'k-.',w,magTO22(:),'k:', 'linewidth', 2);
axis([.1 10 .001 10]);
set(legend('\sigma_{max}(T_O)','\sigma_{min}(T_O)','|T_{O11}|','|T_{O12}|','|T_{O21}|','|T_{O22}|', 3), 'fontsize', 7);
title('output complementary sensitivity function T_O');
xlabel('\omega, rad/sec');
defaultratio_ppt;


%% ================================================================== %%
% input sensitivity and complementary sensitivity functions
SI = (eye(2)+C*Ps)^(-1);
TI = eye(2)-SI;

figure(9); clf;
sv_SI = sigma(SI,w);
[magSI,phaseSI] = bode(SI,w);
magSI11 = magSI(1,1,:);
magSI12 = magSI(1,2,:);
magSI21 = magSI(2,1,:);
magSI22 = magSI(2,2,:);
loglog(w,sv_SI(1,:),'-',w,sv_SI(2,:),'--', 'color', [0.6 0.6 0.6], 'linewidth', 3); hold on;
loglog(w,magSI11(:),'k-',w,magSI12(:),'k--', w,magSI21(:),'k-.',w,magSI22(:),'k:', 'linewidth', 2);
axis([.1 10 .001 10]);
set(legend('\sigma_{max}(S_I)','\sigma_{min}(S_I)','|S_{I11}|','|S_{I12}|','|S_{I21}|','|S_{I22}|', 3), 'fontsize', 7);
title('input sensitivity function S_I');
xlabel('\omega, rad/sec');
defaultratio_ppt;

figure(10); clf;
sv_TI = sigma(TI,w);
[magTI,phaseTI] = bode(TI,w);
magTI11 = magTI(1,1,:);
magTI12 = magTI(1,2,:);
magTI21 = magTI(2,1,:);
magTI22 = magTI(2,2,:);
loglog(w,sv_TI(1,:),'-',w,sv_TI(2,:),'--', 'color', [0.6 0.6 0.6], 'linewidth', 3); hold on;
loglog(w,magTI11(:),'k-',w,magTI12(:),'k--', w,magTI21(:),'k-.',w,magTI22(:),'k:', 'linewidth', 2);
axis([.1 10 .001 10]);
set(legend('\sigma_{max}(T_I)','\sigma_{min}(T_I)','|T_{I11}|','|T_{I12}|','|T_{I21}|','|T_{I22}|', 3), 'fontsize', 7);
title('input complementary sensitivity function T_I');
xlabel('\omega, rad/sec');
defaultratio_ppt;


%% ================================================================== %%
% stability radii
stab_rad11 = 1/max(magSI11)
figure(11); clf;
nyquist(C11*Ps(1,1), 'k'); hold on;
circle = rsmak('circle', stab_rad11, [-1 0]); % rsmak('circle',radius,center)
fnplt(circle,':k',[],1,[]); % FNPLT(F,SYMBOL,INTERV,LINEWIDTH,JUMPS)
plot(-1,0, 'r+');
axis([-2 2 -2 2]);
axis equal
title(['Nyquist Diagram of C11*P11, Stability radius = ', num2str(stab_rad11)]);
defaultratio_ppt;
set(gcf, 'position', [1    1    4.0000    3.0000]);

stab_rad22 = 1/max(magSI22)
figure(12); clf;
nyquist(C22*P22t, 'k'); hold on;
circle = rsmak('circle', stab_rad22, [-1 0]); % rsmak('circle',radius,center)
fnplt(circle,':k',[],1,[]); % FNPLT(F,SYMBOL,INTERV,LINEWIDTH,JUMPS)
plot(-1,0, 'r+');
axis([-2 2 -2 2]);
axis equal
title(['Nyquist Diagram of C22*P22t, Stability radius = ', num2str(stab_rad22)]);
defaultratio_ppt;
set(gcf, 'position', [1    1    4.0000    3.0000]);

