clear all
close all
clc
format compact

s = tf('s');
omega = logspace(-2,2);
t = linspace(0,50);

%% ================================================================== %%
% Plant in engineering coordinates

% [F]/Power
np11 = [0.17   0.7];
dp11 = [1  15   26.7];

% Vbias/Power
np21 = 0.28;
dp21 = [1  0.97];

% 2nd order pade approximation to throttle delay
[ndelay,ddelay] = pade(0.5,2);

% [F]/Throttle
np12 =  -0.17;
dp12 = [1  0.24];

% Vbias/Throttle
np22 = [2.41  9.75];
dp22 = [1  4  0.7];

% Input scalings, based upon nominal operating point values
% RF Power: 1000 watts
% Throttle: 12.5% open
in_scale = diag([1000 12.5]);


% Output scalings, based upon nominal operating point values
% [F]: 30 (unitless)
% Vbias: 350 volts
out_scale = diag([30 350]);


% Scaled plant
np11 = np11*in_scale(1,1)/out_scale(1,1);
np12 = -0.17*in_scale(2,2)/out_scale(1,1);
np21 = np21*in_scale(1,1)/out_scale(2,2);
np22 = [2.41 9.75]*in_scale(2,2)/out_scale(2,2);
% Both loops open

nc11 = 0;
dc11 = 1;
nc22 = 0;
dc22 = 1;

% calculate state space description of plant by calculating a state space
% description of the feedback system with both 
% controllers set to zero

% NOTE: the delay should not be included in the transfer functions p11, p12, etc
% because the SIMULINK file handles it separately
 
[Asys,Bsys,Csys,Dsys] = linmod('RIE_dec1');
P_sys = [Asys Bsys(:,[3:4]);Csys([1:2],:) Dsys([1:2],[3:4])];

ns = size(Asys,1); %  # of states
no = size(Csys([3:4],:),1);  %  # of outputs = # of inputs

AP = Asys;
BP = Bsys(:,[3:4]);
CP = Csys([1:2],:);
DP = Dsys([1:2],[3:4]);

Ps  = ss(AP, BP, CP, DP);

%% ================================================================== %%
% augment state equations so that you can do integral control
Aaug = [AP, zeros(ns,no);
        CP, zeros(no, no)];
Baug = [BP;
     zeros(no,no)];
Caug = [CP, zeros(no,no)];
Daug = zeros(no); 

% Here you should insert your weighting matrices
% Q = eye(10);
% V = eye(8);      
% R = eye(2);
% W = eye(2);
 
Q1 = diag([1,1])*200;
Qx = CP'*Q1*CP;
Qi = diag([1,1])*10;

Q = [Qx,     zeros(ns, no);
  zeros(no,ns), Qi];

R = diag([20,20]);
  
% an LQ state feedback gain
Kaug = lqr(Aaug,Baug,Q,R);
K = Kaug(:,1:8);
KI = Kaug(:,9:10);

% observer gain  -- note that you need to observer the plant states only
q = 5.5;%1;
V = q^2*BP*BP';
W = eye(2);

L = lqr(AP',CP',V,W)';


%% ================================================================== %%
% Bode plots of scaled plant transfer function
figure(1); clf;
[magP11,phaseP11] = bode(Ps(1,1),omega);
magP11 = squeeze(magP11);phaseP11 = squeeze(phaseP11);
[magP12,phaseP12] = bode(Ps(1,2),omega);
magP12 = squeeze(magP12);phaseP12 = squeeze(phaseP12);
[magP21,phaseP21] = bode(Ps(2,1),omega);
magP21 = squeeze(magP21);phaseP21 = squeeze(phaseP21);
[magP22,phaseP22] = bode(Ps(2,2),omega);
magP22 = squeeze(magP22);phaseP22 = squeeze(phaseP22);

subplot(2,1,1)
loglog(omega,magP11,'-',omega,magP12,'--',omega,magP21,'-.',omega,magP22,':')
title('plant transfer functions')
legend('P(1,1)','P(1,2)','P(2,1)','P(2,2)',3)
subplot(2,1,2)
semilogx(omega,phaseP11,'-',omega,phaseP12,'--',omega,phaseP21,'-.',omega,phaseP22,':')
xlabel('frequency, rad/sec')

%% ================================================================== %%
% equivalent compensator:
%   Ceq = (-K(sI-A+BK)^(-1)B+I)KI/s
%       = (I+K(sI-A)^(-1)B)^(-1)KI/s
Ceq= ss(AP-BP*K,BP,-K,eye(2))*ss(zeros(2,2),KI,eye(2),zeros(2,2));

% Bode plots of equivalent compensator transfer function
figure(2); clf;
[magCeq11,phaseCeq11] = bode(Ceq(1,1),omega);
magCeq11 = squeeze(magCeq11);phaseCeq11 = squeeze(phaseCeq11);
[magCeq12,phaseCeq12] = bode(Ceq(1,2),omega);
magCeq12 = squeeze(magCeq12);phaseCeq12 = squeeze(phaseCeq12);
[magCeq21,phaseCeq21] = bode(Ceq(2,1),omega);
magCeq21 = squeeze(magCeq21);phaseCeq21 = squeeze(phaseCeq21);
[magCeq22,phaseCeq22] = bode(Ceq(2,2),omega);
magCeq22 = squeeze(magCeq22);phaseCeq22 = squeeze(phaseCeq22);

subplot(2,1,1)
loglog(omega,magCeq11,'k-',omega,magCeq12,'k--',omega,magCeq21,'k-.',omega,magCeq22,'k:')
set(gca, 'ylim', [.001 10], 'ytick', [1e-3 1e-2 1e-1 1e0 1e1]);
title('Bode diagram of the equivalent compensator')
legend('C_{eq}(1,1)','C_{eq}(1,2)','C_{eq}(2,1)','C_{eq}(2,2)',3)

subplot(2,1,2)
semilogx(omega,phaseCeq11,'k-',omega,phaseCeq12,'k--',omega,phaseCeq21,'k-.',omega,phaseCeq22,'k:')
xlabel('frequency, rad/sec')
 

%% ================================================================== %%
% plot poles and zeros of Ceq(2,2) so that we can approximate by low order
% controller Cd2
figure(3); clf;
Ceq22 = minreal(Ceq(2,2));
pzmap(Ceq22);
title('pole/zero map of C_{eq}(2,2)');
Ceq22zpk = zpk(Ceq22);

% Cd2 should approximate Ceq(2,2)
Cd2 = 0.6*1/s*(s+0.22)/(s+0.7);
figure(51); clf;
bode(Ceq22,'k-',Cd2,'k--',omega)
legend('C_{eq}(2,2)','C_{d2}')
xlim([1e-2 1e2])
set(gca, 'fontsize', 10)
set(gcf, 'position', [50   115   455   357]);

% plot poles and zeros of Ceq(1,1) so that we can approximate by low order
% controller Cd1
figure(4); clf;
Ceq11 = minreal(Ceq(1,1));
pzmap(Ceq11);
title('pole/zero map of C_{eq}(1,1)');
Ceq11zpk = zpk(Ceq11);

% Cd1 should approximate Ceq(1,1)
Cd1 = 0.5*1/s*(s+12.9)/(s+22.2)*(s+1.6)/(s+3.5);
figure(5); clf;
bode(Ceq11,'k-',Cd1,'k--', omega);
legend('C_{eq}(1,1)','C_{d1}', 2);
xlim([1e-2 1e2]);
set(gca, 'fontsize', 10)
set(gcf, 'position', [50   115   455   357]);

Capp = [Cd1, Cd1;
       -Cd2, Cd2];

SOapp = inv(eye(2)+Ps*Capp);
TOapp = eye(2)-SOapp;

SOeq = inv(eye(2)+Ps*Ceq);
TOeq = eye(2)-SOeq;

figure(6); clf;
step(TOeq,'k-',TOapp,'k--',t);
ylim([0 1.05]);
title('step response with C_{eq} and approximation');
legend('with C_{eq}','with approx to C_{eq}', 4);


%% ================================================================== %%
% now begin to design controller C = Cd*M from scratch once we know its structure
% orthogonal transformation matrix
M = 1/sqrt(2)*[1 1;-1 1];

% plant with transformed output coordinates
MP = M*Ps;

% Bode plots of plant in new coordinates
figure(7); clf;
bodemag(MP(1,1),'k-',MP(1,2),'k--',MP(2,1),'k-.',MP(2,2),'k:',omega);
legend('MP(1,1)','MP(1,2)','MP(2,1)','MP(2,2)', 3);
set(gcf, 'position', [50   115   455   357]);

% Cd1 =
% Cd2 =

Cd = [Cd1  0;0  Cd2];
LO = Ps*Cd*M;
SO = inv(eye(2)+LO);
TO = eye(2)-SO;

figure(8); clf;
step(TOeq,'k-',TO,'k--',t);
ylim([0 1]);
title('step response with C_{eq} and C_dM');
legend('with C_{eq}','with C_dM', 4);

