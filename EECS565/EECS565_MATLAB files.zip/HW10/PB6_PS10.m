clear all
close all
clc
format compact

% INPUTS:  [RF Power; Throttle; %O2]
% OUTPUTS: [Flourine; Vbias; Pressure]
% NOTE: (Ap,Bp,Cp,Bp) is the state description in *engineering* coordinates
% NOTE: (As,Bs,Cs,Bs) is the state description in *scaled* coordinates

% F/Power
np11 = 0.49*[1  0.067];
dp11 = conv([1 .095],[1 19.69]);

% Vbias/Power
np21 = 12.23*[1  0.27];
dp21 = conv([1  0.19],[1   62.42]);

% Pressure/Power
np31 = -0.011*[1  -0.006];
dp31 = conv([1   0.19],[1   2.33]);


% F/Throttle
np12 = 4.85*[1  -0.73];
dp12 = conv([1  0.11],[1  39.76]);

% Vbias/Throttle
np22 = 1.65;
dp22 = [1  0.16];

% Pressure/Throttle
np32 = -0.97;
dp32 = conv([1   0.18],[1   3.0]);

% 1st order pade approximation to throttle delay
[ndelayT,ddelayT] = pade(0.42,1);


% F/%O2
np13 = 0.33;
dp13 = [1  0.17];

% Vbias/%O2
np23 = 0.25;
dp23 = [1  0.41];

% Pressure/%O2
np33 = 0.024;
dp33 = [1  0.40];

% 1st order pade approximation to O2 delay
[ndelayO,ddelayO] = pade(0.77,1);


%RIE_withO2
[Ap,Bp,Cp,Dp] = linmod('RIE_withO2');


% Input scalings, based upon nominal operating point values
% RF Power: 1000 watts
% Throttle: 12.5% open
% O2; 5%
in_scale = diag([1000  12.5  5]);

% Output scalings, based upon nominal operating point values
% [F]: 16.52 (unitless)
% Vbias: 340 volts
% Presssure:  17.83 mTorr
out_scale = diag([16.52  340  17.83]);


% create state space description of the scaled plant
As = Ap;  % input and output scaling doesn't affect the state variables
Bs = Bp*in_scale;
Cs = inv(out_scale)*Cp;
Ds = inv(out_scale)*Dp*in_scale; 

% Determine size of plant
[ns,ni] = size(Bs);
[no,ns] = size(Cs);

n = ns;
p = ni;
q = no;

%% ================================================================== %%
% check feasibility of using integral control
s = tf('s');
P = Cs*(s*eye(ns)-As)^-1*Bs;

% DC gain matrix
P0 = dcgain(P)

% singular values
svd(P0)

% condition number
1./svd(P0)


rank([As, Bs;
    Cs, zeros(ni,no)])
n+q

%% ================================================================== %%
% (As,Bs,Cs,Ds) is the state description of the *scaled* plant
% this m-file is set up so that the weighting on the states of
% the plant is given by alpha*Cs'*Cs, the weighting on
% the integrator states is given by Qw, the control weighting is
% given by R, the process noise covariance is given by V=Bs*Bs'
% and the measurement noise is given by  W =  I
% if you wish, you may use a more general form of the state weighting matrix


% weighting matrices
% Assume Q of the form Q = alpha*Cs'*Cs + Qw
% Since I don't have you do the optional parts necessary for the
% observer design, use V = Bs*Bs' and W = I.
alpha = 5;
Qw = diag([1 1 1]);
R = diag([1 10 1]);
V = Bs*Bs';
W =  eye(no);
 

% Design and Analysis of LQG/LTR controller 
w = logspace(-2,2);
time = 0:1/20:40;


% Augment the plant with integrators
% \dot{x} = As x + Bs u
% \dot{q} = y - r
%      y  = Cs x
Aaug = [As, zeros(ns,no);
        Cs, zeros(no,no)];
Baug = [Bs; 
        zeros(no,ni)];
Caug = [Cs, zeros(no,no)];
Daug = zeros(no,ni);

% LQR Design
Qaug = [alpha*Cs'*Cs, zeros(ns,no); zeros(no,ns), Qw];
Kaug = lqr(Aaug,Baug,Qaug,R);


%*************************************************************
% Here you should look at singular values at the plant input of
% the state feedback design
% You might also want to look at the 9 individual transfer functions
% ************************************************************

% Step Response of Closed Loop System -- state feedback
Asf = Aaug-Baug*Kaug;
Bsf = [zeros(ns,ni);
       -eye(ni)];
Csf = Caug;
Dsf = Daug;

figure(1); clf;
set(gcf, 'position', [45   100   736   508]);
outputs = str2mat('F','Vbias','pressure');
inputs = str2mat('Power','Throttle','O2');
for i=1:ni,
    subplot(2,ni,i)
    y = step(Asf,Bsf,Csf,Dsf,i,time);
    titl = ['Step in ',num2str(outputs(i,:))];
    plot(time,y(:,1),'k-',time,y(:,2),'k--',time,y(:,3),'k:')
    grid
    title(titl);
    xlabel('Time (seconds)');
    %ylabel([num2str(outputs(j,:))]);
    if i == 3
        set(legend('[F]','V_{bias}','Pressure'), 'fontsize', 8, 'location', 'east');
    end
    if i == 1 || i == 3
        ylim([-0.2 1.2]);
    end
    set(gca ,'xtick', [0 20 40]);

    subplot(2,ni,i+3)
    u = step(Asf,Bsf,-Kaug,Dsf,i,time);
    titl = ['Response of inputs to a step in  ',num2str(outputs(i,:))];
    plot(time,u(:,1),'k-',time,u(:,2),'k--',time,u(:,3),'k:')
    grid
    %title(titl)
    xlabel('Time (seconds)');
    %ylabel([num2str(inputs(j,:))]);
    if i == 3
        set(legend('Power','Throttle','%O2'), 'fontsize', 8, 'Position',[0.7681 0.2946 0.1277 0.1076]);
    end
    
    set(gca ,'xtick', [0 20 40]);
end

%% ================================================================== %%
% Loop Transfer Recovery
L = lqr(As',Cs',V,W)';

nas = ns+no;
K1 = Kaug(:,1:ns);
K2 = Kaug(:,ns+1:nas);

Ac = [As-Bs*K1-L*Cs, -Bs*K2;
      zeros(no,nas)];
Bc = [L, zeros(ns,no);
      eye(no), -eye(no)];
Cc = -Kaug;
Dc = zeros(ni,2*no);


%*************************************************************
% Here you should look at singular values at the plant input of
% the observer based design feedback design
% You might also want to look at the 9 individual transfer functions
%*************************************************************

% Closed Loop System -- with observer
Acl = [Ac, [L;eye(no)]*Cs; Bs*Cc, As];
Bcl = [zeros(ns,no);-eye(no);zeros(ns,no)];
Ccl = [zeros(no,nas), Cs];
Dcl = zeros(no,no);

%*************************************************************
% Following are step responses with the observer. These should
% be identical to the state feedback step responses (why?)
% For a better simulation, you should 
% model some noise on the measurements as we did in the earlier designs
%*************************************************************
figure(2); clf;
set(gcf, 'position', [45   100   736   508]);

for i=1:ni,
    subplot(2,ni,i)
    y = step(Acl,Bcl,Ccl,Dcl,i,time);
    titl = ['Step in ',num2str(outputs(i,:))];
    plot(time,y(:,1),'k-',time,y(:,2),'k--',time,y(:,3),'k:')
    grid
    title(titl);
    xlabel('Time (seconds)')
    if i == 3
        set(legend('[F]','V_{bias}','Pressure'), 'fontsize', 8, 'location', 'east');
    end
    if i == 1 || i == 3
        ylim([-0.2 1.2]);
    end
    set(gca ,'xtick', [0 20 40]);

    subplot(2,ni,i+3)
    u = step(Acl,Bcl,[-Kaug,zeros(ni,ns)],Dcl,i,time);
    titl = ['Step in  ',num2str(outputs(i,:))];
    plot(time,u(:,1),'k-',time,u(:,2),'k--',time,u(:,3),'k:')
    grid
    xlabel('Time (seconds)')
    if i == 3
        set(legend('Power','Throttle','%O2'), 'fontsize', 8, 'Position',[0.7681 0.2946 0.1277 0.1076]);
    end
    set(gca ,'xtick', [0 20 40]);
    
end
