clear all
close all
clc
format compact

w = logspace(-2,2,200);


%% ================================================================== %%
% Plant in engineering coordinates

% [F]/Power
np11 = [0.17   0.7];
dp11 = [1  15   26.7];

% Vbias/Power
np21 = 0.28;
dp21 = [1  0.97];

% 2nd order pade approximation to throttle delay
[ndelay,ddelay] = pade(0.5,2);

% [F]/Throttle
np12 = -0.17;
dp12 = [1  0.24];

% Vbias/Throttle
np22 = [2.41  9.75];
dp22 = [1  4  0.7];

% Input scalings, based upon nominal operating point values
% RF Power: 1000 watts
% Throttle: 12.5% open
in_scale = diag([1000 12.5]);


% Output scalings, based upon nominal operating point values
% [F]: 30 (unitless)
% Vbias: 350 volts
out_scale = diag([30 350]);

% Scaled plant
np11 = np11*in_scale(1,1)/out_scale(1,1);
np12 = -0.17*in_scale(2,2)/out_scale(1,1);
np21 = np21*in_scale(1,1)/out_scale(2,2);
np22 = [2.41 9.75]*in_scale(2,2)/out_scale(2,2);

% Both loops open
nc11 = 0;
dc11 = 1;
nc22 = 0;
dc22 = 1;

% calculate state space description of plant by calculating a state space
% description of the feedback system with both 
% controllers set to zero

% NOTE: the delay should not be included in the transfer functions p11, p12, etc
% because the SIMULINK file handles it separately
[Asys,Bsys,Csys,Dsys] = linmod('RIE_dec1');

AP = Asys;
BP = Bsys(:,3:4);
CP = Csys(1:2,:);
DP = Dsys(1:2,3:4);

ns = size(Asys,1); %  # of states (n)
no = size(Csys(3:4,:),1);  %  # of outputs = # of inputs (p = q)

Ps  = ss(AP, BP, CP, DP);


%% ================================================================== %%
% augment state equations so that you can do integral control
Aaug = [AP, zeros(ns,no);
        CP, zeros(no, no)];
Baug = [BP;
     zeros(no,no)];
Caug = [CP, zeros(no,no)];
Daug = zeros(no); 

% Here you should insert your weighting matrices
Q1 = diag([1,1])*200;
Qx = CP'*Q1*CP;
Qi = diag([1,1])*10;

Q = [Qx,     zeros(ns, no);
  zeros(no,ns), Qi];

R = diag([20,20]);

% an LQ state feedback gain
Kaug = lqr(Aaug,Baug,Q,R);
K = Kaug(1:no,1:ns);
Ki = Kaug(1:no,ns+1:ns+no);

% closed loop state equations, with state feedback
% Choose Csf and Dsf so that you output both y and u
Asf = [AP-BP*K, -BP*Ki;
       CP, zeros(no,no)];
Bsf = [zeros(ns,no);
       -eye(no)];
Csf = [CP, zeros(no,no);
       -Kaug];
Dsf = zeros(no+no,no);

SF_evalues = eig(Asf); % check to make sure that closed loop is stable!!!

t = linspace(0,50,200);
CL_Flourine = step(Asf,Bsf,Csf,Dsf,1,t);
CL_Vbias = step(Asf,Bsf,Csf,Dsf,2,t);

figure(1); clf;

subplot(2,2,1);
plot(t,CL_Flourine(:,1),'k-',t,CL_Flourine(:,2),'k--');
%xlabel('time, seconds');
title('Step to [F], SF')
set(legend('[F] (y1)','Vbias (y2)'), 'location', 'east', 'fontsize' ,8);
xlim([0 50]);
set(gca, 'ytick', 0:0.2:1);
ylim([0 1]);

subplot(2,2,2);
plot(t,CL_Flourine(:,3),'k-',t,CL_Flourine(:,4),'k--');
%xlabel('time, seconds');
title('Step to [F], SF');
set(legend('RF Power (u1)','Throttle (u2)'), 'location', 'east', 'fontsize' ,8);
xlim([0 50]);
ylim([-1.5 1]);

subplot(2,2,3);
plot(t,CL_Vbias(:,1),'k-',t,CL_Vbias(:,2),'k--');
xlabel('time, seconds');
title('Step to V_{bias}, SF');
set(legend('[F] (y1)','Vbias (y2)'), 'location', 'east', 'fontsize' ,8);
xlim([0 50]);
ylim([0 1]);
set(gca, 'ytick', 0:0.2:1);

subplot(2,2,4);
plot(t,CL_Vbias(:,3),'k-',t,CL_Vbias(:,4),'k--');
xlabel('time, seconds');
title('Step to V_{bias}, SF');
set(legend('RF Power (u1)','Throttle (u2)'), 'location', 'east', 'fontsize' ,8);
xlim([0 50]);
ylim([0 1.4]);
set(gca, 'ytick', 0:0.2:1.4);

annotation('textbox',[0.3107 0.9347 0.4 0.06667],...
           'String',{'Response of State Feedback'}, ...
           'linestyle', 'none', 'Fontsize', 11, 'fontweight', 'bold', 'horizontalalignment', 'center');


%% ================================================================== %%
% % observer gain  -- note that you need to observer the plant states only
q = 5.5;%1;
V = q^2*BP*BP';
W = eye(2);
L = lqr(AP',CP',V,W)';
obs_evalues = eig(AP-L*CP); % check to see that observer is stable

% state equations of closed loop system
% choose c_CL and d_CL so that you get the responses of both
% the outputs F and Vbias and the control signals Power and throttle
a_CL = [AP, -BP*Ki, -BP*K;  % x: original states
        CP, zeros(no, no), zeros(no,ns); % w: integrator states
        L*CP, -BP*Ki, AP-BP*K-L*CP];     % xhat: observer states
b_CL = [zeros(ns, no);
         -eye(no, no);
         zeros(ns, no)];
c_CL = [CP, zeros(no, no), zeros(no, ns); % y: original outputs
        -Kaug, zeros(no, ns)];            % u: controls
d_CL = zeros(no+no,no);

CL_evalues = eig(a_CL);  % check to see that these evalues are those of
                         % Aaug-BaugKaug plus those of A-LC

% calculate step responses (these should be the same as with state feedback)
t = linspace(0,50,200);
CL_Flourine = step(a_CL,b_CL,c_CL,d_CL,1,t);
CL_Vbias = step(a_CL,b_CL,c_CL,d_CL,2,t);

figure(2); clf; 

subplot(2,2,1);
plot(t,CL_Flourine(:,1),'k-',t,CL_Flourine(:,2),'k--');
%xlabel('time, seconds');
title('Step to [F], obs');
set(legend('[F] (y1)','Vbias (y2)'), 'location', 'east', 'fontsize' ,8);
xlim([0 50]);
set(gca, 'ytick', 0:0.2:1);
ylim([0 1]);

subplot(2,2,2);
plot(t,CL_Flourine(:,3),'k-',t,CL_Flourine(:,4),'k--');
%xlabel('time, seconds');
title('Step to [F], obs');
set(legend('RF Power (u1)','Throttle (u2)'), 'location', 'east', 'fontsize' ,8);
xlim([0 50]);
ylim([-1.5 1]);

subplot(2,2,3);
plot(t,CL_Vbias(:,1),'k-',t,CL_Vbias(:,2),'k--');
xlabel('time, seconds');
title('Step to V_{bias}, obs');
set(legend('[F] (y1)','Vbias (y2)'), 'location', 'east', 'fontsize' ,8);
xlim([0 50]);
ylim([0 1]);
set(gca, 'ytick', 0:0.2:1);

subplot(2,2,4);
plot(t,CL_Vbias(:,3),'k-',t,CL_Vbias(:,4),'k--');
xlabel('time, seconds');
title('Step to V_{bias}, obs');
set(legend('RF Power (u1)','Throttle (u2)'), 'location', 'east', 'fontsize' ,8);
xlim([0 50]);
ylim([0 1.4]);
set(gca, 'ytick', 0:0.2:1.4);

annotation('textbox',[0.3107 0.9347 0.4 0.06667],...
           'String',{'Response of SF + Observer'}, ...
           'linestyle', 'none', 'Fontsize', 11, 'fontweight', 'bold', 'horizontalalignment', 'center');

%% ================================================================== %%
Lsf = ss(Aaug,Baug,Kaug,zeros(2,2));

% singular value plots
% state feedback open loop transfer function
sv_Lsf = sigma(Lsf,w);

% sensitivity function
Ssf = inv(eye(2)+Lsf);
sv_Ssf = sigma(Ssf,w);

% complementary sensitivity function
Tsf = eye(2)-Ssf;
sv_Tsf = sigma(Tsf,w);


%% ================================================================== %%
% state space description of C(s) = C_obs(s)
% be careful -- a lot of people screw this up!!!!
AC = [AP-BP*K-L*CP, -BP*Ki;
      zeros(no, ns), zeros(no,no)];
BC =  [L;
       eye(2)];
CC =  Kaug;
Cobs = ss(AC,BC,CC,zeros(2,2));

% state space descripion of L_I(s) = C(s)P(s)
LI = Cobs*Ps;

% singular value plots
% input open loop transfer function with the observer
sv_LI = sigma(LI,w);

% singular value plots
% input sensitivity transfer function with the observer
SI = inv(eye(2)+LI);
sv_SI = sigma(SI,w);

% singular value plots
% input comp. sensitivity transfer function with the observer
TI = eye(2)-SI;
sv_TI = sigma(TI,w);

figure(3); clf;
loglog(w,sv_Lsf(1,:),'k-',w,sv_Lsf(2,:),'k:',w,sv_LI(1,:),'k-.',w,sv_LI(2,:),'k--');
xlabel('\omega, rad/sec');
ylabel('magnitude');
title(['open loop singular values, L_{sf} and L_I']);
legend('\sigma_{max}(L_{sf})','\sigma_{min}(L_{sf})','\sigma_{max}(L_I)','\sigma_{min}(L_I)', 3);
% axis([.01 100 .001 1000]);
defaultratio_ppt;

figure(4); clf;
loglog(w,sv_Ssf(1,:),'k-',w,sv_Ssf(2,:),'k:',w,sv_SI(1,:),'k-.',w,sv_SI(2,:),'k--');
legend('\sigma_{max}(S_{sf})','\sigma_{min}(S_{Ssf})','\sigma_{max}(S_I)','\sigma_{min}(S_I)',4);
title('singular values of sensitivity function');
xlabel('\omega, rad/sec');
ylabel('magnitude');
defaultratio_ppt;

figure(5); clf;
loglog(w,sv_Tsf(1,:),'k-',w,sv_Tsf(2,:),'k:',w,sv_TI(1,:),'k-.',w,sv_TI(2,:),'k--');
legend('\sigma_{max}(T_{sf})','\sigma_{min}(T_{sf})','\sigma_{max}(T_I)','\sigma_{min}(T_I)',3);
title('singular values of complementary sensitivity function');
xlabel('\omega, rad/sec');
ylabel('magnitude');
axis([.01 100 .001 10]);
defaultratio_ppt;


%% ================================================================== %%
% calculate noisy step responses with both loops closed
K1 = K;
K2 = Ki;
[a_CL2,b_CL2,c_CL2,d_CL2] = linmod('obs_sf_int_w_noise');

eig(a_CL2);

t = linspace(0,50,200);
F_noise = sqrt(0.01)*randn(size(t));
Vbias_noise = sqrt(0)*randn(size(t));
one_input = ones(1, length(t));
zero_input = zeros(1, length(t));
	  
u = [one_input',zero_input',zero_input',zero_input',F_noise',Vbias_noise'];
CL_Flourine = lsim(a_CL2,b_CL2,c_CL2,d_CL2,u,t);

u = [zero_input',one_input',zero_input',zero_input',F_noise',Vbias_noise'];
CL_Vbias = lsim(a_CL2,b_CL2,c_CL2,d_CL2,u,t);

figure(6); clf;

subplot(2,2,1);
plot(t,CL_Flourine(:,1),'k-',t,CL_Flourine(:,2),'k--');
%xlabel('time, seconds');
title('Step to [F], MIMO');
set(legend('[F] (y1)','Vbias (y2)'), 'location', 'east', 'fontsize' ,8);
xlim([0 50]);
ylim([-0.2 1.2]);

subplot(2,2,2);
plot(t,CL_Flourine(:,3),'k-',t,CL_Flourine(:,4),'k--');
%xlabel('time, seconds');
title('Step to [F], MIMO');
set(legend('RF Power (u1)','Throttle (u2)'), 'location', 'east', 'fontsize' ,8);
xlim([0 50]);
ylim([-1.5 1]);

subplot(2,2,3);
plot(t,CL_Vbias(:,1),'k-',t,CL_Vbias(:,2),'k--');
xlabel('time, seconds');
title('Step to V_{bias}, MIMO');
set(legend('[F] (y1)','Vbias (y2)'), 'location', 'east', 'fontsize' ,8);
xlim([0 50]);
ylim([-0.2 1.2]);

subplot(2,2,4);
plot(t,CL_Vbias(:,3),'k-',t,CL_Vbias(:,4),'k--');
xlabel('time, seconds');
title('Step to V_{bias}, MIMO');
set(legend('RF Power (u1)','Throttle (u2)'), 'location', 'east', 'fontsize' ,8);
xlim([0 50]);
ylim([0 1.4]);
set(gca, 'ytick', 0:0.2:1.4);


annotation('textbox',[0.35 0.9371 0.3 0.06667],...
           'String',{['Response with Noise (q = ', num2str(q), ')']}, ...
           'linestyle', 'none', 'Fontsize', 11, 'fontweight', 'bold', 'horizontalalignment', 'center');

% ================================================================== %%
figure(7); clf;
[mag_Fnoise,phase_Fnoise] = bode(a_CL2,b_CL2,c_CL2,d_CL2,5,w);
loglog(w,mag_Fnoise(:,1),'k-',w,mag_Fnoise(:,2),'k--',w,mag_Fnoise(:,3),'k-.',w,mag_Fnoise(:,4),'k:');
xlabel('frequency, rad/sec');
legend('[F]','V_{bias}','Power','Throttle', 3);
title('closed loop Bode plots of response to F noise');
line([1e0 1e0], [1e-4 1e1], 'color', [0.7 0.7 0.7]);
line([1e-2 1e2], [1e0 1e0], 'color', [0.7 0.7 0.7]);
defaultratio_ppt;

% singular value plots
% CSO, control response
LO = Ps*Cobs;
SO = 1/(eye(2)+LO);
CSO = minreal(Cobs*SO);
sv_CSO = sigma(CSO,w);

figure(8); clf;
[magCSO,phaseCSO] = bode(CSO,w);
magCSO11 = magCSO(1,1,:);
magCSO12 = magCSO(1,2,:);
magCSO21 = magCSO(2,1,:);
magCSO22 = magCSO(2,2,:);
loglog(w,sv_CSO(1,:),'k-',w,sv_CSO(2,:),'k:', 'linewidth', 2); hold on;
loglog(w,magCSO11(:),'k-',w,magCSO12(:),'k--', ...
       w,magCSO21(:),'k-.',w,magCSO22(:),'k:');
axis([.1 10 .01 10]);
title('singular values and elements of CS_O');
xlabel('\omega, rad/sec');
set(legend('\sigma_{max}(CS_O)','\sigma_{min}(CS_O)',...
       '|CS_{O11}|','|CS_{O12}|','|CS_{O21}|','|CS_{O22}|'), 'fontsize', 9, 'location', 'EastOutside');
set(gcf,'Units', 'inches');
set(gcf, 'position', [0.6250    3.7396    4.675    2.75]);
set(gca, 'position', [0.1000    0.1528    0.6041    0.7465]);

