clear all
close all
clc
format compact

% this script makes the plant (A,B,C,D) for the 3x3 RIE 
% in *engineering* units. It also makes the plant (As,Bs,Cs,Ds) in 
% *scaled* units. 
% We also calculate 
% K1: state feedback gain for the plant states
% K2: state feedback gain for the integrator states
% L: observer gain
% using LQG techniques, and the weighting parameters
% alpha, Qw, R, rho
 
% The m-file also calculates a state space description of the 
% compensator with AW   in scaled units


% the parameter tau controls the feedback loop around a saturated integrator

% pick a nonzero number to turn on the AW algorithm
% tau = 0;    
tau = 1;    
 

% plant transfer functions, engineering units

% F/Power
np11 = 0.49*[1  0.067];
dp11 = conv([1 .095],[1 19.69]);

% Vbias/Power
np21 = 12.23*[1  0.27];
dp21 = conv([1  0.19],[1   62.42]);

% Pressure/Power
np31 = -0.011*[1  -0.006];
dp31 = conv([1   0.19],[1   2.33]);


% F/Throttle
np12 = 4.85*[1  -0.73];
dp12 = conv([1  0.11],[1  39.76]);

% Vbias/Throttle
np22 = 1.65;
dp22 = [1  0.16];

% Pressure/Throttle
np32 = -0.97;
dp32 = conv([1   0.18],[1   3.0]);

% 1st order pade approximation to throttle delay
[ndelayT,ddelayT] = pade(0.42,1);


% F/%O2
np13 = 0.33;
dp13 = [1  0.17];

% Vbias/%O2
np23 = 0.25;
dp23 = [1  0.41];

% Pressure/%O2
np33 = 0.024;
dp33 = [1  0.40];

% 1st order pade approximation to O2 delay
[ndelayO,ddelayO] = pade(0.77,1);

% obtain A,B,C,D: state space of the plant in engineering units
%RIE_withO2
[A,B,C,D] = linmod('RIE_withO2');

% Input scalings, based upon nominal operating point values
% RF Power: 1000 watts
% Throttle: 12.5% open
% O2; 5%
in_scale = diag([1000  12.5  5]);

% Output scalings, based upon nominal operating point values
% [F]: 16.52 (unitless)
% Vbias: 340 volts
% Presssure:  17.83 mTorr
out_scale = diag([16.52  340  17.83]);

% create state space description of the scaled plant
As = A;  % input an output scaling doesn't affect the state variables
Bs = B*in_scale;
Cs = inv(out_scale)*C;
Ds = inv(out_scale)*D*in_scale; 


% Aaw,Baw,Caw,Daw:  state space description for the compensator with
% antiwindup logic in scaled coordinates
[ns,ni] = size(Bs);
[no,ns] = size(Cs);


% weighting matrices
% Assume Q of the form Q = alpha*Cs'*Cs + Qw
% Since I don't have you do the optional parts necessary for the
% observer design, use V = Bs*Bs' and W = I.
alpha = 5;
Qw = diag([1 1 1]);
R = diag([1 10 1]);
V = Bs*Bs';
W =  eye(no);
 
% Augment the plant with integrators
% \dot{x} = A x + B u
% \dot{q} = y - r
%      y  = C x
Aaug = [As, zeros(ns,no); Cs, zeros(no,no)];
Baug = [Bs; zeros(no,ni)];
Caug = [Cs, zeros(no,no)];
Daug = zeros(no,ni);

% use LQR to stabilize the system with augmented integrators
% using state feedback
Qaug = [alpha*Cs'*Cs, zeros(ns,no); zeros(no,ns), Qw];
Kaug = lqr(Aaug,Baug,Qaug,R);
eig(Aaug-Baug*Kaug);

% Use LTR to design an observer
L = lqr(As',Cs',V,W)';
eig(As-L*Cs);

nas = ns+no;
K1 = Kaug(:,1:ns);  % state feedback gain for the plant states
K2 = Kaug(:,ns+1:nas);  % state feedback gains for the integrator states

% State space description for compensator with antiwindup added
% \dot{xhat} = ...
%   \dot{v}  = ...
%         u  = v + eps_act 
Aaw = [As-L*Cs, Bs;
       -K1*(As-L*Cs), -K1*Bs];
Baw = [L, zeros(ns, no), Bs;
       -(K1*L+K2), K2, (tau*eye(3)-K1*Bs)];
Caw = [zeros(no,ns), eye(no)];
Daw = [zeros(no), zeros(no), eye(no)];


% check closed loop system eigenvalues when integrator is not saturated
Bcy = Baw(:,1:no);
Bcr = Baw(:,no+1:2*no);

% State space description for closed-loop system
%    \dot{x} = ...
% \dot{xhat} = ...
%    \dot{v} = ... 
Acl = [As  Bs*Caw;
       Bcy*Cs  Aaw];
Bcl = [zeros(ns,no);
       Bcr];
Ccl = [Cs zeros(no,ns+no)];
Dcl = zeros(no,ni);

% eig(Acl) should yield the SF eigenvalues + the observer eigenvalues
eig(Acl);

% simulate the control algorithm with antiwindup logic added
% Note the plant in this simulation must be in engineering units
sim('RIE_simulate_AW');

sensornames = str2mat('pwr','thr','pO2','[F]','Vbias','Pres');
sigs = 6;
row = 3;
col = 2;
data = youtAW;
data = [data(:,1) data(:,4) data(:,2) data(:,5) data(:,3) data(:,6)];
sensornames = str2mat(sensornames(1,:), ...
                      sensornames(4,:), ...
                      sensornames(2,:), ...
                      sensornames(5,:), ...
                      sensornames(3,:), ...
                      sensornames(6,:));

t = linspace(0,300,500);
Fcommand = zeros(1, length(t));
for i = 1:length(t)
    if t(i) < 20
        Fcommand(i) = 15;
    end
    if  20 <= t(i) && t(i) < 70
        Fcommand(i) = 25;
    end
    if  70 <= t(i) && t(i) < 120
        Fcommand(i) = 15;
    end
    if  120 <= t(i) && t(i) < 180
        Fcommand(i) = 40;
    end
    if  180 <= t(i) && t(i) <= t(length(t))
        Fcommand(i) = 15;
    end
end

figure(1); clf;
plot(t,Fcommand,'-');
xlabel('time, seconds');
title('Flourine step commands');
grid;
axis([0 300 0 50]);
defaultratio_ppt;

figure(2); clf;
set(gcf, 'position', [11   155   671   584]);
for f = 0:ceil(sigs/(row*col))-1,
    for i = 1:min([row*col sigs-f*(row*col)]),
        subplot(row,col,i)
        plot(time, data(:,f*(row*col)+i),'-', 'color', [0.7 0.7 0.7], 'linewidth', 2)
        grid on
        ylabel([sensornames(f*(row*col)+i,:)])
        if i == 1
            title(['\tau = ',num2str(tau)])
%             ylim([600 1400]);
        end
        if i == 2
            title(['\tau = ',num2str(tau)])
        end
        if i == 5
            xlabel('time, seconds')
        end
        if i == 6
            xlabel('time, seconds')
        end
        if i == 3
%             ylim([8 16]);
        end
        if  i == 4
%             ylim([250 450]);
        end
    end
end


sensornames = str2mat('vpwr','vthr','vpO2');
sigs = 3;
row = 3;
col = 1;
data = voutAW;
data = [data(:,1) data(:,2) data(:,3)];
sensornames = str2mat(sensornames(1,:), ...
                      sensornames(2,:), ...
                      sensornames(3,:));

figure(2);
% set(gcf, 'position', [698   154   590   585]);
col_2 = [1 3 5];
for f = 0:ceil(sigs/(row*col))-1,
    for i = 1:min([row*col sigs-f*(row*col)]),
        subplot(3,2,col_2(i)); hold on;
        plot(time, data(:,f*(row*col)+i),'k--')
        grid on
%         ylabel([sensornames(f*(row*col)+i,:)])
        if i == 1
%             title(['integrator states, \tau =',num2str(tau)]);
%             ylim([0 2000]);
              legend('u*', 'v');
        end
        if i == 3
%             xlabel('time, seconds');
%             ylim([0 15]);
            %line([t(1) t(end)], [12.5 12.5], 'color', [0.5 0.5 0.5]);
        end
        if i == 2
%             ylim([8 16]);
        end
    end
end



% figure(3); clf;
% set(gcf, 'position', [698   154   590   585]);
% for f = 0:ceil(sigs/(row*col))-1,
%     for i = 1:min([row*col sigs-f*(row*col)])
%         subplot(row,col,i)
%         plot(time, data(:,f*(row*col)+i),'-')
%         grid on
%         ylabel([sensornames(f*(row*col)+i,:)])
%         if i == 1
%             title(['integrator states, \tau =',num2str(tau)]);
% %             ylim([0 2000]);
%         end
%         if i == 3
%             xlabel('time, seconds');
% %             ylim([0 15]);
%             %line([t(1) t(end)], [12.5 12.5], 'color', [0.5 0.5 0.5]);
%         end
%         if i == 2
% %             ylim([8 16]);
%         end
%     end
% end

