clear all
close all
clc
format compact


%% ================================================================== %%
G0 = 0.4; % mm
R = 2.2;  % ohms
L = .00368; % H
I0 = 0.5; % A
kI = 7*10^4; % mm/As^2
kx = 8.74*10^4; % 1/s^2

A = [0   1   0;
     kx   0   kI;
     0   -I0/G0   -R/L];

B = [0;0;1/L];


%% ================================================================== %%
% full state feedback
Q = diag([1 1 1000]);
R = 20; % large R: expensive control

K = lqr(A,B,Q,R)

Lsf = ss(A,B,K,0);
Ssf = 1/(1+Lsf);
Tsf = 1-Ssf;

% to plot the bound at +/-10 db
bndss = minreal(ss(0,0,0,sqrt(.1)));

figure(1); clf;
bodemag(Ssf,'b-',Tsf,'r-.', bndss,'k-',inv(bndss),'k-')
legend('S_{sf}','T_{sf}',3)
title('state feedback')
set(gca, 'fontsize', 10);
% defaultratio_ppt(1.35);
xlim([1e0 1e6])
ylim([-120 20]);


%% ================================================================== %%
% to use current measurement only
C = [0 0 1];
P = ss(A,B,C,0); % non minimum phase zero!

tzero(P)

OO = obsv(A,C);
rank(OO)
 
Q = diag([1 1 1000000000]);
R = 20000000; % large R: expensive control

K = lqr(A,B,Q,R)

Lsf = ss(A,B,K,0);
Ssf = 1/(1+Lsf);
Tsf = 1-Ssf;

q = 1000000000;% large q: small W, large observer gain L
V = q*B*B';
W = eye(size(C,1)); % large W: don't trust measurement, small observer gain L
L = lqe(A,eye(3),C,V,W) %L1 = lqr(A',C',V,W)

% L1 = lqrr(A',C',V,W)'

A_obs = A-B*K-L*C;
B_obs = L;
C_obs = K;
D_obs = 0;
Cobs = ss(A_obs,B_obs,C_obs,D_obs); % Cobs = ss(A-B*K-L*C,L,K,0);


LI = Cobs*P;
SI = 1/(1+LI);
TI = 1-SI;

figure(2); clf;
bodemag(Ssf,'b-',SI,'g--',Tsf,'r-.',TI,'c',bndss,'k-',inv(bndss),'k-')
legend('S_{sf}','S_I','T_{sf}','T_I',3)
title('current feedback only')
set(gca, 'fontsize', 10);
% defaultratio_ppt(1.35);
xlim([1e0 1e6])
ylim([-120 40]);


%% ================================================================== %%
% to use current and position measurements measurement only
C = [1 0 0;
     0 0 1];

Q = diag([1 1 1000]);
R = 20;

K = lqr(A,B,Q,R);

Lsf = ss(A,B,K,0);
Ssf = 1/(1+Lsf);
Tsf = 1-Ssf;

q = 70000; % V/W large: clean measurement, larege L
V = q*B*B';
W = eye(size(C,1));
L = lqe(A,eye(3),C,V,W);

A_obs = A-B*K-L*C;
B_obs = L;
C_obs = K;
D_obs = 0;
Cobs = ss(A_obs,B_obs,C_obs,D_obs);

P = ss(A,B,C,0);

LI = Cobs*P;
SI = 1/(1+LI);
TI = 1-SI;

figure(3); clf;
bodemag(Ssf,'b-',SI,'g--'); hold on;
bodemag(Tsf,'r-.',TI,'c',bndss,'k-',inv(bndss),'k-')
title('current and position feedback')
legend('S_{sf}','S_I','T_{sf}','T_I',3)
set(gca, 'fontsize', 10);
% defaultratio_ppt(1.35);
xlim([1e0 1e6])
ylim([-120 20]);


