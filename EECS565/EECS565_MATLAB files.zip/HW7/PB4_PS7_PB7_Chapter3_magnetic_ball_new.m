clear all;
close all;
clc;
format compact;
format short e %format: 8.0250e+000

% plant for the magnetic ball problem
A = [0 1 0;
    64.4 0 -16;
    0 0 -100];
B = [0;
    0;
    100];
C = [1 0 0];
D = [0];

% disturbance description
E=B; % range(E) belongs to range(B)
F=0;

n = size(A,1); % #plant states
p = size(B,2); % #inputs
q = size(C,1); % #outputs
m = size(E,2); % #disturbance states

plant_eigenvalues = eig(A)
plant_zeros = tzero(A,B,C,D)

%% ================================================================== %%
% check the feasibility conditions 
rank([A B;C zeros(size(C,1),size(B,2))]) - (n+q)
rank([A E;C F]) - (n+m)

psf = [-6+6*1i   -6-6*1i   -20]*3;
pobs = [psf*2 -5]*3;

% if the feasibility conditions are satisfied
% then choose K, L, G, H, so that the control signal is given by
% u = -K*xhat + G*r + H*dhat and L is the estimator gain
K = place(A,B,psf);

Aaug = [A,               E;
     zeros(q, n), zeros(q, m)];
Caug = [C F];
L = place(Aaug',Caug',pobs).';
L1 = L(1:3);
L2 = L(4);

G = (C*((-A+B*K)^(-1))*B)^(-1); %eq(3.52)
H = -G*(C*((-A+B*K)^(-1))*E+F); %eq(3.53)

%% ================================================================== %%
% Td->u
s = tf('s');

% p.109: bias estimation
A1 = A-L1*C-B*K;
P = C*((s*eye(3)-A)^-1)*B;
Cobs = H*L2/s*(C*((s*eye(3)-A1)^-1)*L1-eye(1))+K*((s*eye(3)-A1)^-1)*L1;
S = minreal(1/(1+P*Cobs));

zero_S = zero(S)
pole_S = pole(S)


