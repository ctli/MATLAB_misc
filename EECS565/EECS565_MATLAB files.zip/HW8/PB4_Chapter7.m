

 
% Make state space description of full order booster vehicle

A = zeros(12,12);
A(1,1) = 1.386;
A(2,2) = -1.401;
A(3:4,3:4)=[-0.1285 12.83;
            -12.83  -0.1285];
A(5:6,5:6)=[-0.2126 21.25;
            -21.25  -0.2126];
A(7:8,7:8)=[-0.2247 22.47;
            -22.47  -0.2247];			
A(9:10,9:10)=[-0.2820 28.19;
            -28.19  -0.2820];		
A(11:12,11:12)=[-0.3979 39.79;
            -39.39  -0.3979];	
			
B = [10.21;9.804;-17.6;-5.853;1.893;-12.64;-1.565; ...
-0.4038;-15.47;-24.52;35.8;13.53];

C = [0.0499 0.0487 -0.01862 -0.006399 -0.001342 0.008392 ...
-0.01809 -0.004859 -0.002462 -0.003988 -0.002187 -0.0008516];

D=0;

% Make reduced order booster model by residualizing the flex modes

[Ar,Br,Cr,Dr] = modred;

[numPr,denPr] = ss2tf(Ar,Br,Cr,Dr);

% compute ORHP poles of reduced plant

Pr_poles = eig(Ar);
% pick the unstable pole
p =  

% compute NMP zeros of reduced plant
Pr_zeros = tzero(Ar,Br,Cr,Dr);
% pick the NMP zero
z = 


omega = logspace(-1,2,300);

% make weighting using Butterworth filters
n =
k = 
omega1 = 
omega2 = 
[numb1,denb1] = butter(n,omega1,'s');
[numb2,denb2] = butter(n,omega2,'s');
% only the coefficient of the constant term in the numerator is nonzero
% hence eliminate all the higher powers of s that have zero coefficients
% this is needed to apply the minreal command later
numb1 = numb1(length(numb1));
numb2 = numb2(length(numb2));
numw = k*conv(denb1,numb2);
denw = conv(numb1,denb2);

[magw,phasew]=bode(numw,denw,omega);

% determine frequency range (w0-infty) over which magw > 1
clear omega1 magw1
for i = 1:length(omega)
    if magw(i) > 1
        omega1(i-k1)  = omega(i);
        magw1(i-k1) = magw(i);
    else
        k1 = i;
    end    
end    
omega0 = omega1(1);

% compute weighting evaluated at the ORHP plant pole
% use the polyval command
Wp = 

% compute Blaschke product of NMP plant zeros
% evaluated at the ORHP plant pole
%  Bz(p) = (z-p)/(z+p)

Bz_p = 

% compute size of optimal WT

gamma = 


% compute the minimum phase part of the reduced plant
% P(s) = P_m(s)B_z(s)
% note this formula holds only for this example

num_Bz = [-1 z];
den_Bz = [1 z];

numPrm = conv(numPr,den_Bz);
denPrm = conv(denPr,num_Bz);
[numPrm,denPrm] = minreal(numPrm,denPrm); % why is this needed?

% compute open loop transfer function, where W is the weighting 
%   L = gamma*Bz(s)/(W-gamma*Bz(s))
numL = 
denL = 

[magL,phaseL] = bode(numL,denL,omega);


figure(1)
clf

subplot(2,1,1)
loglog(omega,magL,'-',omega1,(1./(magw1-1)),'-.')

ylabel('magnitude')
title('Bode plots of L = PC')
legend('| L |','(|W_T|-1)^{-1}, |W_T|>1',3)

subplot(2,1,2)
semilogx(omega,phaseL)
xlabel('\omega, rad/sec')
ylabel('degrees')


% compute the controller

numC = 
denC = 

[numC,denC] = minreal(numC,denC);  % why is this needed?

format short e
C_zeros = roots(numC);
C_poles = roots(denC);

[magC,phaseC] = bode(numC,denC,omega);

figure(2)
clf

subplot(2,1,1)
loglog(omega,magC,'-')

ylabel('magnitude')
title('Bode plot of controller')
 

subplot(2,1,2)
semilogx(omega,phaseC)
xlabel('\omega, rad/sec')
ylabel('degrees')


% plot out weighted complementary sensitivity 
% of the optimal design

figure(3)
clf

numT = conv(numPr,numC);
denT = numT + conv(denPr,denC);

numWT = conv(numw,numT);
denWT = conv(denw,denT);

[magWT,denWT] = bode(numWT,denWT,omega);

loglog(omega,magWT)
axis([omega(1) omega(length(omega)) .1 100])
xlabel('\omega, rad/sec')
ylabel('magnitude')
title(['optimal weighted complementary sensitivity, \gamma = ',num2str(gamma)])

