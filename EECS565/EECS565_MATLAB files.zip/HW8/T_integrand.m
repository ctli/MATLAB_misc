function x = T_integrand(omega1,p,numw,denw)

[mag1,phase1] = bode(numw,denw,omega1);
for i = 1:length(omega1)
   x(i) = log(mag1(i))*(2*p/(p^2 + omega1(i)^2));
end


