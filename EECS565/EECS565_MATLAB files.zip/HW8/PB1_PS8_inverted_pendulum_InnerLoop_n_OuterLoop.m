clear all
close all
clc
format compact

omega = logspace(-1,2, 500);

% parameters of the inverted pendulum plant
L =1;
g = 10;
M = .5;
m = .5;

% compute state space description of the plant
AP = [0 1 0 0;
      0 0 -m*g/M 0;
      0 0 0 1;
      0 0 (M+m)*g/(M*L) 0];
BP = [0;
     1/M;
     0 ;
     -1/(M*L)];
CP = [1 0 0 0;
      0 0 1 0];% output 1 = position, output 2 = theta
DP = 0;
% P = ss(AP,BP,CP,DP);

s = tf('s');
% P = CP*(s*eye(4)-AP)^-1*BP
P = [tf([2 0 -20],[1 0 -20 0 0]);
     tf(-2,[1 0 -20])];

% zero location
z = tzero(P);

% pole location
p = pole(P);

% plant transfer functions
P1 = P(1,1); %P_y_u
% [magP1,phaseP1] = bode(P1,omega);

P2 = P(2,1);%P_theta_u


%% ================================================================== %%
% inner, pendulum loop, controller
% sisotool(P2)
C2 = -70*(s+4.4721)/(s+20); % lead filter with a huge gain to get 0.5 stability radius

% Nyquist and Bode plots for closing inner loop
L2 = C2*P2;
[mL2,pL2] = bode(L2,omega);

figure(1); clf;
nyquist(L2, 'k'); 
hold on;
circle = rsmak('circle', 0.5, [-1 0]); % rsmak('circle',radius,center)
fnplt(circle,':k',[],1,[]); % FNPLT(F,SYMBOL,INTERV,LINEWIDTH,JUMPS)
plot(-1,0, 'r+');
axis('equal')
% axis('square')
xlabel('real')
ylabel('imaginary')
title('Nyquist plot for inner loop stabilization, L_2 = C_2P_2')
set(gcf, 'position', [260   158   476   368]);

% figure(2); clf;
% bode(L2);
% title('Bode plot for inner  loop stabilization, L_2 = C_2P_2')
% temp = allmargin(L2);
% cross_over_freq = temp.PMFrequency  % crossover frequency: 0db @ OL bode plot

% sensitivity and complentary sensitivity functions to compute stability margin
S2 = (1+L2)^-1;
T2 = 1-S2;

% calculate stability radius as the radius of the circle
% centered at the critical point that is avoided by the Nyquist plot
[mag,phase] = bode(S2,omega);
mag = squeeze(mag);
stab_rad2 = 1/max(mag)

% figure(3); clf;
% bodemag(S2,'k-',T2,'k--',omega)
% legend('S_2','T_2',3)
% title(['inner loop, stability radius = ',num2str(stab_rad2)])
% set(gcf, 'position', [260   158   476   368]);

%% ================================================================== %%
% outer, cart loop, controller
% C1 = C_cancel*C_stable*C_proper

% Nyquist plot to stabilize the cart with inner loop closed
% first get state description of P_1S_2
P1S2 = minreal(P1*S2);
P1S2_zeros = tzero(P1S2)
P1S2_poles = pole(P1S2)

z_stable = P1S2_zeros(real(P1S2_zeros)<0);
p_stable = P1S2_poles(real(P1S2_poles)<0);

nC_cancel = poly(p_stable);
dC_cancel = poly(z_stable);
C_cancel = tf(nC_cancel, dC_cancel);
C_z = tzero(C_cancel);
C_p = pole(C_cancel);

% remaining system
Z = minreal(P1S2*C_cancel)
nZ = poly(tzero(Z));
dZ = poly(pole(Z));
% sisotool(Z)

[a,b,c,d] = tf2ss(nZ,dZ);
wn = 1.5;
zeta = 0.5;
psf = roots([1, 2*wn*zeta, wn^2])*1.25
pobs = 2*psf;
K = place(a,b,psf);
L = place(a',c',pobs)';
Cobs = minreal(K*(s*eye(2)-a+b*K+c*L)^-1*L)
pole(Cobs)
tzero(Cobs)

observer = reg(ss(a,b,c,d),K,L);
Tobs = feedback(ss(a,b,c,0), observer, +1);
[nTz dTz] = ss2tf(Tobs.a, Tobs.b, Tobs.c, Tobs.d)
Tz = tf(nTz,dTz)
pole(Tz)

figure(20);
step(Tz)

Tz1 = minreal(Cobs*Z/(1+Cobs*Z)) %not working
pole(Tz1)

%% ========================
C_stable = Cobs;
C1 = minreal(C_cancel*C_stable/(s+5)); % 

C1_zeros = tzero(C1)
C1_poles = pole(C1)

figure(4); clf;
plot(real(P1S2_zeros),imag(P1S2_zeros),'o',real(P1S2_poles),imag(P1S2_poles),'x');
xlabel('real')
ylabel('imag')
title('poles and zeros, P_1S_2')
legend('P_1S_2 zeros','P_1S_2 poles');

figure(5); clf;
plot(real(P1S2_zeros),imag(P1S2_zeros),'o',real(P1S2_poles),imag(P1S2_poles),'x',...
     real(C1_zeros),imag(C1_zeros),'d',real(C1_poles),imag(C1_poles),'s');
xlabel('real')
ylabel('imag')
title('poles and zeros, P_1S_2 and C_1')
legend('P_1S_2 zeros','P_1S_2 poles','C_1 zeros','C_1 poles', 2)
 
C1P1S2 = C1*P1*S2;

figure(6); clf;
plot(real(P1S2_zeros),imag(P1S2_zeros),'o',real(P1S2_poles),imag(P1S2_poles),'x',...
     real(C1_zeros),imag(C1_zeros),'d',real(C1_poles),imag(C1_poles),'s');
legend('P_1S_2 zeros','P_1S_2 poles','C_1 zeros','C_1 poles')
xlabel('real')
ylabel('imag')
title('root locus, C_1P_1S_2')
hold on
k= logspace(-2,2);
r = rlocus(C1P1S2,k);
 
plot(real(r),imag(r),'k+')
axis([-30 10 -20 20])
axis('equal')

figure(7); clf;
nyquist(C1P1S2);
hold on;
circle = rsmak('circle', 0.5, [-1 0]); % rsmak('circle',radius,center)
fnplt(circle,':k',[],1,[]); % FNPLT(F,SYMBOL,INTERV,LINEWIDTH,JUMPS)
plot(-1,0, 'r+');
axis([-2 2 -2 2])
xlabel('real')
ylabel('imaginary')
title('Nyquist plot of C_1P_1S_2 = telda_L1')
axis equal

figure(8); clf;
w = logspace(-1,2);
bode(C1P1S2,w)
title('Bode  plot of C_1P_1S_2 = telda_L1')
 

SO11 = (1+C1P1S2)^-1;
[mSO11,pSO11] = bode(SO11,omega);
stab_rad11 = 1/max(mSO11);
figure(9); clf;
bodemag(SO11,'-',omega)
xlabel('\omega, rad/sec')
title(['Outer loop sensitivity function, S_{O11}, stability radius = ',num2str(stab_rad11)])
 
%% =================================================================== %%
% compute state space description of the controller
C = [C1 C2];

% calculate the input transfer functions
LI = C*P;
SI = 1/(1+LI);

[magSI,phaseSI] = bode(SI,omega);
stab_radI = 1/max(squeeze(magSI))


figure(10); clf;
nyquist(LI);
axis([-2 2 -2 2])
% axis('square')
axis('equal')
xlabel('real')
ylabel('imaginary')
title('Nyquist plot of input open loop transfer function L_I')
 
figure(11); clf;
bodemag(SI,omega);
xlabel('\omega, rad/sec')
title(['Input Sensitivity Function S_I, stability radius = ',num2str(stab_radI)])

%% =================================================================== %%
% calculate the output transfer functions
LO = [P1S2; P2]*C;
SO = (1+LO)^-1;
TO = minreal(LO/(1+LO));
pole_TO = pole(TO)

figure(12); clf;
sv_SO = sigma(SO,omega);
[magSO,phaseSO] = bode(SO,omega);
magSO = squeeze(magSO);

magSO11 = magSO(1,1,:);
magSO12 = magSO(1,2,:);
magSO21 = magSO(2,1,:);
magSO22 = magSO(2,2,:);
loglog(omega,sv_SO(1,:),'k-',omega,sv_SO(2,:),'k:', 'linewidth', 2); hold on;
loglog(       omega,magSO11(:),'k-',omega,magSO12(:),'k--',...
       omega,magSO21(:),'k-.',omega,magSO22(:),'k:')
legend('\sigma_{max}(S_O)','\sigma_{min}(S_O)','|S_{O11}|','|S_{O12}|','|S_{O21}|','|S_{O22}|',4)
title('output sensitivity function S_O')
xlabel('\omega, rad/sec')

figure(13); clf;
bodemag(S2,'b-',SO11,'g--',SI,'r-.',omega)
%loglog(omega,mS2,'-',omega,magSO11(:),'--',omega,magSI,'-.')
legend('|S_2|','|S_{O11}|','|S_I|',4)
title('|S_I| = |S_{O11}||S_2|')
xlabel('\omega, rad/sec')

figure(14); clf;
[y,t,x] = step(TO(:,1));
y1 = y(:,1);
y2 = y(:,2);
plot(t,y1 ,'-',t,y2 ,'--')
xlabel('time, seconds')
title('closed loop cart step response')
legend('cart position','pendulum angle',4)


