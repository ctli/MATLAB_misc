clear all
close all
clc
format compact
 
omega = logspace(-1,2,500);

%% ================================================================== %%
% Make state space description of full order booster vehicle
A = zeros(12,12);
A(1,1) = 1.386;
A(2,2) = -1.401;
A(3:4,3:4)=[-0.1285 12.83;
            -12.83  -0.1285];
A(5:6,5:6)=[-0.2126 21.25;
            -21.25  -0.2126];
A(7:8,7:8)=[-0.2247 22.47;
            -22.47  -0.2247];			
A(9:10,9:10)=[-0.2820 28.19;
            -28.19  -0.2820];		
A(11:12,11:12)=[-0.3979 39.79;
            -39.39  -0.3979];	
			
B = [10.21;9.804;-17.6;-5.853;1.893;-12.64;-1.565; ...
-0.4038;-15.47;-24.52;35.8;13.53];

C = [0.0499 0.0487 -0.01862 -0.006399 -0.001342 0.008392 ...
-0.01809 -0.004859 -0.002462 -0.003988 -0.002187 -0.0008516];

D=0;

[numP,denP] = ss2tf(A,B,C,D);
P = tf(numP,denP); % same pzmap as fig7.11


%% ================================================================== %%
% Make reduced order booster model by residualizing the flex modes
elim = 3:12; % eliminate last 7 states
[Ar,Br,Cr,Dr] = modred(A,B,C,D,elim);
[numPr,denPr] = ss2tf(Ar,Br,Cr,Dr);
Pr = tf(numPr, denPr); % same pzmap as fig7.11

figure(1); clf;
pzmap(P, Pr);
% xlim([-5 5]);

figure(2); clf;
bb = bodeoptions;
bb.MagScale = 'log';
bb.MagUnits = 'abs';
bb.PhaseMatching = 'on';
bodeplot(P, 'k-', Pr, 'k--', omega, bb);
legend('high order (P)', 'reduced order (Pr)', 3);
set(gcf, 'position', [260   158   476   368]);

% compute ORHP poles of reduced plant
Pr_poles = eig(Ar)
p = Pr_poles(real(Pr_poles)>0)   % pick the unstable pole

Pr_zeros = tzero(Ar,Br,Cr,Dr)
z = Pr_zeros(real(Pr_zeros)>0)    % pick the NMP zero


%% ================================================================== %%
% uncertainty
Delta = (Pr-P)/P;
[Dm, Dp] = bode(Delta);


%% ================================================================== %%
% make weighting using Butterworth filters
n = 10;
k = 0.08;
omega1 = 5;
omega2 = 9; 
[numb1,denb1] = butter(n,omega1,'s');
[numb2,denb2] = butter(n,omega2,'s');
numw = k*conv(denb1,numb2);
denw = conv(numb1,denb2);
W = tf(numw,denw);

figure(3); clf;
bodemag(Delta, 'k-', W, 'k-.', omega, bb);
legend('\Delta_r', 'W_T', 2);
set(gcf, 'position', [260   158   476   368]);

%% ================================================================== %%
% determine frequency range (w0-infty) over which magw > 1
[magw,phasew]=bode(W,omega);
magw = squeeze(magw);
[id, value] = find(magw>=1, 1, 'first');
omega0 = omega(id)

% compute Blaschke product of NMP plant zero
% evaluated at the ORHP plant pole
%  Bz(p) = (z-p)/(z+p)
unstable_pole = linspace(.1,10,20);
for k = 1:length(unstable_pole)
    p1 = unstable_pole(k);
    integral = quadl('T_integrand',omega0,100,[],[],p1,numw,denw);
    Bz_p = (z-p)/(z+p);
    Theta(k) = -angle((p1-1i*omega0)/(p1+1i*omega0));
    log_bound_T(k) = (1/Theta(k))*(pi*log(1/abs(Bz_p)) + integral);
    bound_T(k) = exp(log_bound_T(k));
end
largest_p = interp1(bound_T, unstable_pole, 2)

figure(4); clf;
loglog(unstable_pole,bound_T, 'k');
ylabel('||T||_{\infty}');
xlabel('p, rad/sec');
line([0.1 10], [2 2], 'linestyle','--', 'color', 'k');
set(gcf, 'position', [260   158   476   368]);
annotation('textarrow',[0.5567 0.6324],[0.3115 0.2092],...
    'TextEdgeColor','none',...
    'String',{['largest unstable pole =', num2str(largest_p)]});
annotation('textbox',[0.2521 0.2001 0.1176 0.07165],...
    'String',{'||T||_{\infty}=2'},...
    'FitBoxToText','off',...
    'LineStyle','none');

% figure(5); clf;
% semilogx(unstable_pole,Theta);
% title('weighted length of interval (0, \omega_0)');
% ylabel('degrees');
% xlabel('p, rad/sec');
% set(gcf, 'position', [260   158   476   368]);

%% ================================================================== %%
%% less stiff vehicle
% shift the weighting function to a lower frequency: WT(s) = WT(2s)
omega2 = omega/2;
[mD pD]= bode(Delta, omega);
mD = squeeze(mD);

figure(6); clf;
bodemag(Delta, 'k-', W, 'k-.', omega, bb); hold on;
loglog(omega2, mD, 'k', 'linewidth', 2);
set(gcf, 'position', [260   158   476   368]);

numw_new = [2^20 2^19 2^18 2^17 2^16 2^15 2^14 2^13 2^12 2^11 2^10 2^9 2^8 2^7 2^6 2^5 2^4 2^3 2^2 2^1 2^0].*numw;
denw_new = [2^20 2^19 2^18 2^17 2^16 2^15 2^14 2^13 2^12 2^11 2^10 2^9 2^8 2^7 2^6 2^5 2^4 2^3 2^2 2^1 2^0].*denw;
W_new = tf(numw_new,denw_new);
[mWnew pWnew]= bode(W_new, omega);
mWnew = squeeze(mWnew);
figure(6); hold on
loglog(omega, mWnew, 'k-.', 'linewidth', 2);
legend('\Delta_r', 'W_T', '\Delta_{r,new}', 'W_{T,new}', 2);

unstable_pole = linspace(.1,10,20);
for k = 1:length(unstable_pole)
    p1 = unstable_pole(k);
    integral = quadL('T_integrand',omega0,100,[],[],p1,numw_new,denw_new);
    Bz_p = (z-p)/(z+p);
    Theta(k) = -angle((p1-1i*omega0)/(p1+1i*omega0));
    log_bound_T(k) = (1/Theta(k))*(pi*log(1/abs(Bz_p)) + integral);
    bound_T_new(k) = exp(log_bound_T(k));
end
largest_p_new = interp1(bound_T_new, unstable_pole, 2)

figure(7); clf;
loglog(unstable_pole,bound_T, 'k'); hold on;
loglog(unstable_pole,bound_T_new, 'k', 'linewidth', 2);
legend('old bound', 'new bound');
ylabel('||T||_{\infty}');
xlabel('p, rad/sec');
line([0.1 10], [2 2], 'linestyle','--', 'color', 'k');
set(gcf, 'position', [260   158   476   368]);
annotation('textarrow',[0.5483 0.6029],[0.3696 0.2147],...
    'TextEdgeColor','none',...
    'String',{['largest unstable pole =', num2str(largest_p_new)]});

