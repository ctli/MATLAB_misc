clear all
close all
clc
format compact

omega = logspace(-1,2,300);

%% ================================================================== %%
% Make state space description of full order booster vehicle
A = zeros(12,12);
A(1,1) = 1.386;
A(2,2) = -1.401;
A(3:4,3:4)=[-0.1285 12.83;
            -12.83  -0.1285];
A(5:6,5:6)=[-0.2126 21.25;
            -21.25  -0.2126];
A(7:8,7:8)=[-0.2247 22.47;
            -22.47  -0.2247];			
A(9:10,9:10)=[-0.2820 28.19;
            -28.19  -0.2820];		
A(11:12,11:12)=[-0.3979 39.79;
            -39.39  -0.3979];	
			
B = [10.21;9.804;-17.6;-5.853;1.893;-12.64;-1.565; ...
-0.4038;-15.47;-24.52;35.8;13.53];

C = [0.0499 0.0487 -0.01862 -0.006399 -0.001342 0.008392 ...
-0.01809 -0.004859 -0.002462 -0.003988 -0.002187 -0.0008516];

D=0;

[nP,dP] = ss2tf(A,B,C,D);
P = tf(nP,dP); % same pzmap as fig7.11


%% ================================================================== %%
% Make reduced order booster model by residualizing the flex modes
elim = 3:12; % eliminate last 7 states
[Ar,Br,Cr,Dr] = modred(A,B,C,D,elim);
[nPr,dPr] = ss2tf(Ar,Br,Cr,Dr);
Pr = tf(nPr, dPr); % same pzmap as fig7.11

% sisotool(Pr)

%% ================================================================== %%
% controller
nC =3.6*poly([-1.4]);
dC = poly([-2 0]);

% % Bode plot of controller
% figure(1); clf;
% [mC,pC] = bode(nC,dC,omega);
% subplot(2,1,1)
% loglog(omega,mC);
% title('gain of controller');
% ylabel('magnitude');
% subplot(2,1,2);
% semilogx(omega,pC);
% xlabel('\omega, rad/sec');
% ylabel('degrees');
% title('phase of controller');
% set(gcf, 'position', [260   158   476   368]);

% L, S, T for the reduced order plant
nLr = conv(nPr,nC);
dLr = conv(dPr,dC);
[nTr,dTr] = feedback(nLr,dLr,1,1);
[nSr,dSr] = feedback(1,1,nLr,dLr);

nominal_cloop_poles = roots(dTr)

% % root locus plot for nominal plant
figure(2); clf;
set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 7.3125    3.2604]);

subplot(1,2,1);
rlocus(nLr,dLr)
hold on
plot(real(nominal_cloop_poles),imag(nominal_cloop_poles),'ks', 'linewidth', 2)
title('Root Locus of Lr');
set(gca, 'position', [0.13 0.12 0.39 0.72]);

subplot(1,2,2); % zoom-in root locus
rlocus(nLr,dLr)
hold on
plot(real(nominal_cloop_poles),imag(nominal_cloop_poles),'ks', 'linewidth', 2)
axis([-9.6 1.5 -1 1]);
set(gca, 'position', [0.58 0.12 0.39 0.72]);
title('Zoom In');
legend('Lr locus', 'closed-loop poles', 2);

[mLr,pLr] = bode(nLr,dLr,omega);
[mSr,pSr] = bode(nSr,dSr,omega);
[mTr,pTr] = bode(nTr,dTr,omega);

%% ================================================================== %%
% make weighting using Butterworth filters
n = 10;
k = 0.08;
omega1 = 5;
omega2 = 9; 
[numb1,denb1] = butter(n,omega1,'s');
[numb2,denb2] = butter(n,omega2,'s');
numw = k*conv(denb1,numb2);
denw = conv(numb1,denb2);
W = tf(numw,denw);

% the uncertainty
Delta = (Pr-P)/P;
figure(3); clf;
bodemag(Delta, 'k-', W, 'k-.', omega);
legend('\Delta_r', 'W_T', 2);
set(gcf, 'position', [260   158   476   368]);

% determine frequency range (w0-infty) over which magw > 1
[magw,phasew]=bode(W,omega);
magw = squeeze(magw);
[id, value] = find(magw>=1, 1, 'first');
omega0 = omega(id)
omega1 = omega(id:end);
magw1 = magw(id:end);

% check to see whether open loop bandwidth specification is satisfied
% If it has, then the flex modes have been gain stabilized.
figure(4); clf;
loglog(omega,mLr,'k-',omega1,(1./(magw1-1)),'k-.')
ylabel('magnitude')
xlabel('\omega, rad/sec')
title('gain of L_r = P_rC')
legend('| L_r |','(|W|-1)^{-1}, |W|>1',2)
set(gcf, 'position', [260   158   476   368]);

% Nyquist plot with nominal (reduced order) plant
figure(5); clf;
[re,im] = nyquist(nLr,dLr);
plot(re,im,'b-',re,-im,'g-'); hold on;
circle = rsmak('circle', 1, [0 0]); % rsmak('circle',radius,center)
fnplt(circle,':k',[],1,[]); % FNPLT(F,SYMBOL,INTERV,LINEWIDTH,JUMPS)
plot(-1,0, 'r+');
title('nominal Nyquist plot');
axis('square');
xlabel('Real axis');
ylabel('Imag axis');
axis([-4 2 -3 3]);
axis equal

% make weighted complementary sensitivity function
figure(6); clf;
num_WTr = conv(numw,nTr);
den_WTr = conv(denw,dTr);
[magw,phasew] = bode(numw,denw,omega);
[mag_WTr,phase_WTr] = bode(num_WTr,den_WTr,omega);
loglog(omega,mTr,'k-',omega,magw,'k-.',omega,mag_WTr,'k--', 'linewidth', 1); hold on;
line([omega(1) omega(end)], [1 1], 'color', [0.5 0.5 0.5])
xlabel('\omega, rad/sec')
ylabel('magnitude')
title('weighted complementary sensitivity')
legend('| T_r |','| W |','| WT_r |',2)
set(gcf, 'position', [1463   96   476   368]);

% make true closed loop transfer functions to assess stability robustness
[nP,dP] = ss2tf(A,B,C,D);
nL = conv(nP,nC);
dL = conv(dP,dC);
[nT,dT] = feedback(nL,dL,1,1);
[nS,dS] = feedback(1,1,nL,dL);
true_cloop_poles = roots(dT);

[mL,pL] = bode(nL,dL,omega);
[mS,pS] = bode(nS,dS,omega);
[mT,pT] = bode(nT,dT,omega);

figure(7); clf;
loglog(omega,mL,'k-');
hold on;
line([omega(1) omega(end)], [1e0 1e0], 'color', [0.6 0.6 0.6]);
ylabel('magnitude')
xlabel('\omega, rad/sec')
title('Bode plots of L=PC')
set(gcf, 'position', [1493 81 476 368]);

figure(8); clf;
[re,im] = nyquist(nL,dL);
plot(re,im,'b-',re,-im,'r-'); hold on;
circle = rsmak('circle', 1, [0 0]); % rsmak('circle',radius,center)
fnplt(circle,':k',[],1,[]); % FNPLT(F,SYMBOL,INTERV,LINEWIDTH,JUMPS)
plot(-1,0, 'r+');
title('Nyquist plot of true system')
axis('square')
xlabel('Real axis')
ylabel('Imag axis')
axis([-2 2 -2 2])
set(gcf, 'position', [260   158   476   368]);

%% ================================================================== %%
figure(9); clf;
loglog(omega,mSr,'-',omega,mTr,'-.'); hold on;
loglog(omega,mS,'-',omega,mT,'-.', 'linewidth', 2);
xlabel('\omega, rad/sec')
ylabel('magnitude')
title('sensitivity and complementary sensitivity')
legend('|S_r|','|T_r|', '|S|','|T|', 3);
set(gcf, 'position', [260   158   476   368]);

figure(10); clf;
plot(real(nominal_cloop_poles),imag(nominal_cloop_poles),'s',...
     real(true_cloop_poles),imag(true_cloop_poles),'d');
legend('nominal poles','true poles',2)
xlabel('real')
ylabel('imaginary')
title('nominal and true closed loop pole locations');

