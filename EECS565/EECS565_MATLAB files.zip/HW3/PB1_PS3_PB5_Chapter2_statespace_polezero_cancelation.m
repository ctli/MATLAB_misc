clear all
close all
clc;
format compact

% % Problem 5(b), Chapter2, unstable plant
% disp('unstable plant');
% [A1,B1,C1,D1] = tf2ss(1, [1 -1])
% [b, a] = ss2tf(A1,B1,C1,D1);
% tf(b, a)
% disp('==========');
% 
% disp('controller');
% [A2,B2,C2,D2] = tf2ss([1 -1], [1 2])
% [b, a] = ss2tf(A2,B2,C2,D2);
% tf(b, a)
% disp('==========');

% Problem 5(c), Chapter2, stable plant
disp('stable plant');
[A1,B1,C1,D1] = tf2ss([1 -1], [1 2])
[b, a] = ss2tf(A1,B1,C1,D1);
tf(b, a)
disp('==========');

disp('controller');
[A2,B2,C2,D2] = tf2ss(1, [1 -1])
[b, a] = ss2tf(A2,B2,C2,D2);
tf(b, a)
disp('==========');

%% ===================================================================== %%
M = (1+D1*D2)^(-1);
N = (1+D2*D1)^(-1);

A3 = [A1-B1*D2*M*C1,       B1*N*C2
           -B2*M*C1, A2-B2*M*D1*C2]
B3 = [B1*D2*M;
      B2*M]
C3 = [M*C1, D1*N*C2]
D3 = D1*D2*M

eig(A3)

disp('==========');
Co = ctrb(A3,B3)
rank(Co)

disp('==========');
Ob = obsv(A3,C3)
rank(Ob)

