clear all;
close all;
clc;
format compact;


% This function makes the A,B,C,H,F matrices of the disk drive problem. 
% psf =  [-2.5 -2.6 -2.7 -2.8];
psf =  [-1+1i, -1-1i, -5, -6];
t = linspace(0,10,200);
r = sin(t) + 2*cos(t);
x0 = 0; % initial condition

% double integrator plant
A = [0 1;
     0 0];
B =  [0;
      1];
C = [2 0];
D = 0;

% omega = logspace(-1,1);
% [mag,phase] = bode(A,B,C,D,1,omega);
% figure(1); clf; 
% subplot(2,1,1)
% loglog(omega,mag)
% ylabel('magnitude')
% title('Bode plots of Disk Drive System')
% subplot(2,1,2)
% semilogx(omega,phase)
% xlabel('frequency, rad/sec')
% ylabel('phase, degrees')


%% ===================================================================== %%
% Augmented dynamics:
w0 = 1;
F = [0  1;
  -w0^2 0];
H = [0;
     1]; %arbitrafy choice

Aaug = [A zeros(size(A,1), size(F,2));
        H*C F];
Baug = [B;
        zeros(size(H,1), size(B,2))];
Caug = [C zeros(size(C))];
Kaug = place(Aaug, Baug, psf)

K = Kaug(1:2);
Kw = Kaug(3:4);

% closed loop equations
Acl = [A-B*K, -B*Kw;
         H*C,     F];
Bcl = [zeros(size(H,1), size(B,2));
      -H];
Ccl = [C zeros(size(C))];
Dcl =  0;

Cu = -Kaug;
Du = 0;

% simulate
[b a] = ss2tf(Acl,Bcl,Ccl,Dcl);
[y,x] = lsim(tf(b,a),r,t,x0);

[b a] = ss2tf(Acl,Bcl,Cu,Du);
[u,x] = lsim(tf(b,a),r,t,x0);   % to get u substitute -K for Ccl.

figure(2); clf;
plot(t,r,'-', 'color', [0.6 0.6 0.6], 'linewidth', 2);
hold on;
plot(t,u,'k:',t,y,'k--', 'linewidth', 2)
legend('reference r','input u','output y')
xlabel('time')
title('response of disk drive system to reference')
defaultratio_ppt('old axis');

disp('==========================================');
%% ===================================================================== %%
% transfer functions
% Tyu
s = tf('s');
disp('Tyu');
Tyu = Caug*((s*eye(size(Aaug))-Aaug)^(-1))*Baug

disp('==========================================');
% Tyr
disp('Tyr');
Tyr = Ccl*((s*eye(size(Acl))-Acl)^(-1))*Bcl
disp('zeros of Tyr');
zero(Tyr)
figure(3)
bode(Tyr)
title('Bode Diagram of TF from r to y');

disp('==========================================');
% Ter, from r to error
disp('Ter');
Ter = Tyr - 1
disp('zeros of Ter');
zero(Ter)

figure(4); clf;
[mag,phase,w] = bode(Ter);
mag = squeeze(mag); mag = 20*log10(mag);
phase = squeeze(phase); phase(phase>360) = phase(phase>360) - 360;

subplot(2,1,1);
semilogx(w,mag, 'k');
xlabel('frequency, rad/sec');
ylabel('magnitude, dB');
ylim([-150 50])
title('Bode Diagram of TF from r to e');

subplot(2,1,2);
semilogx(w,phase, 'k');
xlabel('frequency, rad/sec');
ylabel('phase,degrees');
ylim([90 315])
set(gca,'ytick', 90:45:360);


