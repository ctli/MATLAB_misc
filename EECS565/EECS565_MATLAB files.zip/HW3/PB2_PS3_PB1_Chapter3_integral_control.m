clear all;
close all;
clc;
format compact;

% Plant: 1/(s+3)
[A,B,C,D] = tf2ss(1, [1 3]);

%% ===================================================================== %%
% augmented system matrices
Aaug = [A 0;
        C 0];
Baug = [B;
        0];
Caug = [C 0];
Daug = 0;

desired_poles = [-5 -6];
Kaug = place(Aaug,Baug,desired_poles)
K = Kaug(1);
Ki = Kaug(2);

Acl = [A-B*K, -B*Ki;
           C,     0];
Bcl = [0;
       -1];
Ccl = [C 0];
Dcl = 0;
Tyr = ss(Acl,Bcl,Ccl,Dcl);

Cu = [-K -Ki];
Du = 0;
Tur = ss(Acl,Bcl,Cu,Du);

% simulate response of y and u to a step command
t = linspace(0,1.2,50);
y = step(Tyr,t);
u = step(Tur,t);

figure(1); clf;
plot(t,y,'k-',t,u,'k--');
xlim([0,t(length(t))]);
xlabel('time, seconds');
legend('output, y','control, u', 4);
title('step response with augmented integral control');
grid;
defaultratio_ppt;

% transfer function from r to y
s = tf('s');
Tyr = Ccl*(s*eye(2)-Acl)^(-1)*Bcl

% steady-state control is non-zero
u_ss = [-K -Ki]*(-Acl)^(-1)*[0;-1]

%% ===================================================================== %%
% add feedforward and see how it affects command response

% the correct feedforward should be: N = (C*(-A+B*K)^(-1)*B)^(-1)
N = [0 1 5 20];  % vector of (4) feedforward terms
z = -Ki./N; % vector of (4) zero locations

for i = 1:length(N)
    Acl = [A-B*K, -B*Ki;
               C,     0];
    Bcl = [B*N(i);
           -1];
    Ccl = [C 0];
    Dcl = 0;
    TyrN = ss(Acl,Bcl,Ccl,Dcl);
    
    Cu = [-K -Ki];
    Du = 0;
    TurN = ss(Acl,Bcl,Cu,Du);

    y(:,i) = step(TyrN,t);
    u(:,i) = step(TurN,t);
end
 
figure(2); clf;
set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 6.67, 2.8]);

subplot(1,2,1);
plot(t,y(:,1),'k-',t,y(:,2),'k:',t,y(:,3),'k-.',t,y(:,4),'k--', 'linewidth', 2)
xlim([0,t(length(t))])
grid
text(0.3, 2.2, 'step response of system output & control signal for different zero locations')
xlabel('time, seconds')
ylabel('y')
set(gca, 'position', [0.07 0.15 0.4 0.7]);

subplot(1,2,2);
plot(t,u(:,1),'k-',t,u(:,2),'k:',t,u(:,3),'k-.',t,u(:,4),'k--', 'linewidth', 2)
xlim([0 t(length(t))])
grid
% title('step response of control signal for different zero locations')
xlabel('time, seconds')
ylabel('u')
legend(['zero = ',num2str(z(1)), ' (N =', num2str(N(1)), ')'],...
       ['zero = ',num2str(z(2)), ' (N =', num2str(N(2)), ')'],...
       ['zero = ',num2str(z(3)), ' (N =', num2str(N(3)), ')'],...
       ['zero = ',num2str(z(4)), ' (N =', num2str(N(4)), ')'], 4)  
set(gca, 'position', [0.57 0.15 0.4 0.7]);
