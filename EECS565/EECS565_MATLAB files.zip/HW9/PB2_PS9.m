clear all
close all
clc
format compact

s = tf('s');

A = [0 1;0 0];
C = [1 0];
 
v1 = 3.385*10^(-15);
v2 = 6.529*10^(-21);
V = diag([v1 v2]);
w = 1.653*10^(-12);

w_real = v1^2/(4*v2);

E = sqrt(V);


% compute the rational function P_d(s)P_d^T(-s) 
Pd = C*((s*eye(2)-A)^-1)*E;
PdPdTm = Pd*Pd'; % C*((s*eye(2)-A)^-1)*V*((-s*eye(2)-A')^-1)*C';

figure(1); clf;
pzmap(PdPdTm, 'k');
xlim([-2.5*10^-3  2.5*10^-3]);
ylim([-2*10^-3  2*10^-3]);
title('open loop poles and zeros: Pd(s)*Pd(-s)\prime');
defaultratio_ppt(1.15);

% symmetric root locus
figure(2); clf;
rlocus(PdPdTm);
xlim([-2.5*10^-3  2.5*10^-3]);
ylim([-2*10^-3  2*10^-3]);
title('symmetric root locus');
defaultratio_ppt(1.15);


%% ================================================================== %%
[L,Sigma] = lqr(A',C',V,w);
L = L';
sigma_theta =  sqrt(Sigma(1,1));
estimator_eigenvalues = eig(A-L*C);

hold on
plot(real(estimator_eigenvalues),imag(estimator_eigenvalues),'c*')
title(['estimator e_value = ',num2str([estimator_eigenvalues(1),estimator_eigenvalues(2)],2),...
       ', \sigma_\theta = ',num2str(sigma_theta),' arcseconds'])


%% ================================================================== %%
alpha = 0.05;
A1 = A + alpha*eye(2);

[L1,Sigma1] = lqr(A1',C',V,w);
L1 = L1';

sigma_theta1 = sqrt(Sigma1(1,1));
estimator_eigenvalues = eig(A-L1*C);

figure(3); clf;
plot(real(estimator_eigenvalues),imag(estimator_eigenvalues),'k*', 'markersize', 8, 'linewidth', 2)
title({['estimator eigenvalue = ',num2str([estimator_eigenvalues(1),estimator_eigenvalues(2)],2)], ...
       ['\sigma_\theta = ',num2str(sigma_theta),' arcseconds']})
axis([-.2 .2 -.2 .2]);
grid on;
defaultratio_ppt('old axis');

