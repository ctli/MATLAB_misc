clear all
close all
clc
format compact

omega = logspace(-1,2);

%% ================================================================== %%
% parameters of the inverted pendulum plant
L =1;
g = 10;
M = .5;
m = .5;

% compute state space description of the plant
A = [0  1  0              0;
      0  0 -m*g/M          0;
      0  0  0              1;
      0  0  (M+m)*g/(M*L)  0];
B = [0;1/M;0 ;-1/(M*L)];
C = [1 0 0 0;
     0 0 1 0]; % output 1 = position, output 2 = theta
D = [0;0];
P = ss(A,B,C,D);

%% ================================================================== %%
% to make unit circle centered at critical point
s = tf('s');
% circle = -1+ (-s+1)/(s+1);
% omegac = logspace(-3,3,400);
% [reC,imC] = nyquist(circle,omegac);
% reC = squeeze(reC);
% imC = squeeze(imC);

%% ================================================================== %%
% controller from Problem Set 8
% outer, cart loop, controller
Ctest = -1.7*(s+.1)/(s+5);
Ccanc = .5*((s^2  + 21.53*s + 223.7)*(s+sqrt(20)))/((s+26)*(s+sqrt(10)));
C1 = Ctest*Ccanc/(.05*s+1);
% inner, pendulum loop, controller
C2 = -170*(s+sqrt(20))/(s+26);
Cont = [C1  C2];
SO = (eye(2)+P*Cont)^(-1);
TO = eye(2)-SO;

t = linspace(0,5, 500);
y = step(TO(:,1),t);

figure(1); clf;
plot(t,y(:,1),'k-',t,(180/pi)*y(:,2),'k--', 'linewidth', 2)
xlim([0 5]);
xlabel('time, seconds');
title('closed loop cart step response from Problem Set 8');
defaultratio_ppt;
set(gcf, 'position', [0.0833    4.4792    4.0000    3.0000]);

%% ================================================================== %%
% LQR design
Q = diag([75 1 1 1]);
R = 1;
K = lqr(A,B,Q,R);

G = (C(1,:)*((-A+B*K)^-1)*B)^-1; % precompensator

Tyr_sf = ss(A-B*K,B*G,C,D);

y_sf = step(Tyr_sf,t);

figure(1); hold on; % figure(2); clf;
plot(t,y_sf(:,1),'k-',t,(180/pi)*y_sf(:,2),'--', 'color', [0.7 0.7 0.7], 'linewidth', 2);
legend('y (old controller)','\theta in deg (old controller)','y (LQR)','\theta in deg (LQR)', 1);
title('step response with state feedback')
 
Lsf = ss(A,B,K,0);

% % Bode plot of Lsf
% figure(3); clf;
% bode(Lsf)
% title('Bode plot of L_{sf}')

% Nyquist plot of Lsf
figure(4); clf;
nyquist(Lsf, 'k');
hold on
circle = rsmak('circle', 1, [-1 0]); % rsmak('circle',radius,center)
fnplt(circle,':k',[],1,[]); % FNPLT(F,SYMBOL,INTERV,LINEWIDTH,JUMPS)
plot(-1,0, 'r+');
axis([-3 3 -3 3]);
axis('equal');
title('Nyquist plot of L_{sf}');
defaultratio_ppt;
set(gcf, 'position', [0.0833    0.5000    4.0000    3.0000]);


%% ================================================================== %%
% initial Kalman filter design
V0 = diag([1 1 1 1]); %process noise
W = diag([1 1]); % measurement noise
L = lqe(A,eye(4),C,V0,W);

% closed loop response from r to y and theta
Acl = [A,    -B*K;
      L*C, A-B*K-L*C];
Bcl = [B*G;
       B*G];
Ccl = [C zeros(size(C))];
Dcl = 0;
Tcl = ss(Acl,Bcl,Ccl,Dcl);

y_obs = step(Tcl,t);

figure(5); hold on; 
plot(t,y_sf(:,1),'k-',t,(180/pi)*y_sf(:,2),'--', 'color', [0.7 0.7 0.7], 'linewidth', 2)
plot(t,y_obs(:,1),'k-',t,(180/pi)*y_obs(:,2),'k--', 'linewidth', 1)
xlabel('time, seconds');
title('step response with observer');
legend('y (LQR)','\theta in deg (LQR)','y (obs)','\theta in deg (obs)',1);
box on;
defaultratio_ppt;
set(gcf, 'position', [4.2396    4.4688    4.0000    3.0000]);

Cobs = K*(s*eye(4)-A+B*K+L*C)^-1*L;
LI = Cobs*P;
SI = 1/(1+LI);
[magSI,phaseSI] = bode(SI,omega);
magSI = squeeze(magSI);
stab_rad = 1/max(magSI);

figure(6); clf;
nyquist(LI, 'k')
hold on
fnplt(circle,':k',[],1,[]); % FNPLT(F,SYMBOL,INTERV,LINEWIDTH,JUMPS)
plot(-1,0, 'r+');
axis([-3 3 -3 3])
axis('equal')
title({'Nyquist plot of L_I = C_{obs}P, initial observer design', ['stability radius=', num2str(stab_rad)]});
defaultratio_ppt;
set(gcf, 'position', [4.2500    0.4896    4.0000    3.0000]);


%% ================================================================== %%
% modified Kalman filter design
beta = 5000;
V = V0 + beta^2*(B*B');
L = lqe(A,eye(4),C,V,W);

Acl = [A,    -B*K;
      L*C, A-B*K-L*C];
Bcl = [B*G;
       B*G];
Ccl = [C zeros(size(C))];
Dcl = 0;
Tcl = ss(Acl,Bcl,Ccl,Dcl);

figure(7); clf; 
y_obs2 = step(Tcl,t);
plot(t,y_obs2(:,1),'k-',t,(180/pi)*y_obs2(:,2) ,'k--')
xlabel('time, seconds')
title('step response with observer')
legend('cart position','pendulum angle (degrees)',1)
legend('y (new observer)','\theta in deg (new observer)',1);
defaultratio_ppt;
set(gcf, 'position', [8.4375    4.4792    4.0000    3.0000]);

Cobs = K*(s*eye(4)-A+B*K+L*C)^-1*L;
LI = Cobs*P;

SI = 1/(1+LI);
TI = 1 - SI;
[magSI,phaseSI] = bode(SI,omega);
magSI = squeeze(magSI);
[magTI,phaseTI] = bode(TI,omega);
magTI = squeeze(magTI);
stab_rad = 1/max(magSI);

figure(8); clf;
nyquist(LI, 'k');
hold on;
fnplt(circle,':k',[],1,[]); % FNPLT(F,SYMBOL,INTERV,LINEWIDTH,JUMPS)
axis([-3 3 -3 3]);
axis('equal');
title({'Nyquist plot of L_I = C_{obs}P, modified observer design', ['stability radius=', num2str(stab_rad)]});
defaultratio_ppt;
set(gcf, 'position', [8.4271    0.5104    4.0000    3.0000]);

figure(9); clf;
loglog(omega,magSI,'k-',omega,magTI,'k--');
xlabel('frequency, rad/sec')
ylim([.001 10]);
legend('S_I', 'T_I', 4);
defaultratio_ppt;
set(gcf, 'position', [2.1875    2.3333    4.0000    3.0000]);

figure(10); clf;
bode(Lsf, 'k-', LI, 'k--');
legend('Lsf', 'L_I (modified observer)', 4)
set(gcf, 'position', [618   229   426   358]); 

figure(11); clf;
SO = (eye(2)+P*Cobs)^(-1);
TO = eye(2)-SO;
y = step(TO(:,1),t);
plot(t, y(:,1),'k-',t,y(:,2) ,'k--');
xlabel('time, seconds');
title('step response with inner loop/outer loop architecture');
legend('y (new observer)','\theta in deg (new observer)',0);
defaultratio_ppt;

