clear all
close all
clc
format compact


s = tf('s');

A = [0 1;0 0];
C = [1 0];

v1 = 3.385*10^(-15);
v2 = 6.529*10^(-21);
V = diag([v1 v2]);
E = sqrt(V);

% compute the rational function P_d(s)P_d^T(-s)
% Note: if G denotes a transfer function G(s), then G' denotes the transfer function G^T(-s)
Pd = C*((s*eye(2)-A)^-1)*E;
PdPdTm = Pd*Pd'; % C*((s*eye(2)-A)^-1)*V*((-s*eye(2)-A')^-1)*C';

figure(1); clf;
pzmap(PdPdTm, 'k');
xlim([-2.5*10^-3  2.5*10^-3]);
ylim([-2*10^-3  2*10^-3]);
title('open loop poles and zeros: Pd(s)*Pd(-s)\prime');
defaultratio_ppt(1.15);

figure(2); clf;
rlocus(PdPdTm);
xlim([-2.5*10^-3  2.5*10^-3]);
ylim([-2*10^-3  2*10^-3]);
title('symmetric root locus');
defaultratio_ppt(1.15);


%% ================================================================== %%
w_real = v1^2/(4*v2);


%% ================================================================== %%
disp('====================================')
disp('w-> zero (very clean measurement)');
L= lqr(A',C',V,1e-20)'
Lobs = C*(s*eye(2)-A)^-1*L;
open_loop_zero = tzero(Lobs)

closed_loop_pole1 = eig(A-L*C)
closed_loop_pole2 = pole(minreal(Lobs/(1+Lobs)))

%% ================================================================== %%
disp('====================================')
w = 1.653*10^(-12);
L= lqr(A',C',V,w)'
Lobs = C*(s*eye(2)-A)^-1*L;
open_loop_zero = tzero(Lobs)

closed_loop_pole1 = eig(A-L*C)
closed_loop_pole2 = pole(minreal(Lobs/(1+Lobs)))

