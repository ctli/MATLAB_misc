clear all
close all
clc
format compact

s = tf('s');

Pz = (s^2+s+1)/(s^3+3*s^2+4*s+2);
figure(1);
pzmap(Pz);

Pz_PzT = (s^2+s+1)/(s^3+3*s^2+4*s+2)*((-s)^2+(-s)+1)/((-s)^3+3*(-s)^2+4*(-s)+2);
figure(2);
pzmap(Pz_PzT);

figure(3); clf;
rlocus(Pz_PzT);