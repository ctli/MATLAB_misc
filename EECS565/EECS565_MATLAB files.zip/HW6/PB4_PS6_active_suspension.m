% Active suspension
clear all;
close all;
clc;
format compact;

% system parameters
Mus = 30; % kg
Ms = 250; % kg
Kus = 150000; % N/m
Ks = 15000; % N/m
Bs = 1000; % N/m/s

% state space  description 
A = [0,        1,      0,      0;
  -Kus/Mus, -Bs/Mus, Ks/Mus, Bs/Mus;
     0,       -1,      0,      1;
     0,      Bs/Ms, -Ks/Ms, -Bs/Ms];
B = [0;
   Ms/Mus;
     0;
    -1];
E = [-1 0 0 0]';
C = [0 0 1 0];
D = 0;

A4 = A(end,:);
b4 = B(end);

% open loop plant
Pyu = ss(A,B,C,D);

% % open loop response of x4dot to disturbance
P_d = ss(A,E,A4,D); %A4*(s*eye(4)-A)^-1*E;

% weights for optimization problem
q1 = 50000;
q3 = 5000;
gamma = 10;
r = 0;

Q = diag([q1, 0, q3, 0]) + gamma*(A4')*A4;
R = r + gamma*b4^2;
S = gamma*(A4'*b4);

K = lqr(A,B,Q,R,S)

Asf = A-B*K;
Bsf = E;
Csf = A4-b4*K;
Dsf = zeros(size(C,1),size(Bsf,2));
Tsf_d = ss(Asf,Bsf,Csf,Dsf);

figure(1); clf; % pb(d)
omega = logspace(-1,3,400);
bodemag(P_d,'k-',Tsf_d,'k--',omega)
legend('open loop (P_{d->x4dot})','state feedback (T_{sf,d->x4dot})',3)
title(['frequency response of sprung mass acceleration to d, \gamma = ',num2str(gamma)])
set(gcf,'Units', 'inches');
set(gcf, 'Position', [1.9583    2.6250    4.7083    3.7396]);

figure(2); clf; % pb(e)
Lsf = ss(A,B,K,D); % Lsf = K*(s*eye(4)-A)^-1*B;
nyquist(Lsf,'k');
title('Nyquist plot of L_{sf} = K(sI-A)^{-1}E');
defaultratio_ppt;
axis equal

figure(3); clf; % pb(e)
Ssf = 1/(1+Lsf);
[mag,phase] = bode(Ssf,omega);
mag = squeeze(mag);
stab_rad = 1/max(mag);
loglog(omega,mag, 'k')
title(['sensitivity function S_{sf}, stability radius = ',num2str(stab_rad,2)])
ylim([.1 10])
xlabel('frequency, rad/sec')
ylabel('magnitude')
defaultratio_ppt;
% ylim([10^-1 10^2]);
set(gca, 'ytick', [10^-1 10^0 10^1 10^2]);

%% ================================================================== %%
% observer design
V = 7e-4; %(m/s)^2
W = 1e-8; % m^2

L = lqe(A,E,C,V,W)

Acl = [A,      -B*K;
      L*C, A-B*K-L*C];
Bcl = [E;
       zeros(size(E))];
Ccl = [A4 -b4*K];
Dcl = 0;

Tcl_d = ss(Acl,Bcl,Ccl,Dcl);

figure(4); clf; % pb(h)
bodemag(P_d,'k-',Tsf_d,'k--',Tcl_d,'k:',omega)
title(['frequency response of sprung mass acceleration to d, \gamma = ',num2str(gamma)])
legend('open loop (P_{d->x4dot})','state feedback (T_{sf,d->x4dot})','observer (T_{cl,d->x4dot})',3);
set(gcf,'Units', 'inches');
set(gcf, 'Position', [1.9583    2.6250    4.7083    3.7396]);

figure(5); clf;
A_obs = A-B*K-L*C;
B_obs = L;
C_obs = K;
D_obs = 0;
Cobs = ss(A_obs,B_obs,C_obs,D_obs);
LI = Cobs*Pyu;
nyquist(LI, 'k');
title('Nyquist plot of L_I=C_{obs}P_{yu}')
defaultratio_ppt('old axis');

figure(6); clf;
SI = 1/(1+LI);
omega = logspace(-2,3,400);
[mag,phase] = bode(SI,omega);
mag = squeeze(mag);
stab_rad = 1/max(mag);
loglog(omega,mag, 'k');
ylabel('magnitude');
title(['sensitivity function S_I, stability radius = ',num2str(stab_rad,2)]);
xlabel('frequency, rad/sec');
ylim([.1 10]);
defaultratio_ppt('old axis');


% %% ================================================================== %%
% figure(7); clf;
% pzmap(P_d);
% 
% figure(8); clf;
% pzmap(Tsf_d);
% % xlim([-18 0])
% 
% [num, den] = ss2tf(Asf,Bsf,Csf,Dsf)

