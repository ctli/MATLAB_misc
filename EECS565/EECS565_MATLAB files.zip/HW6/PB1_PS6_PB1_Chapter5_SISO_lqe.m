clear all;
close all;
clc;
format compact

% plant
A = 1;
C = 1;

% noise covariances
V = 1;
W = [1e3 1 0.1 0.01];

omega = logspace(-1,2,200);
s = tf('s');
for i = 1:length(W)
    L = lqr(A,C',V,W(i))

    % closed loop disturbance response
%     Tv_dy = C/(s+sqrt(A^2+V*(C^2)/W(i)));
    Tv_dy = C*(s-A+L*C)^-1;
    [mag_Tv_dy(i,:),phase_Tv_dy(i,:)] = bode(Tv_dy,omega);
    
    % closed loop noise response
%     Tw_dy = -(A+sqrt(A^2+V*(C^2)/W(i)))/(s+sqrt(A+V*C^2/W(i)));
    Tw_dy = -C*(s-A+L*C)^-1*L;
    [mag_Tw_dy(i,:),phase_Tw_dy(i,:)] = bode(Tw_dy,omega);
end
figure(1); clf;
set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 6.67, 2.8]);

subplot(1,2,1); %Tv_dy
loglog(omega,mag_Tv_dy(1,:),'k-',omega,mag_Tv_dy(2,:),'k:',omega,mag_Tv_dy(3,:),'k--')
title('closed loop transfer function $T_{v\rightarrow \Delta y}$','interpreter','latex');
xlabel('$\omega$, rad/sec','interpreter','latex');
set(legend('$V/W=1$','$V/W=10$','$V/W=100$',3),'interpreter','latex');
set(gca, 'position', [0.07 0.17 0.4 0.72]);

subplot(1,2,2); %Tw_dy
loglog(omega,mag_Tw_dy(1,:),'k-',omega,mag_Tw_dy(2,:),'k:',omega,mag_Tw_dy(3,:),'k--')
title('closed loop transfer function $T_{w\rightarrow \Delta y}$','interpreter','latex');
xlabel('$\omega$, rad/sec','interpreter','latex');
set(legend('$V/W=1$','$V/W=10$','$V/W=100$',3),'interpreter','latex');
set(gca, 'position', [0.57 0.17 0.4 0.72]);

%% ================================================================== %%
% simulate response to noise inputs
randn('seed',0)
t = linspace(0,5,100);
vnoise = randn(size(t));
wnoise = randn(size(t));
for i = 1:length(W)
    L = lqr(A,C',V,W(i));
    Abig = [A,   0
           L*C, A-L*C];
    Bbig = [1, 0;
            0, L];
    Cbig = [C -C];
    Dbig = [0 0];
    Tobs = ss(Abig,Bbig,Cbig,Dbig);
    v = sqrt(V)*vnoise;
    w = sqrt(W(i))*wnoise;
    
    dy = lsim(Abig,Bbig,Cbig,Dbig,[v' w'],t);

    figure(i+1);
    plot(t,v,'-', 'color', [0.7 0.7 0.7], 'linewidth', 2); hold on;
    plot(t,w,'--', 'color', [0.3 0.3 0.3], 'linewidth', 2);
    plot(t,dy,'k-', 'linewidth', 1);
    axis([0 5 -3 3]);
    xlabel('time, seconds','interpreter','latex');
    title(['output estimation error, V=',num2str(V),', W=',num2str(W(i))],'interpreter','latex');
    set(legend('$v$, process noise','$w$, measurement noise', '$\Delta y$, output', 'location', 'EastOutside'),'interpreter','latex');

    set(gcf,'Units', 'inches');
    set(gcf, 'Position', [1.4167    2.4063    6.4375*0.8    3*0.8]);
    set(gca, 'Position', [0.100    0.16    0.4821    0.75]);
end
