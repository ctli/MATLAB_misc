clear all;
close all;
clc;
format compact


% noise covariances
V = 1;
W = [1e-3 1e3];

%% ================================================================== %%
% unstable plant
A = 1;
C = 1;

randn('seed',0)
t = linspace(0,5,100);
vnoise = randn(size(t));
wnoise = randn(size(t));
for i = 1:length(W)
    L = lqr(A,C',V,W(i));
    Abig = [A,   0
           L*C, A-L*C];
    Bbig = [1, 0;
            0, L];
    Cbig = [C -C];
    Dbig = [0 0];
    Tobs = ss(Abig,Bbig,Cbig,Dbig);
    v = sqrt(V)*vnoise;
    w = sqrt(W(i))*wnoise;
    
    dy = lsim(Abig,Bbig,Cbig,Dbig,[v' w'],t);

    figure(i);
    plot(t,v,'-', 'color', [0.7 0.7 0.7], 'linewidth', 2); hold on;
    plot(t,w,'--', 'color', [0.4 0.4 0.4], 'linewidth', 2);
    plot(t,dy,'k-', 'linewidth', 1);
    xlim([0 5]);
    ylim([-40 40]);
    ylim([-0.5 0.5]);
%     axis([0 5 -3 3]);
    xlabel('time, seconds','interpreter','latex');
    title(['unstable system, V=',num2str(V),', W=',num2str(W(i))],'interpreter','latex');
    set(legend('$v$, process noise','$w$, measurement noise', '$\Delta y$, output', 'location', 'EastOutside'),'interpreter','latex');

    set(gcf,'Units', 'inches');
    set(gcf, 'Position', [1.4167    2.4063    6.4375*0.8    3*0.8]);
    set(gca, 'Position', [0.100    0.16    0.4821    0.75]);
end


%% ================================================================== %%
% stable plant
A = -1;
C = 1;

randn('seed',0)
t = linspace(0,5,100);
vnoise = randn(size(t));
wnoise = randn(size(t));
for i = 1:length(W)
    L = lqr(A,C',V,W(i));
    Abig = [A,   0
           L*C, A-L*C];
    Bbig = [1, 0;
            0, L];
    Cbig = [C -C];
    Dbig = [0 0];
    Tobs = ss(Abig,Bbig,Cbig,Dbig);
    v = sqrt(V)*vnoise;
    w = sqrt(W(i))*wnoise;
    
    dy = lsim(Abig,Bbig,Cbig,Dbig,[v' w'],t);

    figure(i+2);
    plot(t,v,'-', 'color', [0.7 0.7 0.7], 'linewidth', 2); hold on;
    plot(t,w,'--', 'color', [0.4 0.4 0.4], 'linewidth', 2);
    plot(t,dy,'k-', 'linewidth', 1);
    xlim([0 5]);
    ylim([-40 40]);
    ylim([-0.5 0.5]);
%     axis([0 5 -3 3]);
    xlabel('time, seconds','interpreter','latex');
    title(['stable system, V=',num2str(V),', W=',num2str(W(i))],'interpreter','latex');
    set(legend('$v$, process noise','$w$, measurement noise', '$\Delta y$, output', 'location', 'EastOutside'),'interpreter','latex');

    set(gcf,'Units', 'inches');
    set(gcf, 'Position', [1.4167    2.4063    6.4375*0.8    3*0.8]);
    set(gca, 'Position', [0.100    0.16    0.4821    0.75]);
end
