clear all
close all
clc;
format compact;

% plant for the magnetic ball problem
A = [0 1 0;64.4 0 -16;0 0 -100];
B = [0;0;100];
C = [1 0 0];
D = [0];
P = ss(A,B,C,D);

% disturbance description
E=B;
F=0;

% dimensions of system (makes it easier to specify closed loop
% system matrices) 
n = size(A,1);    % #plant states
p = size(B,2);    % #inputs
q = size(C,1);    % #outputs
m = size(E,2);    % #disturbance states

% % First the bad design from the problem set
% psf = [-6+6*j   -6-6*j   -20];
% pobs = [-12+12*j  -12-12*j  -40  -5];
% 
% % Then the good design from the problem set
% psf = [-30+30*j  -30-30*j  -100];
% pobs = [2*psf  -5];
% 
% % choose K and L as we did before
% K = place(A,B,psf);
% L = place([A E;zeros(m,n) zeros(m,m)]',[C F]',pobs)';


% create step command and disturbance 
clear r d
t = linspace(0,5,500);
r = zeros(size(t)); r(t>=1) = 1;
d = zeros(size(t));% d(t>=2) = 0.5;

% perform LQR design and study without observer
Q = diag([50,1,1]);
R = diag(5.5);
K = lqr(A,B,Q,R);

% precompensator gain
G = (C*((-A+B*K)^(-1))*B)^(-1); %eq(3.52)

% closed loop response without observer
Asf = A-B*K;
Bsf = [B*G, E];
Csf = C;
Dsf = zeros(size(C,1),size(Bsf,2));
Psf = ss(Asf,Bsf,Csf,Dsf);

% plot control response
Cu = -K;
Du = zeros(size(C,1),size(Bsf,2));
Psf_u = ss(Asf,Bsf,Cu,Du);

% simulate response of y and u to command and disturbance
[y,x] = lsim(Psf,[r' d'],t);
[u,x] = lsim(Psf_u,[r' d'],t);

figure(1); clf;
set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 6.67, 2.8]);

subplot(1,2,1);
plot(t,r,'-', 'color', [0.7 0.7 0.7], 'linewidth', 2); hold on;
plot(t,y,'k-');
plot(t,d,'k--', 'linewidth', 2);
ylim([0 1.03]);
line([1.5 1.5], get(gca, 'ylim'), 'color', [0.8 0.8 0.8]);
text(1.5, 0.5, '1.5 sec', 'HorizontalAlignment', 'center', 'Rotation', 90, 'color', [0.8 0.8 0.8]);
title('response of system to command and disturbance');
xlabel('time, seconds');
legend('ref','y (out)','d (dist)',0);
set(gca, 'position', [0.07 0.17 0.4 0.72]);

subplot(1,2,2);
plot(t,u,'k', 'linewidth', 2);
xlabel('time, seconds');
legend('u', 'location', 'East');
title('control signal');
set(gca, 'position', [0.57 0.17 0.4 0.72]);

% % Nyquist plot
figure(3); clf;
Lsf = ss(A,B,K,D); %Lsf = (K*(s*eye(n)-A)^-1*B)
nyquist(Lsf, 'k');
title('Nyquist plot of Lsf = K(sI-A)^{-1}B');
axis equal
defaultratio_ppt('old axis');

Lsf_pole = pole(Lsf)

% Bode plot of closed loop disturbance response
figure(4); clf;
omega = logspace(-3,3);
[mag,phase] = bode(Asf,Bsf,Csf,Dsf,2,omega); % Tdy = C*(s*eye(n)-A+B*K)^(-1)*E; bode(Tdy);
loglog(omega,mag, 'k');
ylabel('magnitude');
xlabel('frequency, rad/sec');
title('closed loop disturbance response (T_{dy} with state feedback)');
defaultratio_ppt('old axis');

% response of step disturbance
r = zeros(size(t));
d = zeros(size(t)); d(t>=2) = 0.5;
[y,x] = lsim(Psf,[r' d'],t);
[u,x] = lsim(Psf_u,[r' d'],t);

figure(1); clf;
set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 6.67, 2.8]);

subplot(1,2,1);
plot(t,r,'-', 'color', [0.7 0.7 0.7], 'linewidth', 2); hold on;
plot(t,y,'k-');
plot(t,d,'k--', 'linewidth', 2);
title('response of system to command and disturbance');
xlabel('time, seconds');
legend('ref','y (out)','d (dist)',0);
set(gca, 'position', [0.07 0.17 0.4 0.72]);

subplot(1,2,2);
plot(t,u,'k', 'linewidth', 2);
xlabel('time, seconds');
legend('u', 'location', 'East');
title('control signal');
set(gca, 'position', [0.57 0.17 0.4 0.72]);
ylim([-1 0.05]);

%% ================================================================== %%
% optimal estimator
V =  1500;
W =  1;
Aaug = [A, E;
        C, 0];
Baug = [zeros(n,1);
          1];
Caug = [C, 0];

% [kalmf,L,S] = kalman(ss(Aaug,Baug,Caug,0),V,W);
L = lqe(Aaug,Baug,Caug,V,W)
L1 = L(1:3);
L2 = L(4);

F = 0;
H = -G*(C*((-A+B*K)^(-1))*E+F); %eq(3.53)

% closed loop state equations, eq(3.54)
Acl = [A,          -B*K,        B*H;
       L1*C, A-B*K-L1*C, E+B*H-L1*F;
       L2*C,      -L2*C,      -L2*F];
	  
Bcl = [B*G, E;
       B*G, L1*F;
         0, L2*F];

Ccl = [C, zeros(size(C)), 0];
Dcl = [0 0];

Cu = [zeros(size(C)), -K, H];
Du = [G 0];

% simulate response of y and u to command and disturbance
r = zeros(size(t));
d = zeros(size(t)); d(t>=2) = 0.5;
[y,x] = lsim(Acl,Bcl,Ccl,Dcl,[r' d'],t);
[u,x] = lsim(Acl,Bcl,Cu,Du,[r' d'],t);
xhat = x(:,n+1:2*n);
dhat = x(:,2*n+1:2*n+m);

% % anther way to see u:
% u =-K*xhat'+G*r+H*dhat';

figure(5); clf;
set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 6.67, 2.8]);

subplot(1,2,1);
plot(t,r,'-', 'color', [0.7 0.7 0.7], 'linewidth', 2); hold on;
plot(t,y,'k-');
plot(t,d,'k--', 'linewidth',2);
plot(t,dhat,'k-.');
title('response of system to command and disturbance');
xlabel('time, seconds');
legend('ref','y (out)','d (dist)','d_{est}','location', 'east');
set(gca, 'position', [0.07 0.17 0.4 0.72]);
line([2.5 2.5], get(gca, 'ylim'), 'color', [0.8 0.8 0.8]);
text(2.5, sum(get(gca, 'ylim'))/2, '2.5 sec', 'HorizontalAlignment', 'center', 'Rotation', 90, 'color', [0.8 0.8 0.8]);

subplot(1,2,2);
plot(t,u,'k-', 'linewidth',2);
xlabel('time, seconds');
legend('u','location', 'east');
title('control signal');
set(gca, 'position', [0.57 0.17 0.4 0.72]);
ylim([-4 0.07]);

% observer base compensator, eq(3.60)
A_obs = [A-L1*C-B*K, B*H+E;
              -L2*C,     0];
B_obs = [L1;
         L2];
C_obs = [K -H];
D_obs = 0;
Cobs = ss(A_obs,B_obs,C_obs,D_obs);
Lobs = Cobs*P;
figure(7); clf;
nyquist(Lobs, 'k');
title('Nyquist plot of L_{obs}');
axis equal
axis([-2 2 -2 2]);
defaultratio_ppt;

Lobs_pole = pole(Lobs)

% compute closed loop disturbance response
omega = logspace(-3,3);
[mag,phase] = bode(Acl,Bcl,Ccl,Dcl,2,omega);
figure(8); clf;
loglog(omega,mag, 'k');
ylabel('magnitude');
xlabel('frequency, rad/sec');
title('closed loop disturbance response (T_{dy} with estimator)');
defaultratio_ppt('old axis');

figure(9); clf;
SI = 1/(1+Lobs); %disturbance response
Ssf = 1/(1+Lsf); %command response
bodemag(SI,'k', Ssf, 'k--');
legend('S_I', 'S_{sf}',4);
set(gcf,'Units', 'inches');
set(gcf, 'Position', [1.9583    2.6250    4.7083    3.7396]);

