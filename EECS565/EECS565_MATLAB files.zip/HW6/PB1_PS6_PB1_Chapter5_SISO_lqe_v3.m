% LQE, measure noise is larger than design value
clear all;
close all;
clc;
format compact

% plant
A = 1;
C = 1;

V = 1;
W = 0.01;
L = lqr(A,C',V,W)

% simulate response to noise inputs
randn('seed',0)
t = linspace(0,5,100);
vnoise = randn(size(t));
wnoise = randn(size(t));

W = 1; % measure noise is larger than design value
Abig = [A,   0
    L*C, A-L*C];
Bbig = [1, 0;
    0, L];
Cbig = [C -C];
Dbig = [0 1];
Tobs = ss(Abig,Bbig,Cbig,Dbig);
v = sqrt(V)*vnoise;
w = sqrt(W)*wnoise;

dy = lsim(Abig,Bbig,Cbig,Dbig,[v' w'],t);

figure(1); clf;
plot(t,v,'-', 'color', [0.7 0.7 0.7], 'linewidth', 2); hold on;
plot(t,w,'--', 'color', [0.3 0.3 0.3], 'linewidth', 2);
% plot(t,v,'-', 'color', [1 0 0], 'linewidth', 1); hold on;
% plot(t,w,'--', 'color', [0 0 1], 'linewidth', 1);
plot(t,dy,'k-', 'linewidth', 1);
axis([0 5 -3 3]);
xlabel('time, seconds','interpreter','latex');
title(['Design: V=1, W=0.01; Actual: V=1, W=1'],'interpreter','latex');
set(legend('$v$, process noise','$w$, measurement noise', '$\Delta y$, output', 'location', 'EastOutside'),'interpreter','latex');

set(gcf,'Units', 'inches');
set(gcf, 'Position', [1.4167    2.4063    6.4375*0.8    3*0.8]);
set(gca, 'Position', [0.100    0.16    0.4821    0.75]);

