clear all;
close all;
clc;
format compact;
format short;

s = tf('s');

% transfer function for the x-axis of a nano-positioner
Gxx = 4.29*10^(10)*(s^2+631.2*s+9.4*10^6)/(s^2+178.2*s+6*10^6);
Gxx = Gxx/(s^2+412.3*s+1.6*10^7);
Gxx = Gxx*(s^2+638.8*s+4.5*10^7)/(s^2+209.7*s+5.6*10^7)/(s+5818);

% open loop Bode plot in Hz
figure(1); clf;
h = bodeplot(Gxx, 'k');
setoptions(h,'FreqUnits','Hz');
title('G_{xx}')
set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 4*1.1875, 3*1.1875]);

% PII controller
Kpii = (.001*s^2 + 450*s + 10^5)/s^2;

% stability margin with PII controller
figure(2); clf;
margin(Gxx*Kpii);
set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 4*1.1875, 3*1.1875]);

% sensitivity function with PII controller
Spii = 1/(1+Gxx*Kpii);
figure(3); clf;
h = bodeplot(Spii, 'k');
setoptions(h,'FreqUnits','Hz','PhaseVisible','off');
title('sensitivity function, S_{PII} = 1/(1+G_{xx}*K_{PII})')
set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 4*1.1875, 3*1.1875]);


omega = logspace(-1,4,1000);
[mag,phase] = bode(Spii,omega);
mag = squeeze(mag);
stab_rad_Pii = 1/max(mag)

% plot tracking error
% ramp input
t = linspace(0,.05,1000);
r = t;

Tpii = 1-Spii;

y = lsim(Tpii,r,t);
PII_error = r-y';

figure(4); clf;
plot(t,PII_error, 'k');
title('tracking error with PII controller');
xlabel('time, seconds');
set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 4*1.1875, 3*1.1875]);

%% ================================================================== %%
% state variable description of plant
[A,B,C,D] = ssdata(Gxx);
n = size(A,1);

% state space of double integrator with input equal to the error signal y-r
F = [0 1;0 0];
H = [0;1];

% augmented state space description: plant plus double integrator dynamics
% (F,H) needs to be stabilizable pair
Aaug = [A, zeros(n,2);
        H*C, F];
Baug = [B;
        zeros(2,1)];
Caug = [C, [0 0]];
Daug = 0;

% use LQR to stabilize the augmented system
Q = diag([1 1 1 1 1 1 1 100000000  10000]);
R = .001;
Kaug = lqr(Aaug,Baug,Q,R);

eig(Aaug-Baug*Kaug);

% closed loop with state feedback
K = Kaug(1,1:n);
Kq = Kaug(1,n+1:end);

Acl = [A-B*K, -B*Kq;
         H*C,   F];
Bcl = [zeros(n,1);
         -H];
Ccl = [C, [0 0]];
Dcl = 0;
sys_cl = ss(Acl,Bcl,Ccl,Dcl);

y = lsim(sys_cl,r,t);

% plot tracking error
figure(5); clf;
plot(t,r-y','k-',t,PII_error,'k--')
title('tracking error')
legend('state feedback','PII')
xlabel('time, seconds')
set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 4*1.1875, 3*1.1875]);

% sensitivity function
Ssf = 1/(1+Kaug*(s*eye(n+2)-Aaug)^-1*Baug);

[mag,phase] = bode(Ssf,omega);
mag = squeeze(mag);
stab_rad_sf = 1/max(mag)

% compare sensitivity functions
figure(6); clf;
h = bodeplot(Ssf,'k-',Spii,'k--');
setoptions(h,'FreqUnits','Hz','PhaseVisible','off');
title('sensitivity function with state feedback and PII controllers')
legend('state feedback','PII', 4)
set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 4*1.1875, 3*1.1875]);


%% ================================================================== %%
% process disturbance covaruance V
% measurement noise covariance W
V =1000*eye(1);
W = 1;
 
L = lqe(A,B,C,V,W);

A_1 = [F,     zeros(2,n);
       -B*Kq, A-B*K-L*C];
B_1 = [H;
       L]; 
C_1 = [Kq, K];
D_1 = 0;

Cobs = ss(A_1,B_1,C_1,D_1);

Sobs = 1/(1+Cobs*Gxx);

[mag,phase] = bode(Sobs,omega);
mag = squeeze(mag);
stab_rad_obs = 1/max(mag)

figure(7); clf;
h = bodeplot(Sobs,'k-',Ssf,'k:',Spii,'k--');
setoptions(h,'FreqUnits','Hz','PhaseVisible','off');
title('sensitivity functions of all three controllers')
set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 4*1.1875, 3*1.1875]);
legend('observer','state feedback','PII',4)



