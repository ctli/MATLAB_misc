clear all
close all
clc
format compact

% Plant
A = [0 1 0 0;
     2 0 0 0;
     0 0 0 1;
     0 0 6 0];
B = [0 0;
    -2 -2;
     0 0;
    -1 1];
C = [1 0 6 0;
     1 0 -6 0];
D = [0 0;
     0 0];

n = size(A,1);
p = size(B,2);
q = size(C,1);

% Plant augmented with integrators q1 and q2
Aaug = [A, zeros(n,q)
        C, zeros(q,q)];
Baug = [B;
        zeros(q,q)];
Caug = [C zeros(q,q)];
Daug = zeros(q,q);

%  transformation matrix from states [h;theta] to outputs [y1;y2]
H = [1, 6;
     1, -6];

% weighting matrices
% Q: the state weighting matrix from part(a)
% R: the control weighting matrix from part (a)
% Qx: weights for the augmented integrals of state errors
% Qy = inv(H)'*Qx*inv(H): weights for augmented integrals of output errors
% Qaug = [Q 0;0 Qy]: the weighting matrix for the augmented state vector

Q = diag([200 1 600 1]);
R = eye(p);
Qx=[20000, 0;
    0, 70000];

Qy = inv(H)'*Qx*inv(H);
Qaug = [Q zeros(4,2);
        zeros(2,4) Qy];

% % compute the optimal state feedback
Kaug = lqr(Aaug,Baug,Qaug,R);
K = Kaug(:,1:n);
KI = Kaug(:,n+1:n+q);

% print out closed loop eigenvalues
format short e
closed_loop_evalues = eig(Aaug-Baug*Kaug)

% closed loop response to commands with state feedback and integral control
Asf = [A-B*K, -B*KI;
         C,     zeros(q,q)];
Bsf = [zeros(n,q);
      -eye(q)*H];
Csf = eye(n+q);
Dsf = zeros(n+q,p);

sys_sf = ss(Asf,Bsf,Csf,Dsf);

% step commands to h and theta
% this syntax does both: e.g., x(:,1,1) is the response of the state x1 to
% a step command in h, and x(:,1,2) is the response of the state x1 to a
% step command in theta
tfinal = 2;
[y,t,x] = step(sys_sf,tfinal);


% % plot response to a height step command
% figure(1); clf; 
% plot(t,x(:,1,1),'k-', 'linewidth', 2); hold on;
% plot(t,x(:,2,1),'k--', 'color', [0.7 0.7 0.7], 'linewidth', 2);
% plot(t,x(:,3,1),'k-', 'color', [0.7 0.7 0.7], 'linewidth', 2);
% plot(t,x(:,4,1),'k:');
% legend('height','dh/dt','\theta','d\theta/dt',0)
% title('step command to height')
% xlabel('time, seconds')
% line([t(1) t(end)], [.9 .9], 'color', [0.7 0.7 0.7]);
% line([t(1) t(end)], [1.05 1.05], 'color', [0.7 0.7 0.7]);
% 
% 
% % plot response to a theta step command
% figure(2); clf; 
% plot(t,x(:,1,2),'k-', 'linewidth', 2); hold on;
% plot(t,x(:,2,2),'k--', 'color', [0.7 0.7 0.7], 'linewidth', 2);
% plot(t,x(:,3,2),'k-', 'color', [0.7 0.7 0.7], 'linewidth', 2);
% plot(t,x(:,4,2),'k:');
% legend('height','dh/dt','\theta','d\theta/dt',0)
% title('step command to angle')
% xlabel('time, seconds')
% line([t(1) t(end)], [.9 .9], 'color', [0.7 0.7 0.7]);
% line([t(1) t(end)], [1.05 1.05], 'color', [0.7 0.7 0.7]);

% step disturbance, w = 1.0, d = 1.0
E = [0;
    0.5;
     0;
    1/24];
m = size(E,2); % #disturbance states

Eaug = [E;[0;0]];

% closed loop response to disturbance with state feedback and integral control
Asf_dist = Asf;
Bsf_dist = [E
         zeros(p,m)];
Csf_dist = Csf;
Dsf_dist = zeros(n+q,m);

sys_sf_dist = ss(Asf_dist,Bsf_dist,Csf_dist,Dsf_dist);

[y,t,x] = step(sys_sf_dist,tfinal);

figure(3); clf; 
plot(t,x(:,1),'-',t,x(:,3),'--')
legend('height','\theta',0)
title('zero command and unit step disturbance')
xlabel('time, seconds')

% for purposes of comparison
x1sf = x(:,1);
x3sf = x(:,3);
tsf = t;

figure(81); clf; % plot control u
q12old = x(:,n+1:end);
u = -K*x(:,1:n)'-KI*q12old';
plot(tsf,q12old(:,1), tsf,q12old(:,2), 'linewidth',3); hold on;

% plot the integrator states
figure(4); clf; 
plot(t,x(:,5),'-',t,x(:,6),':')
legend('q_1','q_2',0)
title('integrator states q_1 and q_2, step disturbance with state feedback')
xlabel('time, seconds')

% design Kalman filter with process disturbance covariance V and
% measurement noise covariance W
V = 1*75000000;
W = eye(2);

% optimal estimator gain
L = lqe(A,E,C,V,W);

% state equations of the closed loop system with plant, integrator, and
% estimator states, input given by the disturbance, and output equal to h
% and theta
Acl_dist = [A,    -B*K,      -B*KI;
           L*C, A-B*K-L*C,   -B*KI;
            C,  zeros(q,n), zeros(q,q)];
Bcl_dist = [E;
           zeros(n,1);
           zeros(q,1)]; 
Ccl_dist = [1,0,0,0,zeros(1,n),zeros(1,q);
            0,0,1,0,zeros(1,n),zeros(1,q)];
Dcl_dist = zeros(size(Ccl_dist,1),m);

sys_est_dist = ss(Acl_dist,Bcl_dist,Ccl_dist,Dcl_dist);

% evaluate response to a step disturbance
[y,t,x] = step(sys_est_dist,tsf);

% compare disturbance response with state feedback to that with estimator
% based feedback
figure(5); clf;
subplot(2,1,1);
plot(tsf,x1sf,'k-', tsf,y(:,1),'k--');
legend('h (sf)', 'h (est)');
ylabel('h');
title('disturbance response');
subplot(2,1,2);
plot(tsf,x3sf,'k-', tsf,y(:,2),'k--');
legend('\theta (sf)', '\theta (est)');
xlabel('time, seconds');
ylabel('\theta');
set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 4*1.1875, 3*1.1875]);

figure(6); clf;
plot(tsf,x1sf-y(:,1),'k:',tsf,x3sf-y(:,2),'k--');
legend('h(sf)-h(est)','\theta(sf)-\theta(est)',4);
title({'difference between disturbance response', 'with and without estimator'});
xlabel('time, seconds');
line([t(1) t(end)], [10^(-3) 10^(-3)], 'color', [0.5 0.5 0.5]);
line([t(1) t(end)], [-10^(-3) -10^(-3)], 'color', [0.5 0.5 0.5]);
ylim([-1.1e-3 1.1e-3])
set(gcf,'Units', 'inches');
figure_position = get(gcf, 'Position'); %[left bottom width height]
set(gcf, 'Position', [figure_position(1:2), 4*1.1875, 3*1.1875]);

%% ================================================================== %%
figure(7); clf; % plot all states
plot(tsf,x(:,1), tsf, x(:,2), tsf, x(:,3), tsf, x(:,4));
grid on;
title('all states');

figure(8); clf; % plot all estimated states
plot(tsf,x(:,5), tsf, x(:,6), tsf, x(:,7), tsf, x(:,8));
grid on;
title('estimated states, xhat');

figure(81); hold on; % plot control u
q12 = x(:,2*n+1:end);
plot(tsf,q12(:,1), 'm', tsf,q12(:,2), 'c');

%% ================================================================== %%
s = tf('s');
Cx_obs = diag([ones(1,n),zeros(1,n),zeros(1,q)]);
Xobs = Cx_obs*(s*eye(2*n+q)-Acl_dist)^-1*Bcl_dist;
x_obs_ss = Cx_obs*(-Acl_dist)^-1*Bcl_dist
dcgain(Xobs)

Cxhat_obs = diag([zeros(1,n),ones(1,n),zeros(1,q)]);
Xhatobs = Cxhat_obs*(s*eye(2*n+q)-Acl_dist)^-1*Bcl_dist;
xhat_obs_ss = Cxhat_obs*(-Acl_dist)^-1*Bcl_dist
dcgain(Xhatobs)

Cx_sf = diag([ones(1,n),zeros(1,q)]);
Xsf = Cx_sf*(s*eye(n+q)-Asf_dist)^-1*Bsf_dist;
x_sf_ss = Cx_sf*(-Asf_dist)^-1*Bsf_dist
dcgain(Xsf)
